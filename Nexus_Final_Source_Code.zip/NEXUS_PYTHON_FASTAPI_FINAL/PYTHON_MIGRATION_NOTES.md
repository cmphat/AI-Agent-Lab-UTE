# NEXUS — Python AI Engine Migration

## Những phần đã giữ nguyên

- Toàn bộ giao diện React/TypeScript, theme sáng/tối, song ngữ, scenario, policy, timeline, collapse modal và báo cáo.
- Dữ liệu 35 chính sách vẫn lấy từ `src/core/data.ts`; frontend gửi trực tiếp danh sách này sang Python nên không phát sinh hai bộ policy lệch nhau.
- Cấu trúc `NationState` và kết quả hiển thị của AI Lab.

## Những phần được chuyển sang Python

- FastAPI service trong `python_backend/`.
- 18 thuật toán trong `python_backend/algorithms.py`:
  BFS, DFS, IDS, UCS, Greedy Best-First, A*, Hill Climbing, Local Beam Search, Simulated Annealing, AND-OR Search, Belief-State Search, LRTA*, Constraint Propagation, Backtracking CSP, Min-Conflicts CSP, Minimax, Alpha-Beta và Expectimax.
- Hàm mô phỏng trạng thái, đánh giá quốc gia, chi phí chuyển trạng thái và kiểm tra sụp đổ dùng cho AI trong `python_backend/engine.py`.
- Benchmark 5 năm của trang So sánh thuật toán chạy qua endpoint Python.

## Luồng chạy

```text
AILab / Compare (React)
        │ POST JSON
        ▼
FastAPI :8000
        │
        ├── /api/run
        ├── /api/benchmark/algorithm
        └── /api/health
```

## Chế độ dự phòng

Source TypeScript cũ được giữ làm fallback khi backend chưa mở nhằm tránh trắng màn hình. Khi chạy bằng `CHAY_NEXUS.bat`, AI Lab và Compare ưu tiên Python 100%; trên giao diện sẽ hiện `Python / FastAPI`.

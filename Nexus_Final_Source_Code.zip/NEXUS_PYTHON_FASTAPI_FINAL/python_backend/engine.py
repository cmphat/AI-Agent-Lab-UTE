from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from math import exp
from typing import Any, Iterable

State = dict[str, Any]
Policy = dict[str, Any]

POSITIVE_EVENT_IDS = {"boom", "tech_breakthrough", "trade_pact"}
REVERSAL_PAIRS = {
    frozenset(("tax_up", "tax_down")),
    frozenset(("borrow", "pay_debt")),
    frozenset(("austerity", "welfare")),
    frozenset(("austerity", "job_program")),
    frozenset(("power_plant", "green_energy")),
    frozenset(("military", "diplomacy")),
}
POSITIVE_KEYS = (
    "happiness", "education", "healthcare", "energy", "environment",
    "military", "technology", "cybersecurity", "infrastructure", "diplomacy",
)


def clone_state(state: State) -> State:
    return deepcopy(state)


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def average(values: Iterable[float]) -> float:
    values = list(values)
    return sum(values) / max(1, len(values))


def policy_map(policies: list[Policy]) -> dict[str, Policy]:
    return {p["id"]: p for p in policies}


def is_reversal(left: str, right: str) -> bool:
    return frozenset((left, right)) in REVERSAL_PAIRS


def monthly_tax_revenue(state: State) -> float:
    return float(state["gdp"]) * (float(state["taxRate"]) / 100.0) / 12.0


def operating_cost(state: State) -> float:
    return (
        4
        + float(state["education"]) * 0.025
        + float(state["healthcare"]) * 0.025
        + float(state["energy"]) * 0.02
        + float(state["infrastructure"]) * 0.025
        + float(state["cybersecurity"]) * 0.02
        + float(state["military"]) * 0.015
        + float(state["technology"]) * 0.015
    )


def fiscal_metrics(state: State) -> tuple[float, float, float]:
    tax = monthly_tax_revenue(state)
    cost = operating_cost(state)
    return tax, cost, tax - cost


def population_growth_rate(state: State) -> float:
    base = 0.00004
    healthcare = ((float(state["healthcare"]) - 50) / 100) * 0.00018
    happiness_growth = ((float(state["happiness"]) - 50) / 100) * 0.00006 if state["happiness"] >= 50 else 0
    happiness_decline = ((40 - float(state["happiness"])) / 100) * 0.00016 if state["happiness"] < 40 else 0
    return clamp(base + healthcare + happiness_growth - happiness_decline, -0.00045, 0.00035)


def diminishing_above_average(value: float, baseline: float, k: float = 25) -> float:
    if value <= baseline:
        shortage = baseline - value
        return clamp(value - shortage * 0.15, 0, 100)
    excess = value - baseline
    return clamp(baseline + k * (1 - exp(-excess / k)), 0, 100)


def target_happiness(state: State, active_event_count: int | None = None) -> float:
    count = len(state.get("active_events", [])) if active_event_count is None else active_event_count
    employment = clamp(100 - float(state["unemployment"]), 0, 100)
    price = clamp(100 - max(0, float(state["inflation"]) - 3) * 6, 0, 100)
    tax = clamp(100 - max(0, float(state["taxRate"]) - 20) * 8, 0, 100)
    crisis = clamp(100 - count * 20, 0, 100)
    social_average = average([state["healthcare"], state["education"], employment, price, tax, crisis])
    return clamp(
        diminishing_above_average(float(state["healthcare"]), social_average) * 0.25
        + diminishing_above_average(float(state["education"]), social_average) * 0.15
        + diminishing_above_average(employment, social_average) * 0.22
        + diminishing_above_average(price, social_average) * 0.20
        + diminishing_above_average(tax, social_average) * 0.08
        + diminishing_above_average(crisis, social_average) * 0.10,
        0,
        100,
    )


def gdp_health(state: State) -> float:
    scale = max(0.1, float(state["population"]) / 1_000_000)
    return clamp((float(state["gdp"]) / scale / 1000) * 100, 0, 100)


def budget_health(state: State) -> float:
    months = float(state["budget"]) / max(1, operating_cost(state))
    return clamp((months / 24) * 100, 0, 100)


def fiscal_flow_health(state: State) -> float:
    _, cost, balance = fiscal_metrics(state)
    return clamp(50 + (balance / max(1, cost)) * 50, 0, 100)


def debt_safety(state: State) -> float:
    ratio = float(state["debt"]) / max(1, float(state["gdp"]))
    if ratio <= 0.35:
        return 100
    return clamp(100 - (ratio - 0.35) * 240 - max(0, ratio - 0.65) * 160, 0, 100)


def inflation_health(state: State) -> float:
    high = max(0, float(state["inflation"]) - 3) * 8
    low = max(0, 1 - float(state["inflation"])) * 6
    return clamp(100 - high - low, 0, 100)


def employment_health(state: State) -> float:
    u = float(state["unemployment"])
    return clamp(100 - u * 2 - max(0, u - 18) * 2.5, 0, 100)


def tax_health(state: State) -> float:
    t = float(state["taxRate"])
    return clamp(100 - max(0, t - 24) * 8 - max(0, t - 34) * 6 - max(0, 16 - t) * 5 - max(0, 10 - t) * 5, 0, 100)


def resilience_health(state: State) -> float:
    hard = average([state["cybersecurity"], state["military"], state["diplomacy"]])
    productive = average([state["energy"], state["infrastructure"], state["technology"]])
    public = average([state["education"], state["healthcare"]])
    return clamp(hard * 0.24 + productive * 0.30 + public * 0.28 + float(state["environment"]) * 0.18, 0, 100)


def development_potential(state: State) -> float:
    human = float(state["education"]) * 0.55 + float(state["healthcare"]) * 0.45
    productive = float(state["technology"]) * 0.34 + float(state["infrastructure"]) * 0.33 + float(state["energy"]) * 0.33
    risk = float(state["cybersecurity"]) * 0.32 + float(state["environment"]) * 0.30 + float(state["diplomacy"]) * 0.24 + float(state["military"]) * 0.14
    return clamp(human * 0.34 + productive * 0.39 + risk * 0.27, 0, 100)


def growth_outlook(state: State) -> float:
    productivity = (
        float(state["education"]) * 0.25 + float(state["technology"]) * 0.25
        + float(state["infrastructure"]) * 0.20 + float(state["energy"]) * 0.15
        + float(state["healthcare"]) * 0.15
    )
    labor = clamp(100 - float(state["unemployment"]) * 2.2, 0, 100)
    fiscal = average([budget_health(state), fiscal_flow_health(state), debt_safety(state)])
    return clamp(productivity * 0.42 + labor * 0.20 + inflation_health(state) * 0.18 + fiscal * 0.20, 0, 100)


def event_safety(state: State) -> float:
    negatives = sum(1 for event in state.get("active_events", []) if event not in POSITIVE_EVENT_IDS)
    return clamp(100 - negatives * 25, 0, 100)


def population_trend_health(state: State) -> float:
    return clamp(50 + population_growth_rate(state) * 500_000, 0, 100)


def assess_health(state: State) -> dict[str, Any]:
    gh = gdp_health(state)
    bh = budget_health(state)
    ff = fiscal_flow_health(state)
    ds = debt_safety(state)
    pt = population_trend_health(state)
    ih = inflation_health(state)
    eh = employment_health(state)
    th = tax_health(state)
    rh = resilience_health(state)
    dp = development_potential(state)
    es = event_safety(state)

    groups = {
        "economicOutput": gh,
        "fiscal": clamp(bh * 0.28 + ff * 0.22 + ds * 0.50, 0, 100),
        "social": clamp(float(state["happiness"]) * 0.38 + pt * 0.16 + float(state["education"]) * 0.23 + float(state["healthcare"]) * 0.23, 0, 100),
        "pressureSafety": clamp(ih * 0.23 + eh * 0.23 + th * 0.16 + es * 0.14 + rh * 0.24, 0, 100),
    }
    values = list(groups.values())
    base = groups["economicOutput"] * 0.22 + groups["fiscal"] * 0.24 + groups["social"] * 0.24 + groups["pressureSafety"] * 0.20 + dp * 0.10
    weakest = min(values)
    weakness_penalty = max(0, 55 - weakest) * 0.55
    group_avg = average(values)
    imbalance = average(abs(v - group_avg) for v in values) * 0.20
    score = clamp(base - weakness_penalty - imbalance, 0, 100)

    critical: list[str] = []
    if gh < 25: critical.append("gdp")
    if bh < 20 or ff < 15: critical.append("budget")
    if ds < 25: critical.append("debt")
    if float(state["happiness"]) < 25: critical.append("happiness")
    if pt < 20 or float(state["population"]) < 100_000: critical.append("population")
    if ih < 25: critical.append("inflation")
    if eh < 25: critical.append("unemployment")
    if th < 25: critical.append("taxRate")
    if rh < 25: critical.append("resilience")
    if es < 35: critical.append("active_events")

    if float(state["gdp"]) <= 50 or float(state["population"]) <= 50_000 or score <= 15 or len(critical) >= 5:
        level = "collapsed"
    elif len(critical) >= 3 or score < 30:
        level = "critical"
    elif len(critical) >= 2 or score < 50:
        level = "crisis"
    elif len(critical) >= 1 or state.get("active_events") or score < 70:
        level = "warning"
    else:
        level = "stable"
    return {"score": score, "level": level, "criticalIndicators": critical, "groups": groups}


def potential_toward_target(value: float, target: float = 82, floor: float = 35) -> float:
    progress = clamp(value, floor, target) - floor
    score = (progress / max(1, target - floor)) * 100 + max(0, value - target) * 1.15
    return clamp(score, 0, 130)


def future_potential_bonus(state: State) -> float:
    raw = (
        potential_toward_target(float(state["technology"]), 78, 28) * 1.05
        + potential_toward_target(float(state["education"]), 82, 38) * 0.85
        + potential_toward_target(float(state["healthcare"]), 82, 38) * 0.80
        + potential_toward_target(float(state["infrastructure"]), 82, 35) * 0.80
        + potential_toward_target(float(state["energy"]), 82, 40) * 0.65
        + potential_toward_target(float(state["cybersecurity"]), 82, 35) * 0.65
        + potential_toward_target(float(state["environment"]), 82, 40) * 0.55
        + potential_toward_target(float(state["diplomacy"]), 78, 38) * 0.45
        + potential_toward_target(float(state["military"]), 75, 35) * 0.25
    )
    return min(raw, 520)


def recent_policy_penalty(state: State, policies: list[Policy]) -> float:
    categories = {p["id"]: p.get("category", "Khác") for p in policies}
    recent = [p for p in state.get("recentPolicies", []) if p in categories][-6:]
    if len(recent) < 2:
        return 0
    penalty = 0.0
    counts: dict[str, int] = {}
    for i, pid in enumerate(recent):
        category = categories.get(pid, "Khác")
        counts[category] = counts.get(category, 0) + 1
        if i == 0: continue
        previous = recent[i - 1]
        before = recent[max(0, i - 4):i]
        if previous == pid: penalty += 48
        if is_reversal(previous, pid): penalty += 78
        if pid in before: penalty += 38
        if any(is_reversal(x, pid) for x in before): penalty += 58
    dominant = max(counts.values(), default=0)
    threshold = int(len(recent) * 0.58 + 0.999)
    if dominant > threshold: penalty += (dominant - threshold) * 70
    econ = counts.get("Kinh tế", 0)
    if econ > 2: penalty += (econ - 2) * 75
    return min(650, penalty)


def evaluate_state(state: State, policies: list[Policy]) -> float:
    health = assess_health(state)
    if health["level"] == "collapsed":
        return -100000.0
    score = health["score"] * 8.4 + development_potential(state) * 1.45 + growth_outlook(state) * 0.75 + future_potential_bonus(state)
    ratio = float(state["debt"]) / max(1, float(state["gdp"]))
    score -= max(0, ratio - 0.5) * 420 + max(0, ratio - 0.85) * 760 + max(0, ratio - 1.15) * 1050
    score -= {"critical": 3000, "crisis": 1000, "warning": 210}.get(health["level"], 0)
    score -= recent_policy_penalty(state, policies)
    return round(score, 2)


def clamp_state(state: State) -> State:
    next_state = clone_state(state)
    next_state["gdp"] = max(1, float(next_state["gdp"]))
    next_state["budget"] = max(0, float(next_state["budget"]))
    next_state["debt"] = max(0, float(next_state["debt"]))
    next_state["taxRate"] = clamp(float(next_state["taxRate"]), 0, 45)
    next_state["population"] = max(0, round(float(next_state["population"])))
    for key in POSITIVE_KEYS:
        next_state[key] = clamp(float(next_state[key]), 0, 100)
    next_state["inflation"] = clamp(float(next_state["inflation"]), -2, 100)
    next_state["unemployment"] = clamp(float(next_state["unemployment"]), 0, 100)
    next_state["active_events"] = list(next_state.get("active_events", []))
    next_state["recentPolicies"] = list(next_state.get("recentPolicies", []))[-6:]
    next_state["month"] = int(next_state["month"])
    next_state["year"] = int(next_state["year"])
    return next_state


def apply_policy(state: State, policy: Policy) -> State:
    if float(state["budget"]) < float(policy.get("cost", 0)):
        return clone_state(state)
    next_state = clone_state(state)
    next_state["budget"] = float(next_state["budget"]) - float(policy.get("cost", 0))
    next_state["recentPolicies"] = (list(next_state.get("recentPolicies", [])) + [policy["id"]])[-6:]
    for key, value in policy.get("effect", {}).items():
        if key in next_state and isinstance(next_state[key], (int, float)) and isinstance(value, (int, float)):
            next_state[key] = float(next_state[key]) + float(value)
    return clamp_state(next_state)


def advance_month(state: State) -> State:
    current_event_count = sum(1 for e in state.get("active_events", []) if e not in POSITIVE_EVENT_IDS)
    next_state = clone_state(state)
    next_state["active_events"] = []
    next_state["recentPolicies"] = list(state.get("recentPolicies", []))[-6:]
    next_state["month"] = int(next_state["month"]) + 1
    if next_state["month"] > 12:
        next_state["month"] = 1
        next_state["year"] = int(next_state["year"]) + 1

    population_scale = max(0.1, float(state["population"]) / 1_000_000)
    base_job = 0.75 + float(state["education"]) * 0.004 + float(state["technology"]) * 0.003 + float(state["infrastructure"]) * 0.003
    tax_pressure = max(0, float(state["taxRate"]) - 24) * 0.009
    next_state["unemployment"] = float(next_state["unemployment"]) + clamp((population_scale - (base_job - tax_pressure)) * 0.45, -0.35, 0.6)

    supply = 0.8 + float(state["energy"]) * 0.004 + float(state["infrastructure"]) * 0.003 + float(state["technology"]) * 0.002
    price_pressure = clamp((population_scale - supply) * 0.2, -0.18, 0.35)
    energy_pressure = max(0, 45 - float(state["energy"])) * 0.006
    next_state["inflation"] = float(next_state["inflation"]) + (3 - float(state["inflation"])) * 0.04 + price_pressure + energy_pressure

    productivity = float(state["education"]) * 0.25 + float(state["technology"]) * 0.25 + float(state["infrastructure"]) * 0.20 + float(state["energy"]) * 0.15 + float(state["healthcare"]) * 0.15
    population_effect = clamp((population_scale - 1) * (productivity / 100) * 0.001, -0.001, 0.002)
    capability = float(state["technology"]) * 0.000006 + float(state["education"]) * 0.000003 + float(state["infrastructure"]) * 0.000004 + float(state["energy"]) * 0.000003
    growth = clamp(0.0015 + capability + population_effect - max(0, float(next_state["inflation"]) - 4) * 0.00045 - max(0, float(next_state["unemployment"]) - 6) * 0.00032 - max(0, float(state["taxRate"]) - 24) * 0.00035, -0.02, 0.012)
    next_state["gdp"] = float(next_state["gdp"]) * (1 + growth)
    _, _, balance = fiscal_metrics(next_state)
    next_state["budget"] = float(next_state["budget"]) + balance
    next_state["debt"] = float(next_state["debt"]) * 1.0025
    target = target_happiness(next_state, current_event_count)
    next_state["happiness"] = float(next_state["happiness"]) + (target - float(state["happiness"])) * 0.08
    next_state["population"] = float(next_state["population"]) * (1 + population_growth_rate(next_state))
    return clamp_state(next_state)


def transition(state: State, policy: Policy) -> State:
    return advance_month(apply_policy(state, policy))


def is_collapsed(state: State) -> bool:
    return assess_health(state)["level"] == "collapsed"


def strategic_distance(state: State) -> float:
    positive_targets = [
        (state["happiness"], 85, 1.25), (state["education"], 80, 1), (state["healthcare"], 80, 1),
        (state["energy"], 80, 0.85), (state["environment"], 80, 0.85), (state["technology"], 75, 0.85),
        (state["cybersecurity"], 80, 0.9), (state["infrastructure"], 80, 0.9), (state["diplomacy"], 75, 0.75),
    ]
    positive_gap = sum(max(0, target - float(value)) * weight for value, target, weight in positive_targets)
    inflation_gap = abs(float(state["inflation"]) - 2.5) * 4.2 + max(0, float(state["inflation"]) - 8) * 3
    unemployment_gap = max(0, float(state["unemployment"]) - 4) * 4.6
    ratio = float(state["debt"]) / max(1, float(state["gdp"]))
    debt_gap = max(0, ratio - 0.32) * 220 + max(0, ratio - 0.6) * 180
    fiscal_gap = max(0, 120 - float(state["budget"])) * 0.08
    tax_gap = max(0, float(state["taxRate"]) - 30) * 5 + max(0, 16 - float(state["taxRate"])) * 4.2 + max(0, 10 - float(state["taxRate"])) * 5
    return positive_gap + inflation_gap + unemployment_gap + debt_gap + fiscal_gap + tax_gap


def state_key(state: State) -> tuple[Any, ...]:
    def r(key: str, step: float) -> float:
        return round(float(state[key]) / step) * step
    return (
        r("gdp", 25), r("budget", 25), r("debt", 50), r("taxRate", 1), r("inflation", 0.5),
        r("unemployment", 0.5), r("happiness", 2), r("education", 2), r("healthcare", 2),
        r("energy", 2), r("environment", 2), r("technology", 2), r("cybersecurity", 2),
        r("infrastructure", 2), r("diplomacy", 2), tuple(state.get("active_events", [])),
    )


def available_policies(state: State, policies: list[Policy], limit: int = 14) -> list[Policy]:
    affordable = [p for p in policies if float(p.get("cost", 0)) <= float(state["budget"])]
    if not affordable:
        return []
    scored: list[tuple[float, Policy]] = []
    current = evaluate_state(state, policies)
    recent = list(state.get("recentPolicies", []))[-4:]
    for p in affordable:
        child = transition(state, p)
        gain = evaluate_state(child, policies) - current
        response = 0.0
        effect = p.get("effect", {})
        if state["unemployment"] > 10 and effect.get("unemployment", 0) < 0: response += 35
        if state["inflation"] > 7 and effect.get("inflation", 0) < 0: response += 35
        if state["healthcare"] < 40 and effect.get("healthcare", 0) > 0: response += 30
        if state["cybersecurity"] < 40 and effect.get("cybersecurity", 0) > 0: response += 30
        if state["environment"] < 45 and effect.get("environment", 0) > 0: response += 25
        if state["energy"] < 40 and effect.get("energy", 0) > 0: response += 25
        if p["id"] in recent: response -= 80
        if recent and is_reversal(recent[-1], p["id"]): response -= 90
        scored.append((gain + response - float(p.get("cost", 0)) * 0.02, p))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [p for _, p in scored[:limit]]


def transition_cost(before: State, policy: Policy, after: State, policies: list[Policy]) -> float:
    direct = max(0, float(policy.get("cost", 0))) / 48
    social_loss = sum(max(0, float(before[k]) - float(after[k])) * 0.75 for k in POSITIVE_KEYS)
    inflation_penalty = max(0, float(after["inflation"]) - float(before["inflation"])) * 3.2 + max(0, float(after["inflation"]) - 8) * 2.5
    unemployment_penalty = max(0, float(after["unemployment"]) - float(before["unemployment"])) * 3.8
    ratio_before = float(before["debt"]) / max(1, float(before["gdp"]))
    ratio_after = float(after["debt"]) / max(1, float(after["gdp"]))
    debt_penalty = max(0, ratio_after - ratio_before) * 240 + max(0, ratio_after - 0.45) * 180
    score_downside = max(0, evaluate_state(before, policies) - evaluate_state(after, policies)) / 28
    return max(0.05, direct + social_loss + inflation_penalty + unemployment_penalty + debt_penalty + score_downside)


@dataclass(slots=True)
class Node:
    state: State
    path: list[str]
    cost: float = 0.0
    depth: int = 0

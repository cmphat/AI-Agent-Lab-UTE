from __future__ import annotations
from typing import Any
from pydantic import BaseModel, Field

class AlgorithmRequest(BaseModel):
    algorithm: str
    state: dict[str, Any]
    policies: list[dict[str, Any]]
    depth: int = Field(default=3, ge=1, le=8)
    settings: dict[str, Any] = Field(default_factory=dict)

class BenchmarkRequest(AlgorithmRequest):
    months: int = Field(default=60, ge=1, le=120)

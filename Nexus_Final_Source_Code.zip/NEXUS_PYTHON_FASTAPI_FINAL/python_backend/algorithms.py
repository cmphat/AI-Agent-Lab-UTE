from __future__ import annotations

import heapq
import math
import random
import time
from collections import deque
from typing import Any, Callable

from .engine import (
    Node, State, Policy, apply_policy, assess_health, available_policies, average, clone_state,
    evaluate_state, is_collapsed, state_key, strategic_distance, transition, transition_cost,
)

SearchResult = dict[str, Any]
LRTA_MEMORY: dict[tuple[Any, ...], float] = {}


def _result(name: str, initial: State, projected: State, path: list[str], nodes: int, started: float,
            policies: list[Policy], algorithm_value: float | None = None, value_label: str | None = None,
            debug: dict[str, Any] | None = None, conditional_plan: dict[str, Any] | None = None,
            execution_mode: str = "planned") -> SearchResult:
    score = evaluate_state(projected, policies)
    return {
        "algorithm": name,
        "bestPolicies": path,
        "recommendedPolicyId": path[0] if path else None,
        "planPreview": path,
        "projectedState": projected,
        "score": score,
        "nodesExpanded": nodes,
        "runtimeMs": round((time.perf_counter() - started) * 1000, 2),
        "algorithmValue": score if algorithm_value is None else algorithm_value,
        "valueLabel": value_label or "Projected national score",
        "improvementReached": score > evaluate_state(initial, policies) + 5,
        "goalReached": score > evaluate_state(initial, policies) + 5,
        "effectiveDepth": len(path),
        "executionMode": execution_mode,
        "displayPolicies": path,
        "debug": debug or {},
        "conditionalPlan": conditional_plan,
    }


def _children(node: Node, policies: list[Policy], branch_limit: int = 12) -> list[Node]:
    children: list[Node] = []
    for policy in available_policies(node.state, policies, branch_limit):
        next_state = transition(node.state, policy)
        children.append(Node(next_state, node.path + [policy["id"]], node.cost + transition_cost(node.state, policy, next_state, policies), node.depth + 1))
    return children


def _best_node(initial: State) -> Node:
    return Node(clone_state(initial), [], 0.0, 0)


def bfs(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); root = _best_node(initial); best = root; nodes = 0
    queue = deque([root]); seen = {state_key(root.state)}
    while queue:
        node = queue.popleft(); nodes += 1
        if evaluate_state(node.state, policies) > evaluate_state(best.state, policies): best = node
        if node.depth >= depth or is_collapsed(node.state): continue
        for child in _children(node, policies, 12):
            key = state_key(child.state)
            if key in seen: continue
            seen.add(key); queue.append(child)
        if nodes >= 60_000: break
    return _result("BFS", initial, best.state, best.path, nodes, started, policies, debug={"frontierMode": "FIFO"})


def dfs(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); root = _best_node(initial); best = root; nodes = 0
    stack = [root]; seen_depth: dict[tuple[Any, ...], int] = {}
    while stack:
        node = stack.pop(); nodes += 1
        if evaluate_state(node.state, policies) > evaluate_state(best.state, policies): best = node
        if node.depth >= depth or is_collapsed(node.state): continue
        children = _children(node, policies, 12)
        for child in reversed(children):
            key = state_key(child.state)
            if seen_depth.get(key, 10**9) <= child.depth: continue
            seen_depth[key] = child.depth; stack.append(child)
        if nodes >= 80_000: break
    return _result("DFS", initial, best.state, best.path, nodes, started, policies, debug={"frontierMode": "LIFO"})


def ids(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); best = _best_node(initial); total_nodes = 0
    for limit in range(1, depth + 1):
        stack = [_best_node(initial)]
        while stack:
            node = stack.pop(); total_nodes += 1
            if evaluate_state(node.state, policies) > evaluate_state(best.state, policies): best = node
            if node.depth >= limit or is_collapsed(node.state): continue
            stack.extend(reversed(_children(node, policies, 11)))
            if total_nodes >= 90_000: break
        if total_nodes >= 90_000: break
    return _result("IDS", initial, best.state, best.path, total_nodes, started, policies, debug={"depthLimits": list(range(1, depth + 1))})


def ucs(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); root = _best_node(initial); best = root; nodes = 0; serial = 0
    heap: list[tuple[float, int, Node]] = [(0, serial, root)]; best_cost: dict[tuple[Any, ...], float] = {state_key(root.state): 0}
    while heap:
        cost, _, node = heapq.heappop(heap); nodes += 1
        if evaluate_state(node.state, policies) > evaluate_state(best.state, policies): best = node
        if node.depth >= depth or is_collapsed(node.state): continue
        for child in _children(node, policies, 12):
            key = state_key(child.state)
            if child.cost >= best_cost.get(key, math.inf): continue
            best_cost[key] = child.cost; serial += 1; heapq.heappush(heap, (child.cost, serial, child))
        if nodes >= 55_000: break
    return _result("UCS", initial, best.state, best.path, nodes, started, policies, algorithm_value=-best.cost, value_label="Negative accumulated path cost")


def greedy(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); root = _best_node(initial); best = root; nodes = 0; serial = 0
    heap: list[tuple[float, int, Node]] = [(strategic_distance(root.state), serial, root)]
    while heap:
        h, _, node = heapq.heappop(heap); nodes += 1
        if evaluate_state(node.state, policies) > evaluate_state(best.state, policies): best = node
        if node.depth >= depth or is_collapsed(node.state): continue
        for child in _children(node, policies, 12):
            serial += 1; heapq.heappush(heap, (strategic_distance(child.state), serial, child))
        if nodes >= 45_000: break
    return _result("Greedy Best-First", initial, best.state, best.path, nodes, started, policies, algorithm_value=-strategic_distance(best.state), value_label="Negative heuristic distance")


def astar(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); root = _best_node(initial); best = root; nodes = 0; serial = 0
    heap: list[tuple[float, int, Node]] = [(strategic_distance(root.state), serial, root)]
    best_g: dict[tuple[Any, ...], float] = {state_key(root.state): 0}
    best_f = strategic_distance(root.state)
    while heap:
        f, _, node = heapq.heappop(heap); nodes += 1
        if evaluate_state(node.state, policies) > evaluate_state(best.state, policies): best = node; best_f = f
        if node.depth >= depth or is_collapsed(node.state): continue
        for child in _children(node, policies, 12):
            key = state_key(child.state)
            if child.cost >= best_g.get(key, math.inf): continue
            best_g[key] = child.cost; serial += 1
            heapq.heappush(heap, (child.cost + strategic_distance(child.state), serial, child))
        if nodes >= 45_000: break
    return _result("A*", initial, best.state, best.path, nodes, started, policies, algorithm_value=best_f, value_label="f(n) = g(n) + h(n)", debug={"g": round(best.cost, 3), "h": round(strategic_distance(best.state), 3)})


def hill_climbing(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); current = _best_node(initial); best_score = evaluate_state(initial, policies); nodes = 0
    for _ in range(max(1, depth)):
        candidates = _children(current, policies, 18); nodes += len(candidates)
        if not candidates: break
        candidate = max(candidates, key=lambda n: evaluate_state(n.state, policies))
        score = evaluate_state(candidate.state, policies)
        if score <= best_score: break
        current, best_score = candidate, score
    return _result("Hill Climbing", initial, current.state, current.path, nodes, started, policies, debug={"localOptimum": True})


def local_beam(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); width = int(settings.get("beamWidth", 4)); beam = [_best_node(initial)]; best = beam[0]; nodes = 0
    for _ in range(max(1, depth)):
        candidates: list[Node] = []
        for node in beam:
            expanded = _children(node, policies, 12); nodes += len(expanded); candidates.extend(expanded)
        if not candidates: break
        candidates.sort(key=lambda n: evaluate_state(n.state, policies), reverse=True)
        dedup: list[Node] = []; keys = set()
        for node in candidates:
            key = state_key(node.state)
            if key in keys: continue
            keys.add(key); dedup.append(node)
            if len(dedup) >= width: break
        beam = dedup
        if beam and evaluate_state(beam[0].state, policies) > evaluate_state(best.state, policies): best = beam[0]
    return _result("Local Beam Search", initial, best.state, best.path, nodes, started, policies, debug={"beamWidth": width})


def simulated_annealing(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); rng = random.Random(20260627); current = _best_node(initial); best = current; nodes = 0
    iterations = int(settings.get("annealingIterations", max(180, depth * 180)))
    temperature = 250.0
    for i in range(iterations):
        candidates = available_policies(current.state, policies, 18)
        if not candidates: break
        policy = rng.choice(candidates); next_state = transition(current.state, policy); nodes += 1
        delta = evaluate_state(next_state, policies) - evaluate_state(current.state, policies)
        if delta >= 0 or rng.random() < math.exp(delta / max(0.001, temperature)):
            current = Node(next_state, current.path + [policy["id"]], current.cost, current.depth + 1)
            if evaluate_state(current.state, policies) > evaluate_state(best.state, policies): best = Node(clone_state(current.state), list(current.path), current.cost, current.depth)
        temperature *= 0.987
        if len(current.path) > max(4, depth * 3): current.path = current.path[-max(4, depth * 3):]
    preview = best.path[:max(1, depth)]
    projected = clone_state(initial)
    for pid in preview:
        p = next((x for x in policies if x["id"] == pid), None)
        if p: projected = transition(projected, p)
    return _result("Simulated Annealing", initial, projected, preview, nodes, started, policies, debug={"iterations": iterations, "finalTemperature": round(temperature, 4)})


def _shock_outcomes(state: State) -> list[tuple[str, State, float]]:
    outcomes: list[tuple[str, State, float]] = [("normal", clone_state(state), 0.45)]
    economic = clone_state(state); economic["inflation"] += 2.5; economic["unemployment"] += 2; economic["budget"] = max(0, economic["budget"] - 35)
    social = clone_state(state); social["happiness"] = max(0, social["happiness"] - 8); social["healthcare"] = max(0, social["healthcare"] - 3)
    security = clone_state(state); security["cybersecurity"] = max(0, security["cybersecurity"] - 8); security["diplomacy"] = max(0, security["diplomacy"] - 4)
    outcomes.extend([("economicShock", economic, 0.25), ("socialShock", social, 0.18), ("securityShock", security, 0.12)])
    return outcomes


def and_or(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); nodes = 0; conditional: dict[str, Any] = {}
    def solve(state: State, d: int) -> tuple[float, list[str], State]:
        nonlocal nodes
        nodes += 1
        if d <= 0 or is_collapsed(state): return evaluate_state(state, policies), [], state
        best_value = -math.inf; best_path: list[str] = []; best_state = state; best_branches = {}
        for policy in available_policies(state, policies, 8):
            base = transition(state, policy); branch_values = []; branch_plan = {}
            for label, outcome, probability in _shock_outcomes(base):
                value, subpath, terminal = solve(outcome, d - 1)
                branch_values.append(value); branch_plan[label] = {"probability": probability, "plan": subpath}
            robust = min(branch_values) * 0.7 + average(branch_values) * 0.3
            if robust > best_value:
                best_value = robust; best_path = [policy["id"]]; best_state = base; best_branches = branch_plan
        conditional.clear(); conditional.update(best_branches)
        return best_value, best_path, best_state
    value, path, projected = solve(initial, max(1, min(depth, 3)))
    return _result("AND-OR Search", initial, projected, path, nodes, started, policies, algorithm_value=value, value_label="Robust AND-OR value", conditional_plan=conditional)


def belief_state(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); nodes = 0; rng = random.Random(42)
    beliefs = [clone_state(initial)]
    for _ in range(4):
        s = clone_state(initial)
        s["inflation"] = max(-2, s["inflation"] + rng.uniform(-1.0, 1.8)); s["unemployment"] = max(0, s["unemployment"] + rng.uniform(-1, 2)); s["happiness"] = max(0, min(100, s["happiness"] + rng.uniform(-4, 3)))
        beliefs.append(s)
    path: list[str] = []
    for _ in range(max(1, depth)):
        candidates = available_policies(beliefs[0], policies, 12); best_policy = None; best_value = -math.inf
        for p in candidates:
            scores = [evaluate_state(transition(b, p), policies) for b in beliefs]; nodes += len(beliefs)
            robust = average(scores) - (max(scores) - min(scores)) * 0.22
            if robust > best_value: best_value = robust; best_policy = p
        if not best_policy: break
        path.append(best_policy["id"]); beliefs = [transition(b, best_policy) for b in beliefs]
    projected = max(beliefs, key=lambda s: evaluate_state(s, policies)) if beliefs else initial
    return _result("Belief-State Search", initial, projected, path, nodes, started, policies, algorithm_value=average(evaluate_state(b, policies) for b in beliefs), value_label="Expected belief-state value", debug={"beliefCount": len(beliefs)})


def lrta(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); current = clone_state(initial); path: list[str] = []; nodes = 0
    persistent = settings.get("lrtaMemoryMode", "persistent") == "persistent"
    memory = LRTA_MEMORY if persistent else {}
    for _ in range(max(1, depth)):
        key = state_key(current); best_policy = None; best_state = None; best_cost = math.inf
        for p in available_policies(current, policies, 14):
            nxt = transition(current, p); nodes += 1
            estimate = transition_cost(current, p, nxt, policies) + memory.get(state_key(nxt), strategic_distance(nxt))
            if estimate < best_cost: best_cost, best_policy, best_state = estimate, p, nxt
        if not best_policy or best_state is None: break
        memory[key] = best_cost; path.append(best_policy["id"]); current = best_state
    return _result("LRTA*", initial, current, path, nodes, started, policies, algorithm_value=memory.get(state_key(initial), strategic_distance(initial)), value_label="Learned real-time estimate", execution_mode="online", debug={"memorySize": len(memory), "persistent": persistent})


def _constraint_violation(state: State, strictness: str = "balanced") -> float:
    target = {"relaxed": 0.8, "balanced": 1.0, "strict": 1.2}.get(strictness, 1.0)
    ratio = state["debt"] / max(1, state["gdp"])
    return target * (
        max(0, state["inflation"] - 6) * 7 + max(0, state["unemployment"] - 9) * 6
        + max(0, 50 - state["happiness"]) * 3 + max(0, ratio - 0.55) * 250
        + max(0, 100 - state["budget"]) * 0.2 + max(0, 45 - resilience_score(state)) * 4
    )


def resilience_score(state: State) -> float:
    return average([state["education"], state["healthcare"], state["energy"], state["environment"], state["technology"], state["cybersecurity"], state["infrastructure"], state["diplomacy"]])


def constraint_propagation(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); strictness = settings.get("constraintStrictness", "balanced"); current = clone_state(initial); path = []; nodes = 0; pruned = 0
    for _ in range(max(1, depth)):
        domain = available_policies(current, policies, 18); ranked = []
        base_violation = _constraint_violation(current, strictness)
        for p in domain:
            nxt = transition(current, p); nodes += 1; v = _constraint_violation(nxt, strictness)
            if is_collapsed(nxt) or v > base_violation + 25: pruned += 1; continue
            ranked.append((v, -evaluate_state(nxt, policies), p, nxt))
        if not ranked: break
        ranked.sort(key=lambda x: (x[0], x[1])); _, _, p, current = ranked[0]; path.append(p["id"])
    return _result("Constraint Propagation", initial, current, path, nodes, started, policies, algorithm_value=-_constraint_violation(current, strictness), value_label="Negative constraint violation", debug={"prunedValues": pruned, "strictness": strictness})


def backtracking_csp(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); strictness = settings.get("constraintStrictness", "balanced"); nodes = 0; best_state = clone_state(initial); best_path: list[str] = []; best_objective = math.inf
    def backtrack(state: State, path: list[str], d: int) -> None:
        nonlocal nodes, best_state, best_path, best_objective
        nodes += 1
        objective = _constraint_violation(state, strictness) - evaluate_state(state, policies) * 0.02
        if objective < best_objective: best_objective, best_state, best_path = objective, clone_state(state), list(path)
        if d >= depth or nodes >= 9_000 or is_collapsed(state): return
        candidates = []
        for p in available_policies(state, policies, 10):
            nxt = transition(state, p)
            if path and p["id"] == path[-1]: continue
            candidates.append((_constraint_violation(nxt, strictness), p, nxt))
        candidates.sort(key=lambda x: x[0])
        for _, p, nxt in candidates[:8]: backtrack(nxt, path + [p["id"]], d + 1)
    backtrack(initial, [], 0)
    return _result("Backtracking CSP", initial, best_state, best_path, nodes, started, policies, algorithm_value=-best_objective, value_label="CSP objective", debug={"backtracks": max(0, nodes - len(best_path))})


def min_conflicts(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); rng = random.Random(77); months = max(1, depth); candidates = available_policies(initial, policies, 16)
    if not candidates: return _result("Min-Conflicts CSP", initial, initial, [], 0, started, policies)
    assignment = [rng.choice(candidates)["id"] for _ in range(months)]; nodes = 0
    def simulate(path: list[str]) -> State:
        state = clone_state(initial)
        for pid in path:
            p = next((x for x in policies if x["id"] == pid), None)
            if p: state = transition(state, p)
        return state
    best_path = list(assignment); best_state = simulate(best_path); best_conflict = _constraint_violation(best_state, settings.get("constraintStrictness", "balanced"))
    for _ in range(320):
        idx = rng.randrange(months); local_best = None
        for p in candidates:
            test = list(assignment); test[idx] = p["id"]; state = simulate(test); nodes += 1
            conflict = _constraint_violation(state, settings.get("constraintStrictness", "balanced"))
            objective = conflict - evaluate_state(state, policies) * 0.01
            if local_best is None or objective < local_best[0]: local_best = (objective, test, state, conflict)
        if local_best:
            _, assignment, state, conflict = local_best
            if conflict < best_conflict: best_conflict, best_path, best_state = conflict, list(assignment), clone_state(state)
            if conflict <= 0.1: break
    return _result("Min-Conflicts CSP", initial, best_state, best_path, nodes, started, policies, algorithm_value=-best_conflict, value_label="Negative conflicts", debug={"finalConflicts": round(best_conflict, 3)})


def _adversarial_actions(state: State, policies: list[Policy], max_actions: int) -> list[Policy]:
    return available_policies(state, policies, max_actions)


def _bad_outcomes(state: State) -> list[State]:
    return [x[1] for x in _shock_outcomes(state)[1:]]


def minimax(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); nodes = 0; max_actions = int(settings.get("maxMinActions", 4))
    def max_value(state: State, d: int) -> float:
        nonlocal nodes; nodes += 1
        if d <= 0 or is_collapsed(state): return evaluate_state(state, policies)
        return max((min_value(transition(state, p), d - 1) for p in _adversarial_actions(state, policies, max_actions)), default=evaluate_state(state, policies))
    def min_value(state: State, d: int) -> float:
        nonlocal nodes; nodes += 1
        if d <= 0 or is_collapsed(state): return evaluate_state(state, policies)
        return min((max_value(s, d - 1) for s in _bad_outcomes(state)), default=evaluate_state(state, policies))
    best_p = None; best_state = initial; best_value = -math.inf
    for p in _adversarial_actions(initial, policies, max_actions):
        nxt = transition(initial, p); value = min_value(nxt, max(0, depth - 1))
        if value > best_value: best_value, best_p, best_state = value, p, nxt
    path = [best_p["id"]] if best_p else []
    return _result("Minimax", initial, best_state, path, nodes, started, policies, algorithm_value=best_value, value_label="Minimax value")


def alpha_beta(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); nodes = 0; cutoffs = 0; max_actions = int(settings.get("maxMinActions", 4))
    def max_value(state: State, d: int, alpha: float, beta: float) -> float:
        nonlocal nodes, cutoffs; nodes += 1
        if d <= 0 or is_collapsed(state): return evaluate_state(state, policies)
        value = -math.inf
        for p in _adversarial_actions(state, policies, max_actions):
            value = max(value, min_value(transition(state, p), d - 1, alpha, beta)); alpha = max(alpha, value)
            if alpha >= beta: cutoffs += 1; break
        return value
    def min_value(state: State, d: int, alpha: float, beta: float) -> float:
        nonlocal nodes, cutoffs; nodes += 1
        if d <= 0 or is_collapsed(state): return evaluate_state(state, policies)
        value = math.inf
        for s in _bad_outcomes(state):
            value = min(value, max_value(s, d - 1, alpha, beta)); beta = min(beta, value)
            if alpha >= beta: cutoffs += 1; break
        return value
    best_p = None; best_state = initial; best_value = -math.inf; alpha = -math.inf
    for p in _adversarial_actions(initial, policies, max_actions):
        nxt = transition(initial, p); value = min_value(nxt, max(0, depth - 1), alpha, math.inf)
        if value > best_value: best_value, best_p, best_state = value, p, nxt
        alpha = max(alpha, best_value)
    path = [best_p["id"]] if best_p else []
    return _result("Alpha-Beta", initial, best_state, path, nodes, started, policies, algorithm_value=best_value, value_label="Alpha-Beta value", debug={"cutoffs": cutoffs})


def expectimax(initial: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    started = time.perf_counter(); nodes = 0; max_actions = int(settings.get("maxMinActions", 4))
    def max_value(state: State, d: int) -> float:
        nonlocal nodes; nodes += 1
        if d <= 0 or is_collapsed(state): return evaluate_state(state, policies)
        return max((chance_value(transition(state, p), d - 1) for p in _adversarial_actions(state, policies, max_actions)), default=evaluate_state(state, policies))
    def chance_value(state: State, d: int) -> float:
        nonlocal nodes; nodes += 1
        if d <= 0 or is_collapsed(state): return evaluate_state(state, policies)
        return sum(prob * max_value(outcome, d - 1) for _, outcome, prob in _shock_outcomes(state))
    best_p = None; best_state = initial; best_value = -math.inf
    for p in _adversarial_actions(initial, policies, max_actions):
        nxt = transition(initial, p); value = chance_value(nxt, max(0, depth - 1))
        if value > best_value: best_value, best_p, best_state = value, p, nxt
    path = [best_p["id"]] if best_p else []
    return _result("Expectimax", initial, best_state, path, nodes, started, policies, algorithm_value=best_value, value_label="Expected utility")


ALGORITHMS: dict[str, Callable[[State, int, list[Policy], dict[str, Any]], SearchResult]] = {
    "BFS": bfs,
    "DFS": dfs,
    "IDS": ids,
    "UCS": ucs,
    "Greedy Best-First": greedy,
    "A*": astar,
    "Hill Climbing": hill_climbing,
    "Local Beam Search": local_beam,
    "Simulated Annealing": simulated_annealing,
    "AND-OR Search": and_or,
    "Belief-State Search": belief_state,
    "LRTA*": lrta,
    "Constraint Propagation": constraint_propagation,
    "Backtracking CSP": backtracking_csp,
    "Min-Conflicts CSP": min_conflicts,
    "Minimax": minimax,
    "Alpha-Beta": alpha_beta,
    "Expectimax": expectimax,
}


def run_algorithm(name: str, state: State, depth: int, policies: list[Policy], settings: dict[str, Any]) -> SearchResult:
    try:
        fn = ALGORITHMS[name]
    except KeyError as exc:
        raise ValueError(f"Unknown algorithm: {name}") from exc
    return fn(clone_state(state), max(1, int(depth)), policies, settings)

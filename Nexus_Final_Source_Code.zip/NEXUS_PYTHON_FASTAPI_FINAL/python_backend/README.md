# NEXUS Python AI Engine

FastAPI service containing all 18 AI algorithms. The React/TypeScript application remains the presentation layer; algorithm execution and the 5-year benchmark are performed by Python.

## Run

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r python_backend\requirements.txt
python -m uvicorn python_backend.app:app --host 127.0.0.1 --port 8000
```

Health check: `http://127.0.0.1:8000/api/health`

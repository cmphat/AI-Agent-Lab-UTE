from __future__ import annotations
import json
from pathlib import Path

from .algorithms import ALGORITHMS, run_algorithm

ROOT = Path(__file__).resolve().parents[1]

STATE = {
    "gdp": 1000.0, "budget": 500.0, "debt": 200.0, "taxRate": 20.0,
    "inflation": 5.0, "unemployment": 8.0, "happiness": 70.0,
    "education": 50.0, "healthcare": 50.0, "energy": 60.0,
    "environment": 60.0, "military": 40.0, "technology": 30.0,
    "cybersecurity": 35.0, "infrastructure": 45.0, "diplomacy": 50.0,
    "population": 1_000_000, "month": 1, "year": 2026,
    "active_events": [], "recentPolicies": [],
}
POLICIES = [
    {"id": "job_program", "name": "Jobs", "category": "Xã hội", "cost": 75, "effect": {"unemployment": -2}},
    {"id": "inflation_control", "name": "Inflation", "category": "Kinh tế", "cost": 35, "effect": {"inflation": -2, "unemployment": 0.6}},
    {"id": "edu_invest", "name": "Education", "category": "Xã hội", "cost": 80, "effect": {"education": 7}},
    {"id": "health_invest", "name": "Health", "category": "Xã hội", "cost": 85, "effect": {"healthcare": 7}},
    {"id": "green_energy", "name": "Green", "category": "Hạ tầng", "cost": 150, "effect": {"energy": 7, "environment": 9}},
    {"id": "cybersec", "name": "Cyber", "category": "Công nghệ", "cost": 70, "effect": {"cybersecurity": 9}},
]
SETTINGS = {"beamWidth": 3, "annealingIterations": 120, "maxMinActions": 3, "constraintStrictness": "balanced", "lrtaMemoryMode": "temporary"}

for name in ALGORITHMS:
    result = run_algorithm(name, STATE, 2, POLICIES, SETTINGS)
    assert result["algorithm"] == name
    assert "projectedState" in result
    assert isinstance(result["nodesExpanded"], int)
    print(f"PASS {name:24s} score={result['score']:8.2f} nodes={result['nodesExpanded']}")
print(f"All {len(ALGORITHMS)} Python algorithms passed.")

from __future__ import annotations

import time
from collections import Counter
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .algorithms import ALGORITHMS, run_algorithm
from .engine import apply_policy, assess_health, available_policies, clone_state, evaluate_state, is_collapsed, advance_month
from .schemas import AlgorithmRequest, BenchmarkRequest

app = FastAPI(title="NEXUS Python AI Engine", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {"status": "ok", "engine": "python", "algorithms": len(ALGORITHMS), "version": "1.0.0"}

@app.get("/api/algorithms")
def algorithm_names():
    return {"algorithms": list(ALGORITHMS.keys())}

@app.post("/api/run")
def run(request: AlgorithmRequest):
    try:
        return run_algorithm(request.algorithm, request.state, request.depth, request.policies, request.settings)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Python AI engine failed: {exc}") from exc

@app.post("/api/benchmark/algorithm")
def benchmark_algorithm(request: BenchmarkRequest):
    current = clone_state(request.state)
    total_runtime = 0.0
    total_nodes = 0
    completed = 0
    no_action = 0
    usage: Counter[str] = Counter()
    health_scores = [assess_health(current)["score"]]
    collapse_reasons: list[str] = []
    wall_start = time.perf_counter()

    try:
        benchmark_settings = dict(request.settings)
        # The 5-year comparison runs an algorithm up to 60 times. Keep the
        # algorithmic identity but cap stochastic iteration counts so the UI
        # remains responsive on normal student laptops.
        benchmark_settings["annealingIterations"] = min(120, int(benchmark_settings.get("annealingIterations", 120)))
        benchmark_depth = min(int(request.depth), 2)

        for month in range(1, request.months + 1):
            result = run_algorithm(request.algorithm, current, benchmark_depth, request.policies, benchmark_settings)
            total_runtime += float(result["runtimeMs"])
            total_nodes += int(result["nodesExpanded"])
            policy_id = result.get("recommendedPolicyId")
            policy = next((p for p in request.policies if p.get("id") == policy_id), None)
            if policy and float(policy.get("cost", 0)) <= float(current["budget"]):
                current = apply_policy(current, policy)
                usage[policy_id] += 1
            else:
                no_action += 1
            current = advance_month(current)
            completed = month
            health_scores.append(assess_health(current)["score"])
            if is_collapsed(current):
                collapse_reasons = assess_health(current)["criticalIndicators"] or ["system"]
                break
    except Exception as exc:
        return {
            "algorithm": request.algorithm,
            "totalRuntimeMs": round(total_runtime, 2),
            "totalWallTimeMs": round((time.perf_counter() - wall_start) * 1000, 2),
            "totalNodesExpanded": total_nodes,
            "finalScore": -100000,
            "finalStability": round(assess_health(current)["score"], 1),
            "avgStabilityDeviation": 100,
            "minStability": round(min(health_scores), 1),
            "maxMonthlyStabilityDrop": 100,
            "completedMonths": completed,
            "policyActionMonths": sum(usage.values()),
            "noActionMonths": no_action,
            "uniquePolicyCount": len(usage),
            "policyDiversity": 0,
            "topPolicyIds": [],
            "finalState": current,
            "collapsedAtMonth": completed if is_collapsed(current) else None,
            "collapseReasons": collapse_reasons,
            "error": str(exc),
        }

    deviations = [abs(health_scores[i] - health_scores[i - 1]) for i in range(1, len(health_scores))]
    drops = [max(0, health_scores[i - 1] - health_scores[i]) for i in range(1, len(health_scores))]
    action_months = sum(usage.values())
    return {
        "algorithm": request.algorithm,
        "totalRuntimeMs": round(total_runtime, 2),
        "totalWallTimeMs": round((time.perf_counter() - wall_start) * 1000, 2),
        "totalNodesExpanded": total_nodes,
        "finalScore": round(evaluate_state(current, request.policies), 1),
        "finalStability": round(assess_health(current)["score"], 1),
        "avgStabilityDeviation": round(sum(deviations) / max(1, len(deviations)), 2),
        "minStability": round(min(health_scores), 1),
        "maxMonthlyStabilityDrop": round(max(drops, default=0), 2),
        "completedMonths": completed,
        "policyActionMonths": action_months,
        "noActionMonths": no_action,
        "uniquePolicyCount": len(usage),
        "policyDiversity": round((len(usage) / action_months) * 100, 1) if action_months else 0,
        "topPolicyIds": [pid for pid, _ in usage.most_common(3)],
        "finalState": current,
        "collapsedAtMonth": completed if is_collapsed(current) else None,
        "collapseReasons": collapse_reasons,
    }

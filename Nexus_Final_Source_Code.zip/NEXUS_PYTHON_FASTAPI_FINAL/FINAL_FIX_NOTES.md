# NEXUS – Final collapse and reporting fix

## Fixed behavior

1. The simulator stops immediately at the first month where the nation reaches the `collapsed` health level.
2. A long time jump no longer continues after collapse. Example: a requested 120-month run may stop after month 17 and records `requestedMonths = 120`, `completedMonths = 17`.
3. After collapse, time controls and policy/event state changes are locked until Reset is used.
4. A collapse dialog shows:
   - exact collapse date;
   - national score and collapse causes;
   - requested versus actually completed duration;
   - every simulation run in the current session;
   - the complete month-by-month timeline of the run that caused collapse.
5. The Reports page now shows every simulation run, not only the latest five states.
6. Each run stores its start/end state and every monthly snapshot, including events, score, GDP, budget, debt, inflation, unemployment, happiness and stability.
7. Copy and Export MD include the complete run history and all monthly rows.
8. Reset clears state, monthly history, simulation-run history and the collapse notice.

## Verification

The following commands passed:

```bash
npm run lint
npm run test:simulation
npm run test:algorithms
npm run build
```

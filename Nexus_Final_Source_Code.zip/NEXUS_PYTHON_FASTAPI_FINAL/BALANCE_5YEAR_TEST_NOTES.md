# 5-Year Policy/Event Balance Test Notes

## Test setup
- Scenario: `Khủng hoảng toàn diện` = initial state + `recession` + `protest`.
- Horizon: 60 months / 5 years.
- Events: enabled, seeded RNG, 40 seeds.
- Stress tests: 5-month bad-policy runs, 60-month spam runs, single-event recovery tests.

## Main adjustments made

### State / scoring
- Added tax burden into national health scoring, so high tax rates no longer look like a free win just because they raise monthly revenue.
- Added system resilience into pressure/safety scoring using energy, infrastructure, technology, cybersecurity, military, diplomacy, environment, education and healthcare.
- Positive events (`boom`, `tech_breakthrough`, `trade_pact`) are no longer counted as crisis pressure in health scoring or happiness recovery.
- Negative active events now create stronger short-term pressure on happiness and health score.

### Monthly dynamics
- High tax pressure now affects employment and GDP growth earlier and more strongly.
- Tax comfort in target happiness is stricter, so tax spam produces social backlash.

### Policy changes
- `tax_up`: now has immediate happiness backlash: `happiness -3`.
- `tax_down`: now gives mild immediate relief: `happiness +1`.
- `austerity`: now has a clearer social/services downside: `happiness -1.2`, stronger degradation of education/healthcare/infrastructure.
- Emergency response policies were softened so they help recovery but do not instantly erase the crisis.

### Event changes
- Bad events were strengthened moderately after policy responses were added, but they still avoid direct GDP edits.
- Good events are allowed to be beneficial instead of being penalized by generic `active_events` logic.

## Final empirical outcomes

### 5-month bad-policy check
Starting crisis score: 77.
- Bad pattern average after 5 months: 75.3.
- Borrow spam average after 5 months: 69.7.
- Tax-up spam average after 5 months: 74.8.
- Austerity spam average after 5 months: 74.15.
- Naive/random average after 5 months: 73.85.

This satisfies the short-term criterion: bad choices now reduce score within 5 months on average, and longer spam creates crisis/collapse risk.

### 60-month strategy comparison, events enabled
- Policy-aware greedy/lookahead strategy: avg score 72.33, no collapse.
- No-policy baseline: avg score 61.8, no collapse but weak resilience and poor recovery.
- Naive/random strategy: avg score 35.9, 6 collapses / 40 seeds.
- Bad cyclic strategy: avg score 25.57, 31 collapses / 40 seeds.
- Borrow spam: avg score 40.8, 9 collapses / 40 seeds.
- Tax spam: avg score 34.48, 8 collapses / 40 seeds.
- Austerity spam: avg score 14.47, 38 collapses / 40 seeds.

This satisfies the AI-differentiation criterion: smarter policy selection clearly beats naive, bad and spam strategies over 5 years.

### Crisis response pacing
Single-event + matching response policy generally recovers over 2-3 monthly ticks rather than becoming overly positive immediately. Example score paths from base 81:
- Pandemic + emergency healthcare: 74 -> 77 -> 78 -> 78.
- War + ceasefire: 78 -> 78 -> 80 -> 80.
- Oil crisis + resource deal: 78 -> 79 -> 80 -> 80.
- Recession + stimulus: 80 -> 79 -> 80 -> 81.
- Supply chain + stabilization: 79 -> 79 -> 80 -> 80.

## Remaining balance notes
- Cyberattack, disaster and climate are more dangerous over repeated occurrence than as one-off events. This is acceptable because their main threat is cumulative erosion of resilience.
- Welfare spam is no longer a winning strategy because it drains budget and does not repair education, healthcare, energy, infrastructure or cybersecurity.
- Borrow, tax-up and austerity are now dangerous when spammed.

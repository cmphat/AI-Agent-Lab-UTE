# Logic Rework — 18 AI Algorithms

## Đã loại bỏ

- Xóa hoàn toàn `createGenericSearch()` và mọi kết quả giả lập bằng hệ số node hoặc `Math.random()`.

## Đã triển khai riêng

- BFS: FIFO frontier.
- DFS: recursive depth-first traversal.
- IDS: repeated depth-limited DFS.
- UCS: priority queue by cumulative transition cost.
- Greedy Best-First: priority by strategic heuristic.
- A*: `f(n) = g(n) + h(n)`.
- Hill Climbing: best-improving neighbor with local-optimum stop.
- Local Beam Search: keeps k best states per level.
- Simulated Annealing: temperature, cooling and Metropolis acceptance with seeded RNG.
- AND-OR Search: policy OR nodes and nondeterministic outcome AND nodes.
- Belief-State Search: searches over sets of plausible states.
- LRTA*: online heuristic learning table.
- Constraint Propagation: AC-3 arc consistency.
- Backtracking CSP: MRV and forward checking.
- Min-Conflicts CSP: complete assignment repair.
- Minimax: MAX policy / MIN crisis game tree.
- Alpha-Beta: Minimax-equivalent value with pruning.
- Expectimax: probability-weighted chance nodes.

## UI mới

- Nút `Xem mã giả / View Pseudocode` cạnh phần chọn thuật toán.
- Mã giả song ngữ cho đủ 18 thuật toán.
- Hiển thị nhóm thuật toán, cách áp dụng, độ phức tạp.
- Kết quả hiển thị độ sâu thực thi và trạng thái đạt mục tiêu.

## Sửa logic mô phỏng

- Giới hạn lạm phát tối thiểu ở -5% thay vì -100%.
- Clamp thêm GDP, ngân sách, nợ, dân số và cybersecurity.
- Sửa chính sách giảm thuế bị trừ ngân sách hai lần.
- Chuẩn hóa áp dụng sự kiện qua `applyEventToState()`.
- Điều chỉnh tăng ngân sách hàng tháng về mức hợp lý hơn.
- Nâng cấp hàm đánh giá với trọng số xã hội, chiến lược, kinh tế và phạt rủi ro.

## Kiểm tra tự động

```bash
npm run lint
npm run test:algorithms
npm run build
```

Smoke test xác nhận:

- Đủ 18 thuật toán.
- Mỗi thuật toán có mã giả.
- Kết quả tái lập với cùng đầu vào.
- Không có score/runtime vô hạn hoặc NaN.
- Alpha-Beta giữ nguyên giá trị Minimax nhưng mở rộng ít nút hơn.

## Time simulation and state persistence rework

- Added exact `advanceTime(months)` simulation. A one-year jump executes twelve individual monthly transitions and records all twelve history snapshots.
- Added `+1 month`, `+1 quarter`, and `+1 year` controls in the application header.
- Monthly random events are limited to at most one event per month, selected by probability weight. Events no longer accumulate forever in `active_events`.
- Added bounded macroeconomic dynamics: GDP growth, tax revenue, operating costs, debt interest, inflation mean reversion, employment changes, and social/stability consequences.
- The selected AI algorithm and lookahead depth now live in `GameProvider` and are persisted to `localStorage`, so navigating through the sidebar no longer resets the selector to A*.
- Replaced the hard-coded green “Stable” sidebar status with `assessNationHealth()`, a 0–100 operational health index with five levels: Stable, Warning, Crisis, Critical, and Collapsed.
- Added `npm run test:simulation` covering month/year rollover, one-year progression, event expiry, and catastrophic-state classification.


## Time milestone dropdown update

- Replaced the three separate time buttons with one wide dropdown selector.
- Presets: 1 month, 1 quarter, 1 year, 2 years, 5 years, 10 years, then every 5 years from 15 to 100 years.
- The control previews the exact target month/year and the number of monthly simulation steps.
- Long jumps still execute month-by-month, so economics, debt, social indicators, random events and history remain correct.
- The chosen milestone is saved in localStorage.
- The chart is downsampled only for rendering after long simulations; the full state history is retained.

# LRTA* Online Learning Update

## Mục tiêu sửa
- Giữ nguyên giao diện và các quy tắc game đã xây dựng.
- Riêng LRTA* không còn hiển thị/thi hành như một kế hoạch cố định nhiều tháng.
- Với độ sâu dự báo = 5, LRTA* chỉ chốt chính sách hiện tại; 4 bước còn lại được xem là chưa biết vì sẽ được tính lại sau mỗi tháng.

## Logic mới của LRTA*
1. Khi bấm chạy mô phỏng LRTA*, thuật toán chỉ tính chính sách áp dụng ngay ở tháng hiện tại.
2. Giao diện kết quả hiển thị:
   - Ô 1: chính sách sẽ áp dụng.
   - Các ô còn lại đến đúng độ sâu dự báo: dấu `?`.
3. Khi bấm thực thi kế hoạch LRTA*, hệ thống chạy đủ số tháng theo độ sâu dự báo.
4. Trước mỗi tháng, LRTA* quan sát lại trạng thái hiện tại, bao gồm cả `active_events` do khủng hoảng tháng trước để lại.
5. LRTA* cập nhật bảng heuristic H(s), sau đó chọn chính sách kế tiếp.
6. Nếu có khủng hoảng xảy ra trong lúc thực thi, LRTA* không dùng lại kế hoạch cũ mà nhìn lại trạng thái mới rồi tính tiếp.
7. Nếu quốc gia sụp đổ theo luật cũ, quá trình vẫn dừng và báo sụp đổ như trước.

## File đã chỉnh
- `src/core/algorithms.ts`
- `src/core/types.ts`
- `src/core/GameProvider.tsx`
- `src/pages/AILab.tsx`
- `src/core/algorithmDocs.ts`

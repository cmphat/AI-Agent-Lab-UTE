import { ReactNode, useEffect, useMemo, useState } from 'react';
import { useGame } from '../../core/GameProvider';
import { useLanguage } from '../../core/LanguageProvider';
import { assessNationHealth, evaluateState } from '../../core/state';
import {
  Home,
  Layers,
  Activity,
  Settings,
  Info,
  Briefcase,
  Moon,
  Sun,
  Server,
  Beaker,
  Languages,
  FastForward,
  ChevronDown,
  AlertOctagon,
  FileText,
  RotateCcw,
  X,
} from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

interface LayoutProps {
  children: ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const healthStyles = {
  stable: {
    text: 'text-emerald-500',
    bar: 'bg-emerald-500',
    glow: 'shadow-[0_0_8px_rgba(16,185,129,0.45)]',
  },
  warning: {
    text: 'text-amber-500',
    bar: 'bg-amber-500',
    glow: 'shadow-[0_0_8px_rgba(245,158,11,0.45)]',
  },
  crisis: {
    text: 'text-orange-500',
    bar: 'bg-orange-500',
    glow: 'shadow-[0_0_8px_rgba(249,115,22,0.45)]',
  },
  critical: {
    text: 'text-red-500',
    bar: 'bg-red-500',
    glow: 'shadow-[0_0_8px_rgba(239,68,68,0.5)]',
  },
  collapsed: {
    text: 'text-rose-600',
    bar: 'bg-rose-600',
    glow: 'shadow-[0_0_8px_rgba(225,29,72,0.55)]',
  },
} as const;

const TIME_JUMP_OPTIONS = [
  { months: 1, key: 'oneMonth' },
  { months: 3, key: 'oneQuarter' },
  { months: 12, key: 'oneYear' },
  { months: 24, key: 'twoYears' },
  { months: 60, key: 'fiveYears' },
  { months: 120, key: 'tenYears' },
  ...Array.from({ length: 18 }, (_, index) => ({
    months: (15 + index * 5) * 12,
    key: null,
  })),
] as const;

export const Layout = ({ children, activeTab, setActiveTab }: LayoutProps) => {
  const {
    theme,
    toggleTheme,
    state,
    advanceTime,
    simulationRuns,
    isCollapsed,
    collapseNotice,
    dismissCollapseNotice,
    reset,
  } = useGame();
  const { language, toggleLanguage, t, eventName, metricName } = useLanguage();
  const health = assessNationHealth(state);
  const healthStyle = healthStyles[health.level];
  const [selectedAdvanceMonths, setSelectedAdvanceMonths] = useState<number>(() => {
    const stored = Number(localStorage.getItem('nation-time-jump-months'));
    return TIME_JUMP_OPTIONS.some((option) => option.months === stored) ? stored : 1;
  });

  useEffect(() => {
    localStorage.setItem('nation-time-jump-months', String(selectedAdvanceMonths));
  }, [selectedAdvanceMonths]);

  const targetDate = useMemo(() => {
    const currentMonthIndex = state.year * 12 + (state.month - 1);
    const targetMonthIndex = currentMonthIndex + selectedAdvanceMonths;
    return {
      month: (targetMonthIndex % 12) + 1,
      year: Math.floor(targetMonthIndex / 12),
    };
  }, [selectedAdvanceMonths, state.month, state.year]);

  const collapseRun = useMemo(() => {
    if (!collapseNotice?.runId) return [...simulationRuns].reverse().find((run) => run.status === 'collapsed');
    return simulationRuns.find((run) => run.id === collapseNotice.runId);
  }, [collapseNotice?.runId, simulationRuns]);

  const formatTimeOption = (months: number, key: string | null) => {
    if (key) return t(`layout.timeOption.${key}`);
    const years = months / 12;
    return language === 'vi'
      ? `${years} năm (${months} tháng)`
      : `${years} years (${months} months)`;
  };

  const formatDate = (month: number, year: number) =>
    `${language === 'vi' ? 'T' : 'M'}${month.toString().padStart(2, '0')}/${year}`;

  const formatReason = (reason: string) =>
    reason === 'system'
      ? (language === 'vi' ? 'Chỉ số vận hành tổng thể xuống mức 0–10%' : 'Overall operational health fell to 0–10%')
      : metricName(reason);

  const navItems = [
    { id: 'overview', icon: Home, label: t('nav.overview') },
    { id: 'policies', icon: Briefcase, label: t('nav.policies') },
    { id: 'ai-lab', icon: Beaker, label: t('nav.aiLab') },
    { id: 'compare', icon: Layers, label: t('nav.compare') },
    { id: 'scenarios', icon: Activity, label: t('nav.scenarios') },
    { id: 'reports', icon: Server, label: t('nav.reports') },
    { id: 'settings', icon: Settings, label: t('nav.settings') },
    { id: 'about', icon: Info, label: t('nav.about') },
  ];

  return (
    <div className="min-h-screen flex w-full bg-background text-foreground transition-colors duration-200">
      <aside className="w-64 border-r border-border bg-card flex flex-col transition-colors duration-200">
        <div className="p-6 border-b border-border flex items-center gap-3">
          <div className="w-8 h-8 bg-primary rounded flex items-center justify-center font-bold text-primary-foreground">AI</div>
          <h1 className="text-lg font-bold tracking-tight text-foreground leading-tight">
            NEXUS
            <br />
            <span className="text-[10px] font-normal text-primary opacity-80 uppercase tracking-widest">
              {t('app.subtitle')}
            </span>
          </h1>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2 rounded text-sm transition-all duration-200',
                  active
                    ? 'bg-muted text-foreground'
                    : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground',
                )}
              >
                <Icon size={18} />
                <span className="text-sm uppercase font-semibold tracking-wider text-left">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-border">
          <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground mb-2 font-bold tracking-wider">
            <span>{t('layout.systemHealth')}</span>
            <span className={cn('text-right', healthStyle.text)}>
              {t(`layout.health.${health.level}`)} · {Math.round(health.score)}%
            </span>
          </div>
          <div
            className="w-full h-1.5 bg-background rounded-full mb-4 overflow-hidden"
            title={`${t(`layout.health.${health.level}`)}: ${Math.round(health.score)}/100`}
          >
            <div
              className={cn('h-full rounded-full transition-all duration-500', healthStyle.bar, healthStyle.glow)}
              style={{ width: `${Math.max(2, health.score)}%` }}
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={toggleTheme}
              className="flex items-center justify-center gap-2 w-full px-3 py-2 text-xs font-bold rounded border border-border hover:border-primary text-muted-foreground hover:text-foreground transition-colors bg-muted"
              title={theme === 'dark' ? t('layout.lightMode') : t('layout.darkMode')}
            >
              {theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
              {theme === 'dark' ? t('layout.lightMode') : t('layout.darkMode')}
            </button>

            <button
              type="button"
              onClick={toggleLanguage}
              className="flex items-center justify-center gap-2 w-full px-3 py-2 text-xs font-bold rounded border border-border hover:border-primary text-muted-foreground hover:text-foreground transition-colors bg-muted"
              title={language === 'vi' ? t('layout.switchToEnglish') : t('layout.switchToVietnamese')}
            >
              <Languages size={14} />
              {language === 'vi' ? 'EN' : 'VI'}
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="min-h-16 border-b border-border bg-background flex items-center justify-between px-6 py-2 shrink-0 transition-colors duration-200 gap-4">
          <div className="flex gap-8 items-center min-w-0">
            <div className="flex flex-col shrink-0">
              <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">
                {t('layout.fiscalYear')}
              </span>
              <span className="font-mono text-sm text-foreground">
                {state.year} / Q{Math.ceil(state.month / 3)} ({t('layout.month').toUpperCase()} {state.month.toString().padStart(2, '0')})
              </span>
            </div>
            <div className="flex flex-col shrink-0">
              <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">
                {t('layout.budgetStatus')}
              </span>
              <span className="font-mono text-sm text-primary uppercase tracking-wide italic">
                ${state.budget.toFixed(1)}B
              </span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 flex-wrap">
            <button
              type="button"
              onClick={toggleLanguage}
              className="h-8 min-w-12 px-3 border border-border bg-card hover:bg-muted rounded text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
              aria-label={t('layout.language')}
            >
              <Languages size={14} />
              {language.toUpperCase()}
            </button>

            <div className={cn(
              'flex items-stretch rounded-md border bg-card overflow-hidden shadow-sm min-w-[560px]',
              isCollapsed ? 'border-rose-500/60' : 'border-border',
            )}>
              <div className="relative min-w-[230px] border-r border-border">
                <label
                  htmlFor="time-jump-select"
                  className="pointer-events-none absolute left-3 top-1.5 z-10 text-[9px] font-bold uppercase tracking-widest text-muted-foreground"
                >
                  {t('layout.timeRange')}
                </label>
                <select
                  id="time-jump-select"
                  value={selectedAdvanceMonths}
                  onChange={(event) => setSelectedAdvanceMonths(Number(event.target.value))}
                  disabled={isCollapsed}
                  className="h-12 w-full appearance-none bg-card px-3 pt-3 pr-10 text-sm font-semibold text-foreground outline-none transition-colors hover:bg-muted focus:bg-muted focus:ring-2 focus:ring-inset focus:ring-primary disabled:cursor-not-allowed disabled:opacity-50"
                  aria-label={t('layout.timeRange')}
                >
                  {TIME_JUMP_OPTIONS.map((option) => (
                    <option key={option.months} value={option.months}>
                      {formatTimeOption(option.months, option.key)}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  size={16}
                  className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                />
              </div>

              <div className="hidden min-w-[190px] flex-col justify-center border-r border-border px-3 xl:flex">
                <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
                  {isCollapsed ? t('layout.simulationStopped') : t('layout.targetTime')}
                </span>
                <span className={cn('whitespace-nowrap font-mono text-xs font-bold', isCollapsed ? 'text-rose-500' : 'text-foreground')}>
                  {isCollapsed
                    ? `${t('layout.health.collapsed')} · ${formatDate(state.month, state.year)}`
                    : `${t('layout.month').toUpperCase()} ${targetDate.month.toString().padStart(2, '0')} / ${targetDate.year}`}
                </span>
                <span className="whitespace-nowrap text-[9px] text-muted-foreground">
                  {isCollapsed ? t('layout.simulationLocked') : `${selectedAdvanceMonths} ${t('layout.simulatedMonths')}`}
                </span>
              </div>

              <button
                type="button"
                onClick={() => advanceTime(selectedAdvanceMonths)}
                disabled={isCollapsed}
                className={cn(
                  'min-w-[150px] px-4 text-xs font-bold flex items-center justify-center gap-2 transition-all',
                  isCollapsed
                    ? 'cursor-not-allowed bg-rose-600/20 text-rose-500'
                    : 'bg-primary text-primary-foreground hover:opacity-90 shadow-lg shadow-primary/20',
                )}
                title={isCollapsed ? t('layout.simulationLocked') : t('layout.advanceSelectedHint')}
              >
                {isCollapsed ? <AlertOctagon size={15} /> : <FastForward size={15} />}
                {isCollapsed ? t('layout.health.collapsed') : t('layout.advanceSelected')}
              </button>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 bg-background">{children}</div>
      </main>

      {collapseNotice && (
        <div className="fixed inset-0 z-[100] bg-black/75 backdrop-blur-sm p-4 flex items-center justify-center" role="dialog" aria-modal="true">
          <div className="w-full max-w-6xl max-h-[94vh] overflow-hidden rounded-lg border border-rose-500/50 bg-card shadow-2xl shadow-rose-950/40 flex flex-col">
            <div className="flex items-start justify-between gap-4 border-b border-rose-500/30 bg-rose-500/10 p-5">
              <div className="flex items-start gap-3">
                <div className="rounded-md bg-rose-500/20 p-2 text-rose-500">
                  <AlertOctagon size={28} />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-rose-500">{t('layout.simulationStopped')}</p>
                  <h2 className="mt-1 text-2xl font-black uppercase text-rose-500">{t('layout.collapseTitle')}</h2>
                  <p className="mt-2 max-w-3xl text-sm text-foreground/75">{t('layout.collapseDescription')}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={dismissCollapseNotice}
                className="rounded border border-border p-2 text-muted-foreground hover:bg-muted hover:text-foreground"
                aria-label={t('layout.closeNotice')}
              >
                <X size={18} />
              </button>
            </div>

            <div className="overflow-y-auto p-5 space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="rounded border border-border bg-background p-3">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('layout.collapseAt')}</p>
                  <p className="mt-1 font-mono text-lg font-bold">{formatDate(collapseNotice.state.month, collapseNotice.state.year)}</p>
                </div>
                <div className="rounded border border-border bg-background p-3">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('overview.nationalScore')}</p>
                  <p className="mt-1 font-mono text-lg font-bold text-rose-500">{evaluateState(collapseNotice.state).toFixed(1)}</p>
                </div>
                <div className="rounded border border-border bg-background p-3">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('layout.requestedDuration')}</p>
                  <p className="mt-1 font-mono text-lg font-bold">{collapseRun?.requestedMonths ?? 0} {t('layout.months')}</p>
                </div>
                <div className="rounded border border-border bg-background p-3">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('layout.completedDuration')}</p>
                  <p className="mt-1 font-mono text-lg font-bold">{collapseRun?.completedMonths ?? 0} {t('layout.months')}</p>
                </div>
              </div>

              <div className="rounded border border-rose-500/30 bg-rose-500/5 p-4">
                <h3 className="text-xs font-bold uppercase tracking-widest text-rose-500">{t('layout.collapseReasons')}</h3>
                <div className="mt-3 flex flex-wrap gap-2">
                  {(collapseNotice.reasons.length > 0 ? collapseNotice.reasons : ['system']).map((reason) => (
                    <span key={reason} className="rounded border border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-sm text-rose-500">
                      {formatReason(reason)}
                    </span>
                  ))}
                </div>
              </div>

              <section className="space-y-3">
                <h3 className="text-sm font-bold uppercase tracking-widest">{t('layout.runHistory')}</h3>
                {simulationRuns.length === 0 ? (
                  <div className="rounded border border-border bg-background p-4 text-sm text-muted-foreground">{t('layout.noRunHistory')}</div>
                ) : (
                  <div className="max-h-52 overflow-auto rounded border border-border">
                    <table className="w-full min-w-[760px] text-sm">
                      <thead className="sticky top-0 bg-muted text-[10px] uppercase tracking-wider text-muted-foreground">
                        <tr>
                          <th className="px-3 py-2 text-left">{t('layout.runLabel')}</th>
                          <th className="px-3 py-2 text-left">{t('reports.start')}</th>
                          <th className="px-3 py-2 text-left">{t('reports.end')}</th>
                          <th className="px-3 py-2 text-right">{t('reports.requested')}</th>
                          <th className="px-3 py-2 text-right">{t('reports.completed')}</th>
                          <th className="px-3 py-2 text-right">{t('layout.scoreChange')}</th>
                          <th className="px-3 py-2 text-left">{t('layout.status')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {simulationRuns.map((run) => {
                          const scoreDelta = evaluateState(run.endState) - evaluateState(run.startState);
                          return (
                            <tr key={run.id} className={cn('border-t border-border', run.id === collapseRun?.id && 'bg-rose-500/5')}>
                              <td className="px-3 py-2 font-semibold">#{run.sequence}</td>
                              <td className="px-3 py-2 font-mono">{formatDate(run.startState.month, run.startState.year)}</td>
                              <td className="px-3 py-2 font-mono">{formatDate(run.endState.month, run.endState.year)}</td>
                              <td className="px-3 py-2 text-right font-mono">{run.requestedMonths}</td>
                              <td className="px-3 py-2 text-right font-mono">{run.completedMonths}</td>
                              <td className={cn('px-3 py-2 text-right font-mono', scoreDelta >= 0 ? 'text-emerald-500' : 'text-rose-500')}>
                                {scoreDelta >= 0 ? '+' : ''}{scoreDelta.toFixed(1)}
                              </td>
                              <td className={cn('px-3 py-2 font-semibold', run.status === 'collapsed' ? 'text-rose-500' : 'text-emerald-500')}>
                                {run.status === 'collapsed' ? t('layout.collapsed') : t('layout.completed')}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>

              {collapseRun && (
                <section className="space-y-3">
                  <h3 className="text-sm font-bold uppercase tracking-widest">{t('layout.detailedTimeline')}</h3>
                  <div className="max-h-72 overflow-auto rounded border border-border">
                    <table className="w-full min-w-[1060px] text-xs">
                      <thead className="sticky top-0 bg-muted uppercase tracking-wider text-muted-foreground">
                        <tr>
                          <th className="px-3 py-2 text-left">#</th>
                          <th className="px-3 py-2 text-left">{t('layout.month')}</th>
                          <th className="px-3 py-2 text-right">{metricName('gdp')}</th>
                          <th className="px-3 py-2 text-right">{metricName('budget')}</th>
                          <th className="px-3 py-2 text-right">{metricName('inflation')}</th>
                          <th className="px-3 py-2 text-right">{metricName('unemployment')}</th>
                          <th className="px-3 py-2 text-right">{metricName('happiness')}</th>
                          <th className="px-3 py-2 text-right">{metricName('taxRate')}</th>
                          <th className="px-3 py-2 text-right">{metricName('population')}</th>
                          <th className="px-3 py-2 text-right">{t('reports.score')}</th>
                          <th className="px-3 py-2 text-left">{t('layout.events')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {collapseRun.snapshots.map((snapshot, index) => (
                          <tr key={`${collapseRun.id}-${snapshot.year}-${snapshot.month}-${index}`} className="border-t border-border">
                            <td className="px-3 py-2 font-mono">{index + 1}</td>
                            <td className="px-3 py-2 font-mono">{formatDate(snapshot.month, snapshot.year)}</td>
                            <td className="px-3 py-2 text-right font-mono">{snapshot.gdp.toFixed(1)}</td>
                            <td className="px-3 py-2 text-right font-mono">{snapshot.budget.toFixed(1)}</td>
                            <td className="px-3 py-2 text-right font-mono">{snapshot.inflation.toFixed(1)}%</td>
                            <td className="px-3 py-2 text-right font-mono">{snapshot.unemployment.toFixed(1)}%</td>
                            <td className="px-3 py-2 text-right font-mono">{snapshot.happiness.toFixed(1)}</td>
                            <td className="px-3 py-2 text-right font-mono">{snapshot.taxRate.toFixed(1)}%</td>
                            <td className="px-3 py-2 text-right font-mono">{snapshot.population.toLocaleString(language === 'vi' ? 'vi-VN' : 'en-US')}</td>
                            <td className="px-3 py-2 text-right font-mono">{evaluateState(snapshot).toFixed(1)}</td>
                            <td className="px-3 py-2">{snapshot.active_events.length > 0 ? snapshot.active_events.map(eventName).join(', ') : t('layout.noEvents')}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>
              )}
            </div>

            <div className="flex flex-wrap justify-end gap-3 border-t border-border p-4">
              <button
                type="button"
                onClick={dismissCollapseNotice}
                className="flex items-center gap-2 rounded border border-border bg-background px-4 py-2 text-sm font-semibold hover:bg-muted"
              >
                <X size={16} /> {t('layout.closeNotice')}
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('reports');
                  dismissCollapseNotice();
                }}
                className="flex items-center gap-2 rounded border border-primary/30 bg-primary/10 px-4 py-2 text-sm font-semibold text-primary hover:bg-primary/20"
              >
                <FileText size={16} /> {t('layout.viewFullReport')}
              </button>
              <button
                type="button"
                onClick={reset}
                className="flex items-center gap-2 rounded bg-rose-600 px-4 py-2 text-sm font-bold text-white hover:bg-rose-500"
              >
                <RotateCcw size={16} /> {t('layout.resetSimulation')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

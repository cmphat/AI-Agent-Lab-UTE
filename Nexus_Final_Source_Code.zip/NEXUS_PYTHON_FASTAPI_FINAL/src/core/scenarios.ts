import { NationState } from './types';
import { clampState, getInitialState } from './state';

export type ScenarioSeverity = 'stable' | 'warning' | 'crisis' | 'critical';

export interface ScenarioPreset {
  id: string;
  severity: ScenarioSeverity;
  title: Record<'vi' | 'en', string>;
  description: Record<'vi' | 'en', string>;
  objective: Record<'vi' | 'en', string>;
  focusPolicyIds: string[];
  state: NationState;
}

const createScenarioState = (patch: Partial<NationState>): NationState => {
  const base = getInitialState();
  return clampState({
    ...base,
    ...patch,
    active_events: [...(patch.active_events ?? [])],
    recentPolicies: [...(patch.recentPolicies ?? [])].slice(-6),
  });
};

export const SCENARIO_PRESETS: ScenarioPreset[] = [
  {
    id: 'prosperous_baseline',
    severity: 'stable',
    title: {
      vi: 'Ổn định và có dư địa phát triển',
      en: 'Stable with Development Headroom',
    },
    description: {
      vi: 'Quốc gia đang ở trạng thái tốt: ngân sách dồi dào, nợ thấp, lạm phát và thất nghiệp được kiểm soát. Kịch bản này dùng để kiểm tra thuật toán có biết đầu tư dài hạn thay vì chỉ tối ưu ngắn hạn hay không.',
      en: 'The country is in good shape: strong reserves, low debt, controlled inflation and unemployment. Use this scenario to test whether algorithms invest for the long term instead of only optimizing the next few months.',
    },
    objective: {
      vi: 'Ưu tiên đầu tư giáo dục, y tế, công nghệ, hạ tầng và năng lượng sạch mà vẫn giữ an toàn tài khóa.',
      en: 'Prioritize education, healthcare, technology, infrastructure and clean energy while preserving fiscal safety.',
    },
    focusPolicyIds: ['edu_invest', 'health_invest', 'innovation_fund', 'modernize', 'green_energy'],
    state: createScenarioState({
      gdp: 1120,
      budget: 640,
      debt: 185,
      taxRate: 20,
      inflation: 2.8,
      unemployment: 5.5,
      happiness: 78,
      education: 66,
      healthcare: 68,
      energy: 72,
      environment: 69,
      military: 52,
      technology: 55,
      cybersecurity: 58,
      infrastructure: 63,
      diplomacy: 66,
      population: 1_010_000,
      active_events: [],
    }),
  },
  {
    id: 'pandemic_pressure',
    severity: 'crisis',
    title: {
      vi: 'Đại dịch và áp lực xã hội',
      en: 'Pandemic and Social Pressure',
    },
    description: {
      vi: 'Hệ thống y tế bị kéo xuống rõ rệt, thất nghiệp tăng, hạnh phúc giảm và ngân sách bị bào mòn. Đây không chỉ là một sự kiện đơn lẻ mà là trạng thái sau nhiều tháng chịu dịch bệnh.',
      en: 'Healthcare is heavily weakened, unemployment is rising, happiness is falling and public reserves are being depleted. This is not a one-off event; it represents a country after several months of pandemic pressure.',
    },
    objective: {
      vi: 'Ổn định y tế trước, sau đó giảm thất nghiệp và giữ lạm phát trong vùng an toàn.',
      en: 'Stabilize healthcare first, then reduce unemployment and keep inflation within a safe band.',
    },
    focusPolicyIds: ['emergency_healthcare', 'health_invest', 'job_program', 'welfare', 'inflation_control'],
    state: createScenarioState({
      gdp: 930,
      budget: 185,
      debt: 460,
      taxRate: 22,
      inflation: 7.8,
      unemployment: 19,
      happiness: 30,
      education: 42,
      healthcare: 22,
      energy: 48,
      environment: 53,
      military: 40,
      technology: 38,
      cybersecurity: 36,
      infrastructure: 37,
      diplomacy: 49,
      population: 985_000,
      active_events: ['pandemic'],
    }),
  },
  {
    id: 'economic_social_breakdown',
    severity: 'critical',
    title: {
      vi: 'Suy thoái, biểu tình và đứt gãy chuỗi cung',
      en: 'Recession, Protests and Supply Disruption',
    },
    description: {
      vi: 'Đây là kịch bản nguy cấp: thất nghiệp rất cao, lạm phát tăng, ngân sách thấp, nợ công nặng và niềm tin xã hội suy giảm. Nếu AI chỉ chọn chính sách kinh tế lặp lại thì quốc gia rất dễ sụp đổ.',
      en: 'This is a critical scenario: very high unemployment, elevated inflation, low reserves, heavy public debt and weak social confidence. If the AI repeats short-term economic policies, collapse becomes likely.',
    },
    objective: {
      vi: 'Cắt vòng xoáy thất nghiệp - lạm phát - bất mãn, đồng thời tránh vay nợ vô tội vạ.',
      en: 'Break the unemployment-inflation-social unrest spiral while avoiding uncontrolled borrowing.',
    },
    focusPolicyIds: ['job_program', 'supply_chain_stabilization', 'social_dialogue', 'inflation_control', 'business_grant'],
    state: createScenarioState({
      gdp: 820,
      budget: 135,
      debt: 720,
      taxRate: 24,
      inflation: 12.5,
      unemployment: 23,
      happiness: 24,
      education: 43,
      healthcare: 38,
      energy: 44,
      environment: 50,
      military: 39,
      technology: 35,
      cybersecurity: 34,
      infrastructure: 36,
      diplomacy: 42,
      population: 972_000,
      active_events: ['recession', 'protest', 'supply_chain'],
    }),
  },
  {
    id: 'regional_conflict_energy',
    severity: 'crisis',
    title: {
      vi: 'Xung đột khu vực và khủng hoảng năng lượng',
      en: 'Regional Conflict and Energy Crisis',
    },
    description: {
      vi: 'Ngoại giao xuống thấp, năng lượng thiếu hụt, lạm phát cao và năng lực quân sự chưa đủ an toàn. Kịch bản này buộc thuật toán cân bằng giữa quốc phòng, ngoại giao, năng lượng và ổn định giá.',
      en: 'Diplomacy is weak, energy is scarce, inflation is high and military readiness is not yet safe. This scenario forces algorithms to balance defense, diplomacy, energy and price stability.',
    },
    objective: {
      vi: 'Hạ rủi ro chiến tranh bằng ngoại giao, xử lý năng lượng và kiểm soát lạm phát.',
      en: 'Reduce war risk through diplomacy, restore energy security and control inflation.',
    },
    focusPolicyIds: ['diplomacy', 'ceasefire_negotiation', 'foreign_resource_deal', 'green_energy', 'inflation_control'],
    state: createScenarioState({
      gdp: 905,
      budget: 190,
      debt: 600,
      taxRate: 23.5,
      inflation: 14,
      unemployment: 13.5,
      happiness: 35,
      education: 47,
      healthcare: 43,
      energy: 24,
      environment: 47,
      military: 26,
      technology: 40,
      cybersecurity: 39,
      infrastructure: 36,
      diplomacy: 16,
      population: 990_000,
      active_events: ['war', 'oil_crisis'],
    }),
  },
  {
    id: 'cyber_resilience_gap',
    severity: 'warning',
    title: {
      vi: 'Tấn công mạng và năng lực số yếu',
      en: 'Cyberattack and Weak Digital Resilience',
    },
    description: {
      vi: 'Nền kinh tế chưa sụp đổ nhưng an ninh mạng rất thấp, công nghệ chậm, niềm tin giảm và ngân sách bị tổn thất. Kịch bản này kiểm tra AI có ưu tiên đúng các rủi ro ẩn thay vì chỉ nhìn GDP hay không.',
      en: 'The economy has not collapsed, but cybersecurity is extremely weak, technology lags, confidence is lower and reserves have been hit. This tests whether the AI handles hidden systemic risk instead of only reading GDP.',
    },
    objective: {
      vi: 'Khôi phục an ninh mạng, nâng công nghệ và tránh để cú sốc mạng kéo sang kinh tế - xã hội.',
      en: 'Restore cybersecurity, improve technology and prevent the digital shock from spreading into the economy and society.',
    },
    focusPolicyIds: ['cyber_incident_response', 'cybersec', 'ai_national', 'innovation_fund', 'business_grant'],
    state: createScenarioState({
      gdp: 1010,
      budget: 390,
      debt: 300,
      taxRate: 20.5,
      inflation: 4.8,
      unemployment: 8.8,
      happiness: 56,
      education: 56,
      healthcare: 54,
      energy: 58,
      environment: 57,
      military: 45,
      technology: 42,
      cybersecurity: 18,
      infrastructure: 49,
      diplomacy: 53,
      population: 1_000_000,
      active_events: ['cyberattack'],
    }),
  },
  {
    id: 'climate_disaster_recovery',
    severity: 'crisis',
    title: {
      vi: 'Thiên tai và suy thoái môi trường',
      en: 'Natural Disaster and Environmental Decline',
    },
    description: {
      vi: 'Môi trường và hạ tầng bị đánh mạnh, y tế chịu áp lực, năng lượng yếu và ngân sách không còn quá rộng. Kịch bản này giúp kiểm tra chính sách môi trường - hạ tầng có được AI đánh giá đúng giá trị dài hạn không.',
      en: 'Environment and infrastructure are heavily damaged, healthcare is under pressure, energy is weak and reserves are limited. This helps test whether environmental and infrastructure policies are valued for their long-term benefits.',
    },
    objective: {
      vi: 'Tái thiết hạ tầng, phục hồi môi trường, bảo vệ y tế và từng bước khôi phục năng lượng.',
      en: 'Rebuild infrastructure, restore the environment, protect healthcare and gradually recover energy capacity.',
    },
    focusPolicyIds: ['disaster_reconstruction', 'climate_adaptation', 'forest', 'green_energy', 'health_invest'],
    state: createScenarioState({
      gdp: 890,
      budget: 180,
      debt: 535,
      taxRate: 21.5,
      inflation: 9.5,
      unemployment: 15.5,
      happiness: 34,
      education: 47,
      healthcare: 28,
      energy: 29,
      environment: 12,
      military: 41,
      technology: 40,
      cybersecurity: 42,
      infrastructure: 18,
      diplomacy: 50,
      population: 985_000,
      active_events: ['climate', 'disaster'],
    }),
  },
];

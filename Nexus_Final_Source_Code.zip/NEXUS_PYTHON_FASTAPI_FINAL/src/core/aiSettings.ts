export type ConstraintStrictness = 'relaxed' | 'balanced' | 'strict';
export type LrtaMemoryMode = 'temporary' | 'persistent';

export interface AIAdvancedSettings {
  uninformedMonths: number;
  costHeuristicMonths: number;
  localSearchSteps: number;
  beamWidth: number;
  annealingIterations: number;
  andOrMonths: number;
  beliefMonths: number;
  lrtaLearningMonths: number;
  cspMonths: number;
  adversarialMonths: number;
  chanceMonths: number;
  maxMinActions: number;
  constraintStrictness: ConstraintStrictness;
  lrtaMemoryMode: LrtaMemoryMode;
}

export const DEFAULT_AI_SETTINGS: AIAdvancedSettings = {
  uninformedMonths: 3,
  costHeuristicMonths: 3,
  localSearchSteps: 4,
  beamWidth: 4,
  annealingIterations: 540,
  andOrMonths: 2,
  beliefMonths: 3,
  lrtaLearningMonths: 4,
  cspMonths: 3,
  adversarialMonths: 2,
  chanceMonths: 2,
  maxMinActions: 4,
  constraintStrictness: 'balanced',
  lrtaMemoryMode: 'persistent',
};

const clampInteger = (value: unknown, min: number, max: number, fallback: number): number => {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return fallback;
  return Math.max(min, Math.min(max, Math.round(numeric)));
};

export const normalizeAISettings = (value: unknown): AIAdvancedSettings => {
  const raw = typeof value === 'object' && value !== null ? value as Partial<AIAdvancedSettings> : {};
  const strictnessValues: ConstraintStrictness[] = ['relaxed', 'balanced', 'strict'];
  const memoryValues: LrtaMemoryMode[] = ['temporary', 'persistent'];

  return {
    uninformedMonths: clampInteger(raw.uninformedMonths, 1, 5, DEFAULT_AI_SETTINGS.uninformedMonths),
    costHeuristicMonths: clampInteger(raw.costHeuristicMonths, 1, 5, DEFAULT_AI_SETTINGS.costHeuristicMonths),
    localSearchSteps: clampInteger(raw.localSearchSteps, 1, 8, DEFAULT_AI_SETTINGS.localSearchSteps),
    beamWidth: clampInteger(raw.beamWidth, 2, 8, DEFAULT_AI_SETTINGS.beamWidth),
    annealingIterations: clampInteger(raw.annealingIterations, 100, 1200, DEFAULT_AI_SETTINGS.annealingIterations),
    andOrMonths: clampInteger(raw.andOrMonths, 1, 3, DEFAULT_AI_SETTINGS.andOrMonths),
    beliefMonths: clampInteger(raw.beliefMonths, 1, 4, DEFAULT_AI_SETTINGS.beliefMonths),
    lrtaLearningMonths: clampInteger(raw.lrtaLearningMonths, 1, 8, DEFAULT_AI_SETTINGS.lrtaLearningMonths),
    cspMonths: clampInteger(raw.cspMonths, 1, 5, DEFAULT_AI_SETTINGS.cspMonths),
    adversarialMonths: clampInteger(raw.adversarialMonths, 1, 3, DEFAULT_AI_SETTINGS.adversarialMonths),
    chanceMonths: clampInteger(raw.chanceMonths, 1, 3, DEFAULT_AI_SETTINGS.chanceMonths),
    maxMinActions: clampInteger(raw.maxMinActions, 2, 6, DEFAULT_AI_SETTINGS.maxMinActions),
    constraintStrictness: strictnessValues.includes(raw.constraintStrictness as ConstraintStrictness)
      ? raw.constraintStrictness as ConstraintStrictness
      : DEFAULT_AI_SETTINGS.constraintStrictness,
    lrtaMemoryMode: memoryValues.includes(raw.lrtaMemoryMode as LrtaMemoryMode)
      ? raw.lrtaMemoryMode as LrtaMemoryMode
      : DEFAULT_AI_SETTINGS.lrtaMemoryMode,
  };
};

export const readAISettings = (): AIAdvancedSettings => {
  try {
    const saved = localStorage.getItem('nexus-ai-advanced-settings');
    if (!saved) return DEFAULT_AI_SETTINGS;
    return normalizeAISettings(JSON.parse(saved));
  } catch {
    return DEFAULT_AI_SETTINGS;
  }
};

export const getAlgorithmRunLimit = (algorithm: string, settings: AIAdvancedSettings): number => {
  if (['BFS', 'DFS', 'IDS'].includes(algorithm)) return settings.uninformedMonths;
  if (['UCS', 'Greedy Best-First', 'A*'].includes(algorithm)) return settings.costHeuristicMonths;
  if (['Hill Climbing', 'Local Beam Search'].includes(algorithm)) return settings.localSearchSteps;
  if (algorithm === 'Simulated Annealing') return Math.max(1, Math.round(settings.annealingIterations / 180));
  if (algorithm === 'AND-OR Search') return settings.andOrMonths;
  if (algorithm === 'Belief-State Search') return settings.beliefMonths;
  if (algorithm === 'LRTA*') return settings.lrtaLearningMonths;
  if (['Constraint Propagation', 'Backtracking CSP', 'Min-Conflicts CSP'].includes(algorithm)) return settings.cspMonths;
  if (['Minimax', 'Alpha-Beta'].includes(algorithm)) return settings.adversarialMonths;
  if (algorithm === 'Expectimax') return settings.chanceMonths;
  return DEFAULT_AI_SETTINGS.costHeuristicMonths;
};

export const getAlgorithmSettingLabelKey = (algorithm: string): string => {
  if (['BFS', 'DFS', 'IDS'].includes(algorithm)) return 'settings.aiUninformedMonths';
  if (['UCS', 'Greedy Best-First', 'A*'].includes(algorithm)) return 'settings.aiCostHeuristicMonths';
  if (['Hill Climbing', 'Local Beam Search'].includes(algorithm)) return 'settings.aiLocalSearchSteps';
  if (algorithm === 'Simulated Annealing') return 'settings.aiAnnealingIterations';
  if (algorithm === 'AND-OR Search') return 'settings.aiAndOrMonths';
  if (algorithm === 'Belief-State Search') return 'settings.aiBeliefMonths';
  if (algorithm === 'LRTA*') return 'settings.aiLrtaLearningMonths';
  if (['Constraint Propagation', 'Backtracking CSP', 'Min-Conflicts CSP'].includes(algorithm)) return 'settings.aiCspMonths';
  if (['Minimax', 'Alpha-Beta'].includes(algorithm)) return 'settings.aiAdversarialMonths';
  if (algorithm === 'Expectimax') return 'settings.aiChanceMonths';
  return 'settings.aiCostHeuristicMonths';
};

export const getAlgorithmSettingValue = (algorithm: string, settings: AIAdvancedSettings): number => {
  if (algorithm === 'Simulated Annealing') return settings.annealingIterations;
  return getAlgorithmRunLimit(algorithm, settings);
};

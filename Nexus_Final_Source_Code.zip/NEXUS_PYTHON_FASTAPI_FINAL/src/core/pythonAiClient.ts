import { AIAdvancedSettings } from './aiSettings';
import { POLICIES } from './data';
import { AlgorithmResult, NationState } from './types';

const API_BASE = (import.meta.env.VITE_PYTHON_API_URL as string | undefined)?.replace(/\/$/, '') || 'http://127.0.0.1:8000';

const fetchJson = async <T>(path: string, init?: RequestInit, timeoutMs = 120_000): Promise<T> => {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        ...(init?.headers ?? {}),
      },
    });
    if (!response.ok) {
      const body = await response.text();
      throw new Error(`Python AI Engine ${response.status}: ${body || response.statusText}`);
    }
    return await response.json() as T;
  } finally {
    window.clearTimeout(timeout);
  }
};

export interface PythonEngineHealth {
  status: 'ok';
  engine: 'python';
  algorithms: number;
  version: string;
}

export interface PythonBenchmarkResult {
  algorithm: string;
  totalRuntimeMs: number;
  totalWallTimeMs: number;
  totalNodesExpanded: number;
  finalScore: number;
  finalStability: number;
  avgStabilityDeviation: number;
  minStability: number;
  maxMonthlyStabilityDrop: number;
  completedMonths: number;
  policyActionMonths: number;
  noActionMonths: number;
  uniquePolicyCount: number;
  policyDiversity: number;
  topPolicyIds: string[];
  finalState: NationState;
  collapsedAtMonth: number | null;
  collapseReasons: string[];
  error?: string;
}

export const checkPythonEngine = (): Promise<PythonEngineHealth> =>
  fetchJson<PythonEngineHealth>('/api/health', undefined, 4_000);

export const runPythonAlgorithm = (
  algorithm: string,
  state: NationState,
  depth: number,
  settings: AIAdvancedSettings,
): Promise<AlgorithmResult> =>
  fetchJson<AlgorithmResult>('/api/run', {
    method: 'POST',
    body: JSON.stringify({ algorithm, state, policies: POLICIES, depth, settings }),
  });

export const benchmarkPythonAlgorithm = (
  algorithm: string,
  state: NationState,
  depth: number,
  settings: AIAdvancedSettings,
  months = 60,
): Promise<PythonBenchmarkResult> =>
  fetchJson<PythonBenchmarkResult>('/api/benchmark/algorithm', {
    method: 'POST',
    body: JSON.stringify({ algorithm, state, policies: POLICIES, depth, settings, months }),
  }, 300_000);

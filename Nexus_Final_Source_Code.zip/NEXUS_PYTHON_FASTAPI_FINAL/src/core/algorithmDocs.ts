import { Language } from './LanguageProvider';

type LocalizedText = Record<Language, string>;

export interface AlgorithmDoc {
  family: LocalizedText;
  summary: LocalizedText;
  application: LocalizedText;
  complexity: string;
  pseudocode: LocalizedText;
}

export const ALGORITHM_DOCS: Record<string, AlgorithmDoc> = {
  BFS: {
    family: { vi: 'Tìm kiếm không thông tin', en: 'Uninformed search' },
    summary: {
      vi: 'Mở rộng các trạng thái theo từng tầng bằng hàng đợi FIFO nên tìm được lời giải nông nhất trong giới hạn tìm kiếm.',
      en: 'Expands states level by level with a FIFO queue, so it finds the shallowest solution within the search bound.',
    },
    application: {
      vi: 'Mỗi nút là một trạng thái quốc gia; mỗi cạnh là một chính sách đủ điều kiện. BFS duyệt theo tầng trong giới hạn tính toán và giữ trạng thái tốt nhất đã gặp.',
      en: 'Each node is a nation state and each edge is an eligible policy. BFS searches level by level within the calculation limit and keeps the best state seen.',
    },
    complexity: 'Time: O(b^d) • Space: O(b^d)',
    pseudocode: {
      vi: `BFS(trạng_thái_đầu, độ_sâu_tối_đa):
    hàng_đợi ← [(trạng_thái_đầu, đường_đi_rỗng, 0)]
    đã_thăm ← {trạng_thái_đầu}
    trong khi hàng_đợi không rỗng:
        nút ← lấy_đầu(hàng_đợi)
        nếu điểm(nút) tốt hơn tốt_nhất: cập_nhật tốt_nhất
        nếu nút.độ_sâu < độ_sâu_tối_đa:
            với mỗi chính_sách_hợp_lệ:
                con ← áp_dụng(chính_sách, nút.trạng_thái)
                nếu con chưa được thăm:
                    thêm con vào cuối hàng_đợi
    trả về trạng_thái_tốt_nhất_đã_gặp`,
      en: `BFS(initial_state, max_depth):
    queue ← [(initial_state, empty_path, 0)]
    visited ← {initial_state}
    while queue is not empty:
        node ← dequeue_front(queue)
        if node is a better candidate: update best_seen
        if node.depth < max_depth:
            for each valid_policy:
                child ← apply(valid_policy, node.state)
                if child not visited:
                    enqueue_back(queue, child)
    return best_state_seen`,
    },
  },
  DFS: {
    family: { vi: 'Tìm kiếm không thông tin', en: 'Uninformed search' },
    summary: {
      vi: 'Đi sâu hết một nhánh trước khi quay lui sang nhánh khác.',
      en: 'Explores one branch as deeply as possible before backtracking.',
    },
    application: {
      vi: 'DFS thử liên tiếp các chính sách theo chiều sâu và dùng tập trạng thái trên đường đi để tránh chu trình.',
      en: 'DFS applies policy sequences depth-first and uses a path-state set to avoid cycles.',
    },
    complexity: 'Time: O(b^m) • Space: O(bm)',
    pseudocode: {
      vi: `DFS(nút, giới_hạn):
    nếu điểm(nút) tốt hơn tốt_nhất: cập_nhật tốt_nhất
    nếu nút.độ_sâu = giới_hạn: thất_bại
    với mỗi chính_sách_hợp_lệ:
        con ← áp_dụng(chính_sách, nút)
        nếu con không nằm trên đường_đi_hiện_tại:
            kết_quả ← DFS(con, giới_hạn)
            nếu thành_công: trả về kết_quả
    quay_lui`,
      en: `DFS(node, limit):
    if score(node) improves best_seen: update best_seen
    if node.depth = limit: fail
    for each valid_policy:
        child ← apply(valid_policy, node)
        if child is not on current_path:
            result ← DFS(child, limit)
            if success: return result
    backtrack`,
    },
  },
  IDS: {
    family: { vi: 'Tìm kiếm không thông tin', en: 'Uninformed search' },
    summary: {
      vi: 'Lặp DFS giới hạn độ sâu từ 0 đến d, kết hợp tính đầy đủ của BFS và bộ nhớ thấp của DFS.',
      en: 'Repeats depth-limited DFS from 0 to d, combining BFS completeness with DFS memory efficiency.',
    },
    application: {
      vi: 'Hệ thống tăng dần giới hạn số bước chính sách, chạy DFS giới hạn nhiều lần và giữ plan tốt nhất đã gặp.',
      en: 'The simulator increases the policy-step limit, reruns depth-limited DFS, and keeps the best plan found.',
    },
    complexity: 'Time: O(b^d) • Space: O(bd)',
    pseudocode: {
      vi: `IDS(trạng_thái_đầu, d):
    với giới_hạn từ 0 đến d:
        kết_quả ← DFS_GIỚI_HẠN(trạng_thái_đầu, giới_hạn)
        nếu kết_quả tốt hơn tốt_nhất:
            cập_nhật tốt_nhất
    trả về trạng_thái_tốt_nhất`,
      en: `IDS(initial_state, d):
    for limit from 0 to d:
        result ← DEPTH_LIMITED_DFS(initial_state, limit)
        if result improves best_seen:
            update best_seen
    return best_state_seen`,
    },
  },
  UCS: {
    family: { vi: 'Tìm kiếm theo chi phí', en: 'Cost-based search' },
    summary: {
      vi: 'Luôn mở rộng nút có tổng chi phí g(n) nhỏ nhất bằng hàng đợi ưu tiên.',
      en: 'Always expands the node with the lowest accumulated path cost g(n) using a priority queue.',
    },
    application: {
      vi: 'Chi phí cạnh gồm chi phí ngân sách trực tiếp, chi phí xã hội/chiến lược, rủi ro nợ, lạm phát, thất nghiệp và phạt sụp đổ.',
      en: 'Edge cost combines direct budget cost, social/strategic loss, debt, inflation, unemployment risk, and collapse penalty.',
    },
    complexity: 'Time/Space: O(b^(1+⌊C*/ε⌋))',
    pseudocode: {
      vi: `UCS(trạng_thái_đầu):
    frontier ← hàng_đợi_ưu_tiên theo g(n)
    đưa trạng_thái_đầu với g = 0 vào frontier
    trong khi frontier không rỗng:
        nút ← lấy nút có g nhỏ nhất
        nếu điểm(nút) tốt hơn tốt_nhất: cập_nhật tốt_nhất
        với mỗi chính_sách_hợp_lệ:
            g_mới ← g(nút) + chi_phí_chuyển
            nếu g_mới tốt hơn chi phí đã biết:
                cập_nhật và đưa con vào frontier`,
      en: `UCS(initial_state):
    frontier ← priority_queue ordered by g(n)
    insert initial_state with g = 0
    while frontier is not empty:
        node ← pop lowest g
        if node is a better candidate: update best_seen
        for each valid_policy:
            new_g ← g(node) + transition_cost
            if new_g improves the known cost:
                update and push child`,
    },
  },
  'Greedy Best-First': {
    family: { vi: 'Tìm kiếm có thông tin', en: 'Informed search' },
    summary: {
      vi: 'Chỉ dùng heuristic h(n) để chọn trạng thái có vẻ gần mục tiêu nhất.',
      en: 'Uses only heuristic h(n) to select the state that appears closest to the goal.',
    },
    application: {
      vi: 'Heuristic đo khoảng cách đến quốc gia mục tiêu: chỉ số tích cực cao, lạm phát và thất nghiệp thấp, nợ bền vững.',
      en: 'The heuristic measures distance to a healthy target nation with strong positive metrics and controlled risks.',
    },
    complexity: 'Worst case: O(b^m) time and space',
    pseudocode: {
      vi: `GREEDY(trạng_thái_đầu):
    frontier ← hàng_đợi_ưu_tiên theo h(n)
    trong khi frontier không rỗng:
        nút ← lấy nút có h nhỏ nhất
        nếu điểm(nút) tốt hơn tốt_nhất: cập_nhật tốt_nhất
        sinh các trạng_thái_con
        đưa con vào frontier với ưu tiên h(con)`,
      en: `GREEDY(initial_state):
    frontier ← priority_queue ordered by h(n)
    while frontier is not empty:
        node ← pop lowest h
        if node is a better candidate: update best_seen
        generate child states
        push each child with priority h(child)`,
    },
  },
  'A*': {
    family: { vi: 'Tìm kiếm có thông tin', en: 'Informed search' },
    summary: {
      vi: 'Kết hợp chi phí đã đi và ước lượng còn lại theo f(n) = g(n) + h(n).',
      en: 'Combines accumulated cost and estimated remaining cost with f(n) = g(n) + h(n).',
    },
    application: {
      vi: 'g(n) phản ánh chi phí chuỗi chính sách; h(n) phản ánh khoảng cách đến điểm mục tiêu và trạng thái quốc gia khỏe mạnh.',
      en: 'g(n) represents policy-plan cost; h(n) estimates the remaining gap to the target score and a healthy nation.',
    },
    complexity: 'Worst case: O(b^d) • Optimal with admissible h',
    pseudocode: {
      vi: `A_STAR(trạng_thái_đầu):
    frontier ← hàng_đợi_ưu_tiên theo f = g + h
    g(trạng_thái_đầu) ← 0
    trong khi frontier không rỗng:
        nút ← lấy nút có f nhỏ nhất
        nếu điểm(nút) tốt hơn tốt_nhất: cập_nhật tốt_nhất
        với mỗi con:
            tentative_g ← g(nút) + chi_phí_cạnh
            nếu tentative_g tốt hơn:
                g(con) ← tentative_g
                f(con) ← g(con) + h(con)
                đưa con vào frontier`,
      en: `A_STAR(initial_state):
    frontier ← priority_queue ordered by f = g + h
    g(initial_state) ← 0
    while frontier is not empty:
        node ← pop lowest f
        if node is a better candidate: update best_seen
        for each child:
            tentative_g ← g(node) + edge_cost
            if tentative_g improves known g:
                g(child) ← tentative_g
                f(child) ← g(child) + h(child)
                push child`,
    },
  },
  'Hill Climbing': {
    family: { vi: 'Tìm kiếm cục bộ', en: 'Local search' },
    summary: {
      vi: 'Mỗi bước chọn láng giềng có điểm cao nhất và dừng khi không còn cải thiện.',
      en: 'Chooses the highest-scoring neighbor at every step and stops when no improvement remains.',
    },
    application: {
      vi: 'Láng giềng là trạng thái sau khi áp dụng đúng một chính sách hợp lệ. Thuật toán có thể mắc cực đại cục bộ.',
      en: 'A neighbor is the state after one valid policy. The method can become trapped at a local optimum.',
    },
    complexity: 'Time: O(iterations × b) • Space: O(b)',
    pseudocode: {
      vi: `HILL_CLIMBING(trạng_thái):
    lặp:
        láng_giềng ← sinh mọi chính_sách_hợp_lệ
        tốt_nhất ← láng_giềng có điểm cao nhất
        nếu điểm(tốt_nhất) ≤ điểm(trạng_thái):
            trả về trạng_thái
        trạng_thái ← tốt_nhất`,
      en: `HILL_CLIMBING(state):
    repeat:
        neighbors ← apply every valid policy
        best ← highest-scoring neighbor
        if score(best) ≤ score(state):
            return state
        state ← best`,
    },
  },
  'Local Beam Search': {
    family: { vi: 'Tìm kiếm cục bộ', en: 'Local search' },
    summary: {
      vi: 'Duy trì đồng thời k trạng thái tốt nhất thay vì chỉ một trạng thái.',
      en: 'Maintains the k best states simultaneously instead of a single current state.',
    },
    application: {
      vi: 'Mỗi tầng sinh toàn bộ hậu duệ của beam hiện tại, loại trùng và giữ k trạng thái có điểm cao nhất.',
      en: 'Each level expands all beam members, removes duplicates and keeps the k highest-scoring successors.',
    },
    complexity: 'Time: O(dkb) • Space: O(kb)',
    pseudocode: {
      vi: `LOCAL_BEAM(trạng_thái_đầu, k, d):
    beam ← {trạng_thái_đầu}
    lặp d tầng:
        successors ← mọi hậu_duệ của các nút trong beam
        nếu có mục_tiêu: trả về mục_tiêu
        beam ← k trạng_thái tốt nhất trong successors
    trả về trạng_thái tốt nhất trong beam`,
      en: `LOCAL_BEAM(initial_state, k, d):
    beam ← {initial_state}
    repeat for d levels:
        successors ← all children of states in beam
        if a better candidate exists: update best_seen
        beam ← k best states from successors
    return best state in beam`,
    },
  },
  'Simulated Annealing': {
    family: { vi: 'Tìm kiếm cục bộ ngẫu nhiên', en: 'Stochastic local search' },
    summary: {
      vi: 'Thỉnh thoảng chấp nhận nghiệm xấu hơn theo nhiệt độ để thoát cực đại cục bộ.',
      en: 'Occasionally accepts worse solutions according to temperature, allowing escape from local optima.',
    },
    application: {
      vi: 'Nghiệm là một chuỗi chính sách cố định độ dài. Láng giềng được tạo bằng cách thay một chính sách trong chuỗi.',
      en: 'A solution is a fixed-length policy plan. A neighbor is formed by replacing one policy in the plan.',
    },
    complexity: 'Time: O(iterations × plan evaluation) • Space: O(d)',
    pseudocode: {
      vi: `SIMULATED_ANNEALING(kế_hoạch_đầu):
    current ← kế_hoạch_đầu
    T ← nhiệt_độ_ban_đầu
    trong khi chưa hết số vòng:
        next ← thay ngẫu nhiên một chính_sách
        Δ ← điểm(next) - điểm(current)
        nếu Δ ≥ 0 hoặc random() < exp(Δ/T):
            current ← next
        T ← T × hệ_số_làm_nguội
    trả về kế_hoạch tốt nhất đã gặp`,
      en: `SIMULATED_ANNEALING(initial_plan):
    current ← initial_plan
    T ← initial_temperature
    while iterations remain:
        next ← randomly replace one policy
        Δ ← score(next) - score(current)
        if Δ ≥ 0 or random() < exp(Δ/T):
            current ← next
        T ← T × cooling_rate
    return best plan seen`,
    },
  },
  'AND-OR Search': {
    family: { vi: 'Tìm kiếm không xác định', en: 'Nondeterministic search' },
    summary: {
      vi: 'OR chọn hành động; AND yêu cầu kế hoạch xử lý được mọi kết quả có thể của hành động đó.',
      en: 'OR nodes choose actions; AND nodes require the plan to handle every possible action outcome.',
    },
    application: {
      vi: 'Mỗi chính sách có ba kết quả: thành công, hiệu quả một phần và gặp trở ngại. Giá trị hành động được tính theo nhánh xấu nhất.',
      en: 'Each policy has success, partial-success and setback outcomes. An action is evaluated by its worst branch.',
    },
    complexity: 'Exponential in action and outcome branching',
    pseudocode: {
      vi: `OR_SEARCH(trạng_thái):
    nếu hết_giới_hạn_tính_toán: đánh_giá_trạng_thái
    với mỗi hành_động:
        kế_hoạch ← AND_SEARCH(CÁC_KẾT_QUẢ(trạng_thái, hành_động))
        nếu mọi kết_quả đều có kế_hoạch:
            lưu giá_trị_xấu_nhất của hành_động
    trả về hành_động có giá_trị_xấu_nhất lớn nhất

AND_SEARCH(tập_kết_quả):
    giải OR_SEARCH cho từng kết_quả
    tất cả nhánh phải thành công`,
      en: `OR_SEARCH(state):
    if limit reached: evaluate leaf
    for each action:
        plan ← AND_SEARCH(OUTCOMES(state, action))
        if every outcome has a plan:
            record the action's worst-case value
    return action with the best worst-case value

AND_SEARCH(outcomes):
    solve OR_SEARCH for every outcome
    every branch must succeed`,
    },
  },
  'Belief-State Search': {
    family: { vi: 'Tìm kiếm quan sát không đầy đủ', en: 'Partially observable search' },
    summary: {
      vi: 'Tìm kiếm trên tập các trạng thái có thể đúng thay vì một trạng thái duy nhất.',
      en: 'Searches over a set of possible states rather than one fully known state.',
    },
    application: {
      vi: 'Belief ban đầu gồm trạng thái chính xác, lạc quan, bi quan và khủng hoảng ẩn. Chính sách được đánh giá theo điểm trung bình và tệ nhất.',
      en: 'The initial belief contains exact, optimistic, pessimistic and hidden-crisis states. Policies are scored by mean and worst-case value.',
    },
    complexity: 'Exponential in hidden-state and action branching',
    pseudocode: {
      vi: `BELIEF_SEARCH(belief_đầu):
    frontier ← {belief_đầu}
    lặp theo độ_sâu:
        với mỗi belief và mỗi chính_sách:
            belief_mới ← áp_dụng chính_sách lên mọi trạng_thái trong belief
            điểm_bền_vững ← 0.65×trung_bình + 0.35×tệ_nhất
        giữ các belief tốt nhất
    trả về kế_hoạch có điểm_bền_vững cao nhất`,
      en: `BELIEF_SEARCH(initial_belief):
    frontier ← {initial_belief}
    repeat by internal calculation limit:
        for each belief and each policy:
            new_belief ← apply policy to every possible state
            robust_score ← 0.65×mean + 0.35×worst
        keep the best belief nodes
    return plan with highest robust_score`,
    },
  },
  'LRTA*': {
    family: { vi: 'Tìm kiếm trực tuyến', en: 'Online search' },
    summary: {
      vi: 'Ra quyết định trực tuyến: chỉ chốt chính sách tháng hiện tại, các tháng sau sẽ quan sát lại rồi tính tiếp.',
      en: 'Acts online: commits only the current month’s policy, then observes again before planning the next month.',
    },
    application: {
      vi: 'Ở mỗi bước, LRTA* nhìn lại trạng thái hiện tại cùng khủng hoảng đang active, cập nhật H(trạng thái), chọn một chính sách, rồi tháng sau mới tính tiếp.',
      en: 'At each step, LRTA* observes the current state and active crises, updates H(state), chooses one policy, then recalculates next month.',
    },
    complexity: 'Per move: O(b) • Learning memory: O(visited states)',
    pseudocode: {
      vi: `LRTA_STAR(trạng_thái, độ_sâu):
    lặp từ 1 đến độ_sâu:
        quan_sát trạng_thái hiện tại và khủng_hoảng_active
        với mỗi chính_sách a:
            con ← RESULT(trạng_thái, a)
            giá_trị(a) ← chi_phí(a) + H(con) - ưu_tiên_xử_lý_khủng_hoảng
        H(trạng_thái) ← min giá_trị(a)
        chọn chính_sách có giá_trị nhỏ nhất
        áp_dụng chính_sách, qua 1 tháng, quan_sát trạng_thái mới`,
      en: `LRTA_STAR(state, learning_months):
    repeat from 1 to learning_months:
        observe current state and active crises
        for each policy a:
            child ← RESULT(state, a)
            value(a) ← cost(a) + H(child) - crisis_response_priority
        H(state) ← minimum action value
        choose the minimum-value policy
        apply policy, advance 1 month, observe new state`,
    },
  },
  'Constraint Propagation': {
    family: { vi: 'Bài toán thỏa mãn ràng buộc', en: 'Constraint satisfaction' },
    summary: {
      vi: 'Dùng AC-3 để loại các giá trị không có hỗ trợ trong miền của biến khác.',
      en: 'Uses AC-3 to remove values that have no supporting value in neighboring variable domains.',
    },
    application: {
      vi: 'Mỗi vị trí trong kế hoạch là một biến; miền là chính sách. Ràng buộc gồm không lặp, không xung đột và đủ ngân sách.',
      en: 'Each plan position is a variable with policies as its domain. Constraints cover uniqueness, incompatibility and affordability.',
    },
    complexity: 'AC-3: O(e d³)',
    pseudocode: {
      vi: `AC3(CSP):
    queue ← mọi cung (Xi, Xj)
    trong khi queue không rỗng:
        (Xi, Xj) ← lấy một cung
        nếu REVISE(Xi, Xj):
            nếu miền(Xi) rỗng: thất_bại
            thêm (Xk, Xi) với mọi láng_giềng Xk
    trả về các miền đã rút gọn

REVISE(Xi, Xj):
    xóa x nếu không tồn tại y thỏa ràng_buộc(x, y)`,
      en: `AC3(CSP):
    queue ← all arcs (Xi, Xj)
    while queue is not empty:
        (Xi, Xj) ← remove an arc
        if REVISE(Xi, Xj):
            if domain(Xi) is empty: fail
            add (Xk, Xi) for every neighbor Xk
    return reduced domains

REVISE(Xi, Xj):
    remove x when no y supports constraint(x, y)`,
    },
  },
  'Backtracking CSP': {
    family: { vi: 'Bài toán thỏa mãn ràng buộc', en: 'Constraint satisfaction' },
    summary: {
      vi: 'Gán biến đệ quy, quay lui khi gán hiện tại vi phạm ràng buộc.',
      en: 'Recursively assigns variables and backtracks whenever the current assignment violates a constraint.',
    },
    application: {
      vi: 'Triển khai dùng MRV để chọn biến có ít giá trị hợp lệ nhất và forward checking để phát hiện miền rỗng sớm.',
      en: 'The implementation uses MRV to select the tightest variable and forward checking to detect empty domains early.',
    },
    complexity: 'Worst case: O(d^n)',
    pseudocode: {
      vi: `BACKTRACK(gán):
    nếu gán đầy đủ: trả về gán
    biến ← chọn biến chưa gán bằng MRV
    với mỗi giá_trị hợp_lệ:
        gán biến ← giá_trị
        nếu nhất_quán và forward_check thành_công:
            kết_quả ← BACKTRACK(gán)
            nếu thành_công: lưu nghiệm
        bỏ gán biến
    quay_lui`,
      en: `BACKTRACK(assignment):
    if assignment is complete: return assignment
    variable ← select unassigned variable with MRV
    for each legal value:
        assign variable ← value
        if consistent and forward_check succeeds:
            result ← BACKTRACK(assignment)
            if successful: record solution
        remove assignment
    backtrack`,
    },
  },
  'Min-Conflicts CSP': {
    family: { vi: 'Tìm kiếm cục bộ cho CSP', en: 'Local search for CSP' },
    summary: {
      vi: 'Bắt đầu từ một gán đầy đủ rồi liên tục thay giá trị của biến đang xung đột.',
      en: 'Starts from a complete assignment and repeatedly changes a variable involved in a conflict.',
    },
    application: {
      vi: 'Xung đột gồm chính sách trùng, cặp chính sách đối nghịch, vượt ngân sách và bỏ sót nhu cầu khẩn cấp.',
      en: 'Conflicts include duplicate policies, incompatible pairs, budget violations and ignored urgent needs.',
    },
    complexity: 'Typically near-linear per repair step; incomplete',
    pseudocode: {
      vi: `MIN_CONFLICTS(CSP, max_steps):
    current ← một gán đầy đủ ngẫu nhiên
    lặp max_steps lần:
        nếu current không có xung_đột: trả về current
        var ← chọn ngẫu nhiên biến đang xung_đột
        value ← giá_trị tạo ít xung_đột nhất
        current[var] ← value
    trả về gán tốt nhất đã gặp`,
      en: `MIN_CONFLICTS(CSP, max_steps):
    current ← a random complete assignment
    repeat max_steps times:
        if current has no conflicts: return current
        var ← randomly choose a conflicted variable
        value ← value producing the fewest conflicts
        current[var] ← value
    return best assignment seen`,
    },
  },
  Minimax: {
    family: { vi: 'Tìm kiếm đối kháng', en: 'Adversarial search' },
    summary: {
      vi: 'MAX chọn chính sách tốt nhất trong khi MIN chọn khủng hoảng gây thiệt hại lớn nhất.',
      en: 'MAX selects the best policy while MIN selects the most damaging crisis outcome.',
    },
    application: {
      vi: 'Một lượt gồm nút chính phủ MAX và nút môi trường MIN. Giá trị lá là điểm quốc gia sau chuỗi quyết định–khủng hoảng.',
      en: 'A turn contains a government MAX node and an environment MIN node. Leaves are evaluated by national score.',
    },
    complexity: 'Time: O(b^m) • Space: O(bm)',
    pseudocode: {
      vi: `MAX_VALUE(s, d):
    nếu d = 0: trả về EVALUATE(s)
    v ← -∞
    với mỗi chính_sách a:
        v ← max(v, MIN_VALUE(RESULT(s,a), d-1))
    trả về v

MIN_VALUE(s, d):
    v ← +∞
    với mỗi khủng_hoảng e:
        v ← min(v, MAX_VALUE(RESULT(s,e), d))
    trả về v`,
      en: `MAX_VALUE(s, d):
    if d = 0: return EVALUATE(s)
    v ← -∞
    for each policy a:
        v ← max(v, MIN_VALUE(RESULT(s,a), d-1))
    return v

MIN_VALUE(s, d):
    v ← +∞
    for each crisis e:
        v ← min(v, MAX_VALUE(RESULT(s,e), d))
    return v`,
    },
  },
  'Alpha-Beta': {
    family: { vi: 'Tìm kiếm đối kháng', en: 'Adversarial search' },
    summary: {
      vi: 'Cho kết quả như Minimax nhưng bỏ qua các nhánh không thể ảnh hưởng quyết định cuối.',
      en: 'Produces the same decision as Minimax while skipping branches that cannot change the final choice.',
    },
    application: {
      vi: 'Các chính sách được sắp theo giá trị trước khi duyệt để tăng khả năng cắt tỉa.',
      en: 'Policies are ordered by strategic value before expansion to improve pruning effectiveness.',
    },
    complexity: 'Best case: O(b^(m/2)) • Worst: O(b^m)',
    pseudocode: {
      vi: `ALPHA_BETA(s, d, α, β, maximizing):
    nếu d = 0: trả về EVALUATE(s)
    nếu maximizing:
        v ← -∞
        với mỗi con:
            v ← max(v, ALPHA_BETA(con, d-1, α, β, false))
            α ← max(α, v)
            nếu α ≥ β: cắt_tỉa
    ngược_lại:
        v ← +∞
        với mỗi con:
            v ← min(v, ALPHA_BETA(con, d, α, β, true))
            β ← min(β, v)
            nếu α ≥ β: cắt_tỉa
    trả về v`,
      en: `ALPHA_BETA(s, d, α, β, maximizing):
    if d = 0: return EVALUATE(s)
    if maximizing:
        v ← -∞
        for each child:
            v ← max(v, ALPHA_BETA(child, d-1, α, β, false))
            α ← max(α, v)
            if α ≥ β: prune
    else:
        v ← +∞
        for each child:
            v ← min(v, ALPHA_BETA(child, d, α, β, true))
            β ← min(β, v)
            if α ≥ β: prune
    return v`,
    },
  },
  Expectimax: {
    family: { vi: 'Tìm kiếm đối kháng có xác suất', en: 'Stochastic adversarial search' },
    summary: {
      vi: 'Thay nút MIN bằng nút cơ hội và tính giá trị kỳ vọng theo xác suất các sự kiện.',
      en: 'Replaces MIN nodes with chance nodes and computes probability-weighted expected utility.',
    },
    application: {
      vi: 'Hệ thống xét trường hợp không có sự kiện cùng các khủng hoảng ngẫu nhiên, chuẩn hóa xác suất rồi tối đa hóa điểm kỳ vọng.',
      en: 'The simulator considers no-event and random-crisis outcomes, normalizes their probabilities and maximizes expected score.',
    },
    complexity: 'Time: O((b × c)^d)',
    pseudocode: {
      vi: `MAX_VALUE(s, d):
    nếu d = 0: trả về EVALUATE(s)
    trả về max theo chính_sách của CHANCE_VALUE(RESULT(s,a), d-1)

CHANCE_VALUE(s, d):
    tổng ← 0
    với mỗi kết_quả i:
        tổng ← tổng + P(i) × MAX_VALUE(RESULT(s,i), d)
    trả về tổng`,
      en: `MAX_VALUE(s, d):
    if d = 0: return EVALUATE(s)
    return max over policies of CHANCE_VALUE(RESULT(s,a), d-1)

CHANCE_VALUE(s, d):
    total ← 0
    for each outcome i:
        total ← total + P(i) × MAX_VALUE(RESULT(s,i), d)
    return total`,
    },
  },
};

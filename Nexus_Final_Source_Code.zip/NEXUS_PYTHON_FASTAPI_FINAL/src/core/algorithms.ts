import { AlgorithmResult, NationState, Policy } from './types';
import { AIAdvancedSettings, DEFAULT_AI_SETTINGS } from './aiSettings';
import { EVENTS, POLICIES } from './data';
import {
  applyPolicyToState as applyPolicyEffectToState,
  advanceMonth,
  clampState,
  evaluateState,
  getAdjustedEventProbability,
  isNationCollapsed,
} from './state';

type SearchFn = (state: NationState, depth?: number, settings?: AIAdvancedSettings) => AlgorithmResult;

type SearchNode = {
  state: NationState;
  path: string[];
  depth: number;
  g: number;
};

type InternalResult = {
  best: string[];
  state: NationState;
  nodes: number;
  score?: number;
  algorithmValue?: number;
  valueLabel?: string;
  improvementReached?: boolean;
  goalReached?: boolean;
  effectiveDepth?: number;
  executionMode?: 'planned' | 'online';
  displayPolicies?: Array<string | null>;
  debug?: AlgorithmResult['debug'];
  conditionalPlan?: AlgorithmResult['conditionalPlan'];
};

type ValueResult = {
  value: number;
  state: NationState;
  path: string[];
  conditionalPlan?: Record<string, unknown> | null;
  label?: string;
};

type WeightedState = {
  state: NationState;
  probability: number;
  label: string;
};

type ConflictReport = {
  hard: number;
  soft: number;
  score: number;
  state: NationState | null;
};

const MAX_NODES = 35_000;
const EPSILON = 1e-9;
const CSP_HARD_WEIGHT = 1_000;
const NO_POLICY_ID = '__no_policy__';
const NO_POLICY: Policy = {
  id: NO_POLICY_ID,
  name: 'Không ban hành chính sách mới',
  category: 'Vận hành',
  description: 'Giữ nguyên chính sách trong tháng này để tránh can thiệp quá mức khi các lựa chọn đều kém hiệu quả.',
  cost: 0,
  effect: {},
};

const withSettings = (settings?: AIAdvancedSettings): AIAdvancedSettings => settings ?? DEFAULT_AI_SETTINGS;

const NUMERIC_KEYS: Array<Exclude<keyof NationState, 'active_events'>> = [
  'gdp',
  'budget',
  'debt',
  'taxRate',
  'inflation',
  'unemployment',
  'happiness',
  'education',
  'healthcare',
  'energy',
  'environment',
  'military',
  'technology',
  'cybersecurity',
  'infrastructure',
  'diplomacy',
  'population',
  'month',
  'year',
];

const POSITIVE_KEYS: Array<keyof NationState> = [
  'happiness',
  'education',
  'healthcare',
  'energy',
  'environment',
  'military',
  'technology',
  'cybersecurity',
  'infrastructure',
  'diplomacy',
];

const POLICY_REVERSAL_PAIRS: Array<[string, string]> = [
  ['tax_up', 'tax_down'],
  ['borrow', 'pay_debt'],
  ['austerity', 'welfare'],
  ['austerity', 'job_program'],
  ['power_plant', 'green_energy'],
  ['military', 'diplomacy'],
];

const isPolicyReversal = (left: string, right: string): boolean =>
  POLICY_REVERSAL_PAIRS.some(([a, b]) => (left === a && right === b) || (left === b && right === a));

const measure = (algorithm: string, fn: () => InternalResult): AlgorithmResult => {
  const start = performance.now();
  const result = fn();
  const end = performance.now();
  const rawPlanPreview = result.displayPolicies ?? result.best;
  const normalizedPreview = rawPlanPreview.map((policyId) => policyId === NO_POLICY_ID ? null : policyId);
  const firstInternalStep = result.best[0] ?? rawPlanPreview.find((policyId): policyId is string => typeof policyId === 'string' && policyId.length > 0) ?? null;
  const recommendedPolicyId = firstInternalStep && firstInternalStep !== NO_POLICY_ID ? firstInternalStep : null;

  return {
    algorithm,
    // bestPolicies is the internal search trace/forecast. It is intentionally
    // not treated as an execution plan by the UI; only recommendedPolicyId is
    // applied to the next game month.
    bestPolicies: result.best.filter((policyId) => policyId !== NO_POLICY_ID),
    recommendedPolicyId,
    planPreview: normalizedPreview,
    projectedState: result.state,
    score: Number((result.score ?? evaluateState(result.state)).toFixed(2)),
    nodesExpanded: Math.max(1, result.nodes),
    runtimeMs: Number((end - start).toFixed(2)),
    algorithmValue: result.algorithmValue ?? result.score,
    valueLabel: result.valueLabel,
    improvementReached: result.improvementReached ?? result.goalReached ?? false,
    goalReached: result.goalReached ?? result.improvementReached ?? false,
    effectiveDepth: result.effectiveDepth ?? Math.max(1, normalizedPreview.length),
    executionMode: result.executionMode ?? 'planned',
    displayPolicies: normalizedPreview,
    debug: result.debug,
    conditionalPlan: result.conditionalPlan ?? null,
  };
};

const cloneState = (state: NationState): NationState => ({
  ...state,
  active_events: [...state.active_events],
  recentPolicies: [...(state.recentPolicies ?? [])].slice(-6),
});

const applyPolicyToState = (state: NationState, policy: Policy): NationState => {
  if (policy.id === NO_POLICY_ID) {
    return advanceMonth({
      ...cloneState(state),
      recentPolicies: [...(state.recentPolicies ?? []), NO_POLICY_ID].slice(-6),
    });
  }
  const afterPolicy = applyPolicyEffectToState(state, policy);
  return advanceMonth(afterPolicy);
};

const roundTo = (value: number, step: number): number => Math.round(value / step) * step;

const bounded = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

const stateKey = (state: NationState): string => [
  roundTo(state.gdp, 25),
  roundTo(state.budget, 25),
  roundTo(state.debt, 50),
  roundTo(state.taxRate, 1),
  roundTo(state.inflation, 0.5),
  roundTo(state.unemployment, 0.5),
  roundTo(state.happiness, 2),
  roundTo(state.education, 2),
  roundTo(state.healthcare, 2),
  roundTo(state.energy, 2),
  roundTo(state.environment, 2),
  roundTo(state.technology, 2),
  roundTo(state.cybersecurity, 2),
  roundTo(state.infrastructure, 2),
  roundTo(state.diplomacy, 2),
].join('|');

const strategicDistance = (state: NationState): number => {
  const positiveTargets: Array<[number, number, number]> = [
    [state.happiness, 85, 1.25],
    [state.education, 80, 1],
    [state.healthcare, 80, 1],
    [state.energy, 80, 0.85],
    [state.environment, 80, 0.85],
    [state.technology, 75, 0.85],
    [state.cybersecurity, 80, 0.9],
    [state.infrastructure, 80, 0.9],
    [state.diplomacy, 75, 0.75],
  ];

  const positiveGap = positiveTargets.reduce(
    (sum, [value, target, weight]) => sum + Math.max(0, target - value) * weight,
    0,
  );
  const inflationGap = Math.abs(state.inflation - 2.5) * 4.2 + Math.max(0, state.inflation - 8) * 3;
  const unemploymentGap = Math.max(0, state.unemployment - 4) * 4.6;
  const debtRatio = state.debt / Math.max(1, state.gdp);
  const debtGap = Math.max(0, debtRatio - 0.32) * 220 + Math.max(0, debtRatio - 0.6) * 180;
  const fiscalGap = Math.max(0, 120 - state.budget) * 0.08;
  const taxGap = Math.max(0, state.taxRate - 30) * 5 + Math.max(0, 16 - state.taxRate) * 4.2 + Math.max(0, 10 - state.taxRate) * 5;

  return positiveGap + inflationGap + unemploymentGap + debtGap + fiscalGap + taxGap;
};

const hasImprovedEnough = (initialState: NationState, state: NationState): boolean =>
  evaluateState(state) > evaluateState(initialState) + 5 || strategicDistance(state) < strategicDistance(initialState) - 15;

const isTerminalBadState = (state: NationState): boolean => isNationCollapsed(state) || evaluateState(state) <= -99_999;

const hasEconomicEmergency = (state: NationState): boolean => {
  const debtRatio = state.debt / Math.max(1, state.gdp);
  return state.budget < 75 || state.inflation > 7.5 || state.unemployment > 10 || state.taxRate < 15 || state.taxRate > 29 || debtRatio > 0.65;
};

const isTemporarilyDiscouragedPolicy = (state: NationState, policy: Policy): boolean => {
  const recent = [...(state.recentPolicies ?? [])].filter((policyId) => policyId !== NO_POLICY_ID).slice(-4);
  if (recent.length === 0) return false;

  const previousPolicyId = recent.at(-1);
  const sameCategoryCount = recent.filter((policyId) => getPolicy(policyId)?.category === policy.category).length;
  const economicEmergency = hasEconomicEmergency(state);
  const debtRatio = state.debt / Math.max(1, state.gdp);

  if (previousPolicyId === policy.id) return true;
  if (recent.includes(policy.id)) return true;
  if (recent.some((policyId) => isPolicyReversal(policyId, policy.id))) return true;
  if (sameCategoryCount >= 3) return true;
  if (policy.category === 'Kinh tế' && sameCategoryCount >= 2 && !economicEmergency) return true;

  if (policy.id === 'borrow' && (state.budget > 85 || debtRatio > 0.5)) return true;
  if (policy.id === 'pay_debt' && debtRatio < 0.35) return true;
  if (policy.id === 'tax_up' && (state.taxRate >= 28 || (state.budget > 120 && !economicEmergency))) return true;
  if (policy.id === 'tax_down' && (state.taxRate <= 16 || state.budget < 90)) return true;
  if (policy.id === 'austerity' && (state.inflation < 4.5 || state.unemployment > 9 || state.happiness < 62)) return true;

  return false;
};

const getAvailablePolicies = (state: NationState): Policy[] => {
  const affordable = [...POLICIES.filter((policy) => policy.cost <= state.budget), NO_POLICY];
  if (affordable.length <= 1) return affordable;

  const diversified = affordable.filter((policy) => !isTemporarilyDiscouragedPolicy(state, policy));
  return diversified.length > 0 ? diversified : affordable;
};

const getPolicy = (policyId: string): Policy | undefined => POLICIES.find((policy) => policy.id === policyId);

const planChurnPenalty = (path: string[]): number => {
  let penalty = 0;
  const categoryCounts: Record<string, number> = {};

  for (let index = 0; index < path.length; index += 1) {
    const policyId = path[index];
    const previous = path[index - 1];
    const policy = getPolicy(policyId);
    if (policy) categoryCounts[policy.category] = (categoryCounts[policy.category] ?? 0) + 1;
    const recentBefore = path.slice(Math.max(0, index - 4), index);
    if (!previous) continue;
    if (previous === policyId) penalty += 24;
    if (isPolicyReversal(previous, policyId)) penalty += 34;
    if (recentBefore.includes(policyId)) penalty += 18;
    if (recentBefore.some((recentPolicyId) => isPolicyReversal(recentPolicyId, policyId))) penalty += 26;
  }

  const dominantCategory = Math.max(0, ...Object.values(categoryCounts));
  if (path.length >= 4 && dominantCategory > Math.ceil(path.length * 0.58)) {
    penalty += (dominantCategory - Math.ceil(path.length * 0.58)) * 26;
  }

  return penalty;
};

const nodeSelectionScore = (node: SearchNode): number =>
  evaluateState(node.state) - planChurnPenalty((node.state.recentPolicies ?? node.path).slice(-6)) * 0.85;

const policyInvestmentCredit = (before: NationState, policy: Policy, after: NationState): number => {
  const foundationGain = POSITIVE_KEYS.reduce((sum, key) => {
    const beforeValue = Number(before[key]);
    const afterValue = Number(after[key]);
    return sum + Math.max(0, afterValue - beforeValue);
  }, 0);
  const laborGain = Math.max(0, before.unemployment - after.unemployment) * 1.1;
  const priceGain = Math.max(0, before.inflation - after.inflation) * 0.9;
  const debtFundedCash = Math.max(0, after.debt - before.debt);
  const organicBudgetGain = Math.max(0, after.budget - before.budget - debtFundedCash);
  const fiscalGain = Math.max(0, before.debt - after.debt) / 90 + organicBudgetGain / 160;
  const immediateScoreGain = Math.max(0, evaluateState(after) - evaluateState(before)) / 95;
  const responseNeedBonus =
    (before.unemployment > 9 && Number(policy.effect.unemployment ?? 0) < 0 ? 0.7 : 0) +
    (before.inflation > 6 && Number(policy.effect.inflation ?? 0) < 0 ? 0.7 : 0) +
    (before.cybersecurity < 45 && Number(policy.effect.cybersecurity ?? 0) > 0 ? 0.6 : 0) +
    (before.environment < 50 && Number(policy.effect.environment ?? 0) > 0 ? 0.5 : 0) +
    (before.taxRate > 28 && Number(policy.effect.taxRate ?? 0) < 0 ? 0.8 : 0) +
    (before.taxRate < 16 && Number(policy.effect.taxRate ?? 0) > 0 ? 0.8 : 0) +
    (before.budget < 70 && before.debt / Math.max(1, before.gdp) < 0.45 && policy.id === 'borrow' ? 0.8 : 0);

  return Math.min(4.5, foundationGain * 0.08 + laborGain + priceGain + fiscalGain + immediateScoreGain + responseNeedBonus);
};

const policySequencePenalty = (policyId: string, recentPath: string[] = []): number => {
  const previousPolicy = recentPath.at(-1);
  const recentWindow = recentPath.slice(-4);
  const policy = getPolicy(policyId);
  const repeatPenalty = previousPolicy === policyId ? 14 : 0;
  const reversalPenalty = previousPolicy && isPolicyReversal(previousPolicy, policyId) ? 18 : 0;
  const recentReusePenalty = recentWindow.includes(policyId) && previousPolicy !== policyId ? 11 : 0;
  const recentReversalPenalty = recentWindow.some((id) => isPolicyReversal(id, policyId)) ? 25 : 0;
  const sameCategoryCount = recentWindow.filter((id) => getPolicy(id)?.category === policy?.category).length;
  const concentrationPenalty = sameCategoryCount >= 2 ? sameCategoryCount * 12 : 0;
  const economicCyclePenalty = policy?.category === 'Kinh tế' && sameCategoryCount >= 2 ? 22 : 0;
  return repeatPenalty + reversalPenalty + recentReusePenalty + recentReversalPenalty + concentrationPenalty + economicCyclePenalty;
};

const transitionCostBreakdown = (before: NationState, policy: Policy, after: NationState, recentPath: string[] = []) => {
  const beforeScore = evaluateState(before);
  const afterScore = evaluateState(after);
  const directBudgetCost = Math.max(0, policy.cost) / 48;
  const socialLossCost = POSITIVE_KEYS.reduce((sum, key) => {
    const beforeValue = Number(before[key]);
    const afterValue = Number(after[key]);
    return sum + Math.max(0, beforeValue - afterValue) * 0.75;
  }, 0);
  const inflationPenalty = Math.max(0, after.inflation - before.inflation) * 3.2 + Math.max(0, after.inflation - 8) * 2.5;
  const unemploymentPenalty = Math.max(0, after.unemployment - before.unemployment) * 3.8;
  const debtRatioBefore = before.debt / Math.max(1, before.gdp);
  const debtRatioAfter = after.debt / Math.max(1, after.gdp);
  const debtPenalty =
    Math.max(0, debtRatioAfter - debtRatioBefore) * 240 +
    Math.max(0, debtRatioAfter - 0.45) * 180 +
    Math.max(0, debtRatioAfter - 0.8) * 250;
  const reservePenalty = Math.max(0, 90 - after.budget) * 0.08;
  const taxDriftPenalty = ['tax_up', 'tax_down'].includes(policy.id)
    ? Math.max(0, Math.abs(after.taxRate - 20) - Math.abs(before.taxRate - 20)) * 1.6 +
      Math.max(0, 16 - after.taxRate) * 0.8 +
      Math.max(0, after.taxRate - 30) * 0.8
    : 0;
  const usefulProgressPenalty = Math.max(0, 10 - (afterScore - beforeScore)) * 0.75;
  const scoreDownside = Math.max(0, beforeScore - afterScore) / 28;
  const administrativeChurnCost = policy.id === 'borrow'
    ? 30
    : ['tax_up', 'tax_down'].includes(policy.id)
      ? 22
      : policy.id === 'austerity'
        ? 20
        : 0;
  const sequencePenalty = policySequencePenalty(policy.id, [...(before.recentPolicies ?? []), ...recentPath].slice(-6));
  const investmentCredit = policyInvestmentCredit(before, policy, after);
  const collapsePenalty = isTerminalBadState(after) ? 10_000 : 0;
  const baseActionCost = 1;
  const total = Math.max(
    0.15,
    baseActionCost +
      directBudgetCost +
      socialLossCost +
      inflationPenalty +
      unemploymentPenalty +
      debtPenalty +
      reservePenalty +
      taxDriftPenalty +
      usefulProgressPenalty +
      scoreDownside +
      administrativeChurnCost +
      sequencePenalty +
      collapsePenalty -
      investmentCredit,
  );

  return {
    directBudgetCost: Number(directBudgetCost.toFixed(2)),
    socialLossCost: Number(socialLossCost.toFixed(2)),
    inflationPenalty: Number(inflationPenalty.toFixed(2)),
    unemploymentPenalty: Number(unemploymentPenalty.toFixed(2)),
    debtPenalty: Number(debtPenalty.toFixed(2)),
    reservePenalty: Number(reservePenalty.toFixed(2)),
    taxDriftPenalty: Number(taxDriftPenalty.toFixed(2)),
    usefulProgressPenalty: Number(usefulProgressPenalty.toFixed(2)),
    scoreDownside: Number(scoreDownside.toFixed(2)),
    administrativeChurnCost: Number(administrativeChurnCost.toFixed(2)),
    sequencePenalty: Number(sequencePenalty.toFixed(2)),
    investmentCredit: Number(investmentCredit.toFixed(2)),
    collapsePenalty: Number(collapsePenalty.toFixed(2)),
    baseActionCost,
    total: Number(total.toFixed(2)),
  };
};

const transitionCost = (before: NationState, policy: Policy, after: NationState, recentPath: string[] = []): number =>
  transitionCostBreakdown(before, policy, after, recentPath).total;

const firstPolicyCostDebug = (initialState: NationState, policyId?: string | null) => {
  if (!policyId) return undefined;
  const policy = getPolicy(policyId);
  if (!policy || policy.cost > initialState.budget) return undefined;
  const next = applyPolicyToState(initialState, policy);
  return {
    policyId,
    budgetCostB: Number(policy.cost.toFixed(2)),
    ...transitionCostBreakdown(initialState, policy, next),
  };
};

const compareScore = (left: SearchNode, right: SearchNode): number => {
  const actionBias = 6;
  const leftScore = nodeSelectionScore(left) + (left.path.length > 0 ? actionBias : 0);
  const rightScore = nodeSelectionScore(right) + (right.path.length > 0 ? actionBias : 0);
  return leftScore - rightScore;
};

const averageStates = (weightedStates: WeightedState[]): NationState => {
  const total = weightedStates.reduce((sum, item) => sum + item.probability, 0) || 1;
  const base = cloneState(weightedStates[0]?.state ?? ({} as NationState));

  for (const key of NUMERIC_KEYS) {
    const value = weightedStates.reduce(
      (sum, item) => sum + Number(item.state[key]) * item.probability,
      0,
    ) / total;
    (base[key] as number) = value;
  }

  base.month = Math.round(base.month);
  base.year = Math.round(base.year);
  base.population = Math.round(base.population);
  base.active_events = [...new Set(weightedStates.flatMap((item) => item.state.active_events))].slice(-5);
  return clampState(base);
};

const planState = (initial: NationState, policyIds: string[]): NationState | null => {
  let current = cloneState(initial);
  for (const policyId of policyIds) {
    const policy = getPolicy(policyId);
    if (!policy || policy.cost > current.budget) return null;
    current = applyPolicyToState(current, policy);
  }
  return current;
};

const hashString = (input: string): number => {
  let hash = 2166136261;
  for (let index = 0; index < input.length; index += 1) {
    hash ^= input.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
};

const createRng = (seed: number) => {
  let value = seed || 1;
  return () => {
    value = (Math.imul(value, 1664525) + 1013904223) >>> 0;
    return value / 0x1_0000_0000;
  };
};

class MinPriorityQueue<T> {
  private items: Array<{ item: T; priority: number; order: number }> = [];
  private order = 0;

  push(item: T, priority: number) {
    this.items.push({ item, priority, order: this.order });
    this.order += 1;
  }

  pop(): T | undefined {
    if (this.items.length === 0) return undefined;
    let bestIndex = 0;
    for (let index = 1; index < this.items.length; index += 1) {
      const current = this.items[index];
      const best = this.items[bestIndex];
      if (
        current.priority < best.priority - EPSILON ||
        (Math.abs(current.priority - best.priority) <= EPSILON && current.order < best.order)
      ) {
        bestIndex = index;
      }
    }
    return this.items.splice(bestIndex, 1)[0].item;
  }

  get size() {
    return this.items.length;
  }
}

// 1. Breadth-First Search: FIFO frontier, no heuristic ordering and no early goal stop.
export const bfs: SearchFn = (initialState, requestedDepth = 2) =>
  measure('BFS', () => {
    const depth = Math.max(1, Math.min(5, requestedDepth));
    const queue: SearchNode[] = [{ state: cloneState(initialState), path: [], depth: 0, g: 0 }];
    const visited = new Set<string>([`root@0@${stateKey(initialState)}`]);
    let head = 0;
    let nodes = 0;
    let bestNode = queue[0];

    while (head < queue.length && nodes < MAX_NODES) {
      const node = queue[head++];
      nodes += 1;
      if (compareScore(node, bestNode) > EPSILON) bestNode = node;
      if (node.depth >= depth) continue;

      for (const policy of getAvailablePolicies(node.state)) {
        const next = applyPolicyToState(node.state, policy);
        const path = [...node.path, policy.id];
        const firstPolicy = path[0] ?? policy.id;
        const key = `${firstPolicy}@${node.depth + 1}@${stateKey(next)}`;
        if (visited.has(key)) continue;
        visited.add(key);
        queue.push({
          state: next,
          path,
          depth: node.depth + 1,
          g: node.g + transitionCost(node.state, policy, next, node.path),
        });
        if (queue.length > MAX_NODES * 4) break;
      }
    }

    return {
      best: bestNode.path,
      state: bestNode.state,
      nodes,
      improvementReached: hasImprovedEnough(initialState, bestNode.state),
      effectiveDepth: depth,
      debug: { traversalMode: 'FIFO breadth-first' },
    };
  });

// 2. Depth-First Search: stable deep traversal with backtracking and best-so-far by evaluateState().
export const dfs: SearchFn = (initialState, requestedDepth = 3) =>
  measure('DFS', () => {
    const depth = Math.max(1, Math.min(5, requestedDepth));
    let nodes = 0;
    let bestNode: SearchNode = { state: cloneState(initialState), path: [], depth: 0, g: 0 };

    const visit = (node: SearchNode, pathKeys: Set<string>) => {
      if (nodes >= MAX_NODES) return;
      nodes += 1;
      if (compareScore(node, bestNode) > EPSILON) bestNode = node;
      if (node.depth >= depth) return;

      for (const policy of getAvailablePolicies(node.state)) {
        const next = applyPolicyToState(node.state, policy);
        const key = `${node.depth + 1}@${stateKey(next)}`;
        if (pathKeys.has(key)) continue;
        pathKeys.add(key);
        visit({
          state: next,
          path: [...node.path, policy.id],
          depth: node.depth + 1,
          g: node.g + transitionCost(node.state, policy, next, node.path),
        }, pathKeys);
        pathKeys.delete(key);
        if (nodes >= MAX_NODES) return;
      }
    };

    visit(bestNode, new Set([`0@${stateKey(initialState)}`]));
    return {
      best: bestNode.path,
      state: bestNode.state,
      nodes,
      improvementReached: hasImprovedEnough(initialState, bestNode.state),
      effectiveDepth: depth,
      debug: { traversalMode: 'stable depth-first' },
    };
  });

// 3. Iterative Deepening Search: repeated depth-limited DFS from 1..limit, preserving DFS order.
export const ids: SearchFn = (initialState, requestedDepth = 3) =>
  measure('IDS', () => {
    const depth = Math.max(1, Math.min(5, requestedDepth));
    let nodes = 0;
    let bestNode: SearchNode = { state: cloneState(initialState), path: [], depth: 0, g: 0 };

    for (let limit = 1; limit <= depth && nodes < MAX_NODES; limit += 1) {
      const depthLimited = (node: SearchNode, pathKeys: Set<string>) => {
        if (nodes >= MAX_NODES) return;
        nodes += 1;
        if (compareScore(node, bestNode) > EPSILON) bestNode = node;
        if (node.depth >= limit) return;

        for (const policy of getAvailablePolicies(node.state)) {
          const next = applyPolicyToState(node.state, policy);
          const key = `${node.depth + 1}@${stateKey(next)}`;
          if (pathKeys.has(key)) continue;
          pathKeys.add(key);
          depthLimited({
            state: next,
            path: [...node.path, policy.id],
            depth: node.depth + 1,
            g: node.g + transitionCost(node.state, policy, next, node.path),
          }, pathKeys);
          pathKeys.delete(key);
          if (nodes >= MAX_NODES) return;
        }
      };

      depthLimited({ state: cloneState(initialState), path: [], depth: 0, g: 0 }, new Set([`0@${stateKey(initialState)}`]));
    }

    return {
      best: bestNode.path,
      state: bestNode.state,
      nodes,
      improvementReached: hasImprovedEnough(initialState, bestNode.state),
      effectiveDepth: depth,
      debug: { traversalMode: 'iterative deepening DFS' },
    };
  });

// 4. Uniform-Cost Search: priority and selection are cumulative strategic transition cost g(n).
export const ucs: SearchFn = (initialState, requestedDepth = 3) =>
  measure('UCS', () => {
    const depth = Math.max(1, Math.min(5, requestedDepth));
    const frontier = new MinPriorityQueue<SearchNode>();
    const start: SearchNode = { state: cloneState(initialState), path: [], depth: 0, g: 0 };
    frontier.push(start, 0);
    const bestCost = new Map<string, number>([[`0@${stateKey(initialState)}`, 0]]);
    let nodes = 0;
    let bestTerminal: SearchNode | null = null;
    let bestExpanded: SearchNode | null = null;

    while (frontier.size > 0 && nodes < MAX_NODES) {
      const node = frontier.pop()!;
      nodes += 1;
      if (node.path.length > 0 && (!bestExpanded || node.g < bestExpanded.g - EPSILON)) bestExpanded = node;
      if (node.depth >= depth) {
        if (!bestTerminal || node.g < bestTerminal.g - EPSILON) bestTerminal = node;
        continue;
      }

      const policies = getAvailablePolicies(node.state);
      if (policies.length === 0 && node.path.length > 0) {
        if (!bestTerminal || node.g < bestTerminal.g - EPSILON) bestTerminal = node;
        continue;
      }

      for (const policy of policies) {
        const next = applyPolicyToState(node.state, policy);
        const g = node.g + transitionCost(node.state, policy, next, node.path);
        const key = `${node.depth + 1}@${stateKey(next)}`;
        const known = bestCost.get(key);
        if (known !== undefined && known <= g + EPSILON) continue;
        bestCost.set(key, g);
        frontier.push({ state: next, path: [...node.path, policy.id], depth: node.depth + 1, g }, g);
      }
    }

    const result = bestTerminal ?? bestExpanded ?? start;
    return {
      best: result.path,
      state: result.state,
      nodes,
      score: -result.g,
      algorithmValue: -result.g,
      valueLabel: 'lowest cumulative search cost',
      improvementReached: hasImprovedEnough(initialState, result.state),
      effectiveDepth: depth,
      debug: { totalSearchCost: Number(result.g.toFixed(2)), firstStepCost: firstPolicyCostDebug(initialState, result.path[0]) ?? null },
    };
  });

// 5. Greedy Best-First Search: priority is strategicDistance h(n), not path cost or score.
export const greedyBestFirst: SearchFn = (initialState, requestedDepth = 3) =>
  measure('Greedy Best-First', () => {
    const depth = Math.max(1, Math.min(5, requestedDepth));
    const frontier = new MinPriorityQueue<SearchNode>();
    const start: SearchNode = { state: cloneState(initialState), path: [], depth: 0, g: 0 };
    frontier.push(start, strategicDistance(initialState));
    const visited = new Set<string>();
    let nodes = 0;
    let bestNode = start;

    while (frontier.size > 0 && nodes < MAX_NODES) {
      const node = frontier.pop()!;
      const key = `${node.depth}@${stateKey(node.state)}`;
      if (visited.has(key)) continue;
      visited.add(key);
      nodes += 1;
      if (strategicDistance(node.state) < strategicDistance(bestNode.state) - EPSILON) bestNode = node;
      if (node.depth >= depth) continue;

      for (const policy of getAvailablePolicies(node.state)) {
        const next = applyPolicyToState(node.state, policy);
        frontier.push({
          state: next,
          path: [...node.path, policy.id],
          depth: node.depth + 1,
          g: node.g + transitionCost(node.state, policy, next, node.path),
        }, strategicDistance(next));
      }
    }

    return {
      best: bestNode.path,
      state: bestNode.state,
      nodes,
      score: -strategicDistance(bestNode.state),
      algorithmValue: -strategicDistance(bestNode.state),
      valueLabel: 'negative strategic distance',
      improvementReached: hasImprovedEnough(initialState, bestNode.state),
      effectiveDepth: depth,
      debug: { strategicDistance: Number(strategicDistance(bestNode.state).toFixed(2)) },
    };
  });

// 6. A*: priority is f(n)=g(n)+h(n), with transitionCost as g and normalized strategicDistance as h.
export const aStar: SearchFn = (initialState, requestedDepth = 3) =>
  measure('A*', () => {
    const depth = Math.max(1, Math.min(5, requestedDepth));
    const heuristic = (state: NationState) => strategicDistance(state) / 9;
    const frontier = new MinPriorityQueue<SearchNode>();
    const start: SearchNode = { state: cloneState(initialState), path: [], depth: 0, g: 0 };
    frontier.push(start, heuristic(initialState));
    const bestG = new Map<string, number>([[`0@${stateKey(initialState)}`, 0]]);
    let nodes = 0;
    let best: SearchNode = start;
    let bestF = Infinity;

    while (frontier.size > 0 && nodes < MAX_NODES) {
      const node = frontier.pop()!;
      nodes += 1;
      const f = node.g + heuristic(node.state);
      if (node.path.length > 0 && f < bestF - EPSILON) {
        best = node;
        bestF = f;
      }
      if (node.depth >= depth) continue;

      for (const policy of getAvailablePolicies(node.state)) {
        const next = applyPolicyToState(node.state, policy);
        const g = node.g + transitionCost(node.state, policy, next, node.path);
        const key = `${node.depth + 1}@${stateKey(next)}`;
        const known = bestG.get(key);
        if (known !== undefined && known <= g + EPSILON) continue;
        bestG.set(key, g);
        const child = { state: next, path: [...node.path, policy.id], depth: node.depth + 1, g };
        frontier.push(child, g + heuristic(next));
      }
    }

    return {
      best: best.path,
      state: best.state,
      nodes,
      score: -bestF,
      algorithmValue: -bestF,
      valueLabel: 'A* f = g + h',
      improvementReached: hasImprovedEnough(initialState, best.state),
      effectiveDepth: depth,
      debug: { fValue: Number(bestF.toFixed(2)), firstStepCost: firstPolicyCostDebug(initialState, best.path[0]) ?? null },
    };
  });

// 7. Hill Climbing: local search by evaluateState(), no frontier and no random restart.
export const hillClimbing: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Hill Climbing', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(12, options.localSearchSteps ?? requestedDepth));
    let current = cloneState(initialState);
    const path: string[] = [];
    let nodes = 1;

    for (let step = 0; step < depth && nodes < MAX_NODES; step += 1) {
      const candidates = getAvailablePolicies(current).map((policy) => ({ policy, state: applyPolicyToState(current, policy) }));
      nodes += candidates.length;
      if (candidates.length === 0) break;
      candidates.sort((a, b) => (evaluateState(b.state) - planChurnPenalty([...path, b.policy.id])) - (evaluateState(a.state) - planChurnPenalty([...path, a.policy.id])) || a.policy.id.localeCompare(b.policy.id));
      const next = candidates[0];
      if (evaluateState(next.state) <= evaluateState(current) + EPSILON) break;
      current = next.state;
      path.push(next.policy.id);
    }

    return {
      best: path,
      state: current,
      nodes,
      improvementReached: hasImprovedEnough(initialState, current),
      effectiveDepth: depth,
      debug: { localSearchSteps: depth },
    };
  });

// 8. Local Beam Search: keeps K states by evaluateState() at every level.
export const localBeamSearch: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Local Beam Search', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(8, requestedDepth));
    const beamWidth = Math.max(2, Math.min(10, options.beamWidth));
    let beam: SearchNode[] = [{ state: cloneState(initialState), path: [], depth: 0, g: 0 }];
    let bestNode = beam[0];
    let nodes = 1;

    for (let level = 0; level < depth && nodes < MAX_NODES; level += 1) {
      const successors: SearchNode[] = [];
      const seen = new Set<string>();
      for (const node of beam) {
        for (const policy of getAvailablePolicies(node.state)) {
          const next = applyPolicyToState(node.state, policy);
          const path = [...node.path, policy.id];
          const key = `${path[0] ?? policy.id}@${node.depth + 1}@${stateKey(next)}`;
          if (seen.has(key)) continue;
          seen.add(key);
          successors.push({
            state: next,
            path,
            depth: node.depth + 1,
            g: node.g + transitionCost(node.state, policy, next, node.path),
          });
          nodes += 1;
          if (nodes >= MAX_NODES) break;
        }
        if (nodes >= MAX_NODES) break;
      }
      if (successors.length === 0) break;
      successors.sort((a, b) => nodeSelectionScore(b) - nodeSelectionScore(a) || a.path.join('|').localeCompare(b.path.join('|')));
      beam = successors.slice(0, beamWidth);
      if (compareScore(beam[0], bestNode) > EPSILON) bestNode = beam[0];
    }

    return {
      best: bestNode.path,
      state: bestNode.state,
      nodes,
      improvementReached: hasImprovedEnough(initialState, bestNode.state),
      effectiveDepth: depth,
      debug: { beamWidth, keptStatesPerLevel: beamWidth },
    };
  });

const buildInitialPlan = (initialState: NationState, depth: number, rng: () => number): string[] => {
  const plan: string[] = [];
  let current = cloneState(initialState);
  for (let index = 0; index < depth; index += 1) {
    const available = getAvailablePolicies(current);
    if (available.length === 0) break;
    const ranked = available
      .map((policy) => ({ policy, state: applyPolicyToState(current, policy) }))
      .sort((a, b) =>
        (evaluateState(b.state) - planChurnPenalty([...plan, b.policy.id])) -
        (evaluateState(a.state) - planChurnPenalty([...plan, a.policy.id])),
      );
    const pool = ranked.slice(0, Math.max(1, Math.min(8, ranked.length)));
    const selected = pool[Math.floor(rng() * pool.length)].policy;
    plan.push(selected.id);
    current = applyPolicyToState(current, selected);
  }
  return plan;
};

// 9. Simulated Annealing: stochastic local search with temperature-based acceptance of worse moves.
export const simulatedAnnealing: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Simulated Annealing', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(5, requestedDepth));
    const rng = createRng(hashString(`SA-${stateKey(initialState)}-${depth}`));
    let currentPlan = buildInitialPlan(initialState, depth, rng);
    let currentState = planState(initialState, currentPlan) ?? cloneState(initialState);
    let currentScore = evaluateState(currentState) - planChurnPenalty(currentPlan);
    let bestPlan = [...currentPlan];
    let bestState = currentState;
    let bestScore = currentScore;
    let temperature = 24;
    const iterations = Math.max(50, Math.min(2000, options.annealingIterations));
    let nodes = 1;

    for (let iteration = 0; iteration < iterations && nodes < MAX_NODES; iteration += 1) {
      const candidatePlan = [...currentPlan];
      const index = candidatePlan.length === 0 ? 0 : Math.floor(rng() * candidatePlan.length);
      const prefix = candidatePlan.slice(0, index);
      const prefixState = planState(initialState, prefix) ?? cloneState(initialState);
      const choices = getAvailablePolicies(prefixState);
      if (choices.length === 0) break;
      const replacement = choices[Math.floor(rng() * choices.length)].id;
      if (candidatePlan.length === 0) candidatePlan.push(replacement);
      else candidatePlan[index] = replacement;

      const candidateState = planState(initialState, candidatePlan);
      nodes += 1;
      if (!candidateState) continue;
      const candidateScore = evaluateState(candidateState) - planChurnPenalty(candidatePlan);
      const delta = candidateScore - currentScore;
      const accept = delta >= 0 || rng() < Math.exp(delta / Math.max(0.001, temperature));
      if (accept) {
        currentPlan = candidatePlan;
        currentState = candidateState;
        currentScore = candidateScore;
      }
      if (candidateScore > bestScore + EPSILON) {
        bestScore = candidateScore;
        bestPlan = candidatePlan;
        bestState = candidateState;
      }
      temperature = Math.max(0.05, temperature * 0.965);
    }

    return {
      best: bestPlan,
      state: bestState,
      nodes,
      score: bestScore,
      algorithmValue: bestScore,
      valueLabel: 'best annealed score',
      improvementReached: hasImprovedEnough(initialState, bestState),
      effectiveDepth: depth,
      debug: { annealingIterations: iterations, finalTemperature: Number(temperature.toFixed(2)) },
    };
  });

const riskLevelFor = (state: NationState, policy?: Policy): number => {
  const debtRatio = state.debt / Math.max(1, state.gdp);
  const fiscal = Math.max(0, debtRatio - 0.45) * 1.2 + Math.max(0, 120 - state.budget) / 240;
  const macro = Math.max(0, state.inflation - 6) / 12 + Math.max(0, state.unemployment - 9) / 18;
  const social = Math.max(0, 50 - state.happiness) / 100 + Math.max(0, 55 - state.diplomacy) / 160;
  const resilience = Math.max(0, 55 - state.cybersecurity) / 140 + Math.max(0, 55 - state.environment) / 140;
  const policyRisk = policy ? Math.max(0, policy.cost - 100) / 260 + Math.max(0, Number(policy.effect.debt ?? 0)) / 160 : 0;
  return bounded(fiscal + macro + social + resilience + policyRisk, 0, 1);
};

const scaledPolicyState = (state: NationState, policy: Policy, scale: number): NationState => {
  if (policy.cost > state.budget) return cloneState(state);
  const next = cloneState(state);
  next.budget -= policy.cost;
  for (const [key, value] of Object.entries(policy.effect)) {
    if (typeof value !== 'number') continue;
    const numericKey = key as Exclude<keyof NationState, 'active_events'>;
    if (typeof next[numericKey] === 'number') (next[numericKey] as number) += value * scale;
  }
  return advanceMonth(clampState(next));
};

const applyEventEffect = (state: NationState, eventIndex: number, scale = 1): NationState => {
  const event = EVENTS[eventIndex % EVENTS.length];
  const next = cloneState(state);
  for (const [key, value] of Object.entries(event.effect)) {
    if (typeof value !== 'number') continue;
    const numericKey = key as Exclude<keyof NationState, 'active_events'>;
    if (typeof next[numericKey] === 'number') (next[numericKey] as number) += value * scale;
  }
  next.active_events = [...new Set([...next.active_events.slice(-4), event.id])].slice(-5);
  return clampState(next);
};

const normalizeOutcomes = (outcomes: WeightedState[]): WeightedState[] => {
  const total = outcomes.reduce((sum, outcome) => sum + Math.max(0, outcome.probability), 0) || 1;
  return outcomes.map((outcome) => ({ ...outcome, probability: Math.max(0, outcome.probability) / total }));
};

const policyOutcomes = (state: NationState, policy: Policy): WeightedState[] => {
  const risk = riskLevelFor(state, policy);
  const successProb = bounded(0.36 - risk * 0.12, 0.18, 0.5);
  const partialProb = bounded(0.42 - risk * 0.04, 0.25, 0.5);
  const setbackProb = bounded(0.17 + risk * 0.11, 0.1, 0.32);
  const criticalProb = bounded(0.05 + risk * 0.05, 0.03, 0.18);
  const eventIndex = Math.abs(hashString(`${policy.id}-${stateKey(state)}-outcome`)) % 9;

  return normalizeOutcomes([
    { state: scaledPolicyState(state, policy, 1.05), probability: successProb, label: 'success' },
    { state: scaledPolicyState(state, policy, 0.65), probability: partialProb, label: 'partial' },
    { state: applyEventEffect(scaledPolicyState(state, policy, 0.3), eventIndex, 0.18 + risk * 0.15), probability: setbackProb, label: 'setback' },
    { state: applyEventEffect(scaledPolicyState(state, policy, 0.1), eventIndex, 0.35 + risk * 0.25), probability: criticalProb, label: 'critical_setback' },
  ]);
};

// 10. AND-OR Search: OR chooses policy, AND requires every plausible outcome to stay solvable.
export const andOrSearch: SearchFn = (initialState, requestedDepth = 3) =>
  measure('AND-OR Search', () => {
    const depth = Math.max(1, Math.min(3, requestedDepth));
    let nodes = 0;
    const memo = new Map<string, ValueResult>();

    const orSearch = (state: NationState, remaining: number): ValueResult => {
      nodes += 1;
      if (remaining === 0 || nodes >= MAX_NODES || isTerminalBadState(state)) return { value: evaluateState(state), state, path: [] };
      const memoKey = `${stateKey(state)}#${remaining}`;
      const cached = memo.get(memoKey);
      if (cached) return cached;

      const policies = getAvailablePolicies(state);
      if (policies.length === 0) return { value: evaluateState(state), state, path: [] };

      let bestSafe: ValueResult | null = null;
      let bestFallback: ValueResult | null = null;

      for (const policy of policies) {
        const outcomes = policyOutcomes(state, policy);
        const outcomeResults = outcomes.map((outcome) => ({
          outcome,
          result: isTerminalBadState(outcome.state)
            ? { value: -100_000, state: outcome.state, path: [], label: outcome.label }
            : orSearch(outcome.state, remaining - 1),
        }));
        const worst = outcomeResults.reduce((left, right) => (left.result.value <= right.result.value ? left : right));
        const nominal = outcomeResults.find((item) => item.outcome.label === 'success') ?? outcomeResults[0] ?? worst;
        const conditionalPlan = {
          type: 'AND_OR_CONDITIONAL_PLAN',
          policyId: policy.id,
          robustValue: Number(worst.result.value.toFixed(2)),
          outcomeBranches: outcomeResults.map((item) => ({
            label: item.outcome.label,
            probability: Number(item.outcome.probability.toFixed(3)),
            value: Number(item.result.value.toFixed(2)),
            continuation: item.result.path,
            subplan: item.result.conditionalPlan ?? null,
          })),
        };
        const result: ValueResult = {
          value: worst.result.value,
          state: worst.result.state,
          path: [policy.id, ...(nominal.result.path ?? [])],
          conditionalPlan,
        };
        const allOutcomesSolvable = outcomeResults.every((item) => item.result.value > -100_000);
        if (allOutcomesSolvable) {
          if (!bestSafe || result.value > bestSafe.value + EPSILON) bestSafe = result;
        }
        if (!bestFallback || result.value > bestFallback.value + EPSILON) bestFallback = result;
        if (nodes >= MAX_NODES) break;
      }

      const result = bestSafe ?? bestFallback ?? { value: evaluateState(state), state, path: [] };
      memo.set(memoKey, result);
      return result;
    };

    const result = orSearch(cloneState(initialState), depth);
    return {
      best: result.path.slice(0, depth),
      state: result.state,
      nodes,
      score: result.value,
      algorithmValue: result.value,
      valueLabel: 'robust worst-outcome value',
      improvementReached: result.value > evaluateState(initialState),
      effectiveDepth: depth,
      conditionalPlan: result.conditionalPlan ?? null,
      debug: { robustValue: Number(result.value.toFixed(2)), conditionalBranches: result.conditionalPlan ? 'available' : 'none' },
    };
  });

const boundedStateDelta = (state: NationState, changes: Partial<NationState>): NationState => clampState({
  ...cloneState(state),
  ...changes,
  active_events: [...state.active_events],
  recentPolicies: [...(state.recentPolicies ?? [])].slice(-6),
});

const makeInitialBelief = (state: NationState): NationState[] => {
  const debtRatio = state.debt / Math.max(1, state.gdp);
  const fiscalRisk = bounded(Math.max(0, debtRatio - 0.45) * 1.4 + Math.max(0, 120 - state.budget) / 250, 0, 1);
  const macroRisk = bounded(Math.max(0, state.inflation - 6) / 12 + Math.max(0, state.unemployment - 9) / 16, 0, 1);
  const socialRisk = bounded(Math.max(0, 55 - state.happiness) / 90 + Math.max(0, 55 - state.diplomacy) / 150, 0, 1);
  const cyberRisk = bounded(Math.max(0, 55 - state.cybersecurity) / 80, 0, 1);
  const environmentRisk = bounded(Math.max(0, 55 - state.environment) / 80, 0, 1);
  const hiddenRisk = bounded(Math.max(fiscalRisk, macroRisk, socialRisk, cyberRisk, environmentRisk), 0, 1);

  const exact = cloneState(state);
  const optimistic = boundedStateDelta(state, {
    happiness: Math.min(100, state.happiness + 3),
    education: Math.min(100, state.education + 2),
    healthcare: Math.min(100, state.healthcare + 2),
    budget: state.budget * 1.04,
    gdp: state.gdp * 1.015,
    inflation: Math.max(0, state.inflation - 0.8),
    unemployment: Math.max(0, state.unemployment - 0.8),
  } as Partial<NationState>);
  const pessimistic = boundedStateDelta(state, {
    happiness: Math.max(0, state.happiness - 4),
    education: Math.max(0, state.education - 2),
    healthcare: Math.max(0, state.healthcare - 3),
    budget: state.budget * 0.95,
    gdp: state.gdp * 0.985,
    inflation: state.inflation + 1.2,
    unemployment: state.unemployment + 1.2,
  });
  const hidden = boundedStateDelta(state, {
    budget: state.budget * (1 - 0.08 * fiscalRisk),
    debt: state.debt * (1 + 0.05 * fiscalRisk),
    happiness: Math.max(0, state.happiness - 4 * socialRisk - 2 * hiddenRisk),
    healthcare: Math.max(0, state.healthcare - 2 * environmentRisk),
    environment: Math.max(0, state.environment - 4 * environmentRisk),
    cybersecurity: Math.max(0, state.cybersecurity - 4 * cyberRisk),
    diplomacy: Math.max(0, state.diplomacy - 3 * socialRisk),
    inflation: state.inflation + 2 * macroRisk,
    unemployment: state.unemployment + 1.8 * macroRisk,
  });

  return [exact, optimistic, pessimistic, hidden];
};

const robustBeliefScore = (belief: NationState[]): number => {
  const scores = belief.map(evaluateState);
  const mean = scores.reduce((sum, score) => sum + score, 0) / Math.max(1, scores.length);
  const worst = Math.min(...scores);
  return mean * 0.65 + worst * 0.35;
};

const beliefDebugScores = (belief: NationState[]): Record<string, number> => {
  const labels = ['exact', 'optimistic', 'pessimistic', 'hiddenRisk'];
  return Object.fromEntries(belief.map((state, index) => [labels[index] ?? `belief${index + 1}`, Number(evaluateState(state).toFixed(2))]));
};

// 11. Belief-State Search: evaluates policies across exact/optimistic/pessimistic/hidden-risk states.
export const beliefStateSearch: SearchFn = (initialState, requestedDepth = 3) =>
  measure('Belief-State Search', () => {
    const depth = Math.max(1, Math.min(4, requestedDepth));
    const beamWidth = 4;
    type BeliefNode = { belief: NationState[]; path: string[] };
    let frontier: BeliefNode[] = [{ belief: makeInitialBelief(initialState), path: [] }];
    let best = frontier[0];
    let nodes = 1;

    for (let level = 0; level < depth && nodes < MAX_NODES; level += 1) {
      const successors: BeliefNode[] = [];
      for (const node of frontier) {
        const representative = averageStates(node.belief.map((state) => ({ state, probability: 1 / node.belief.length, label: 'belief' })));
        const minBudget = Math.min(...node.belief.map((beliefState) => beliefState.budget));
        const policies = getAvailablePolicies(representative).filter((policy) => policy.cost <= minBudget);

        for (const policy of policies) {
          const nextBelief = node.belief.map((beliefState) => applyPolicyToState(beliefState, policy));
          successors.push({ belief: nextBelief, path: [...node.path, policy.id] });
          nodes += nextBelief.length;
          if (nodes >= MAX_NODES) break;
        }
        if (nodes >= MAX_NODES) break;
      }
      if (successors.length === 0) break;
      successors.sort((a, b) => robustBeliefScore(b.belief) - robustBeliefScore(a.belief) || a.path.join('|').localeCompare(b.path.join('|')));
      frontier = successors.slice(0, beamWidth);
      if (robustBeliefScore(frontier[0].belief) > robustBeliefScore(best.belief) + EPSILON) best = frontier[0];
    }

    const projected = averageStates(best.belief.map((state) => ({ state, probability: 1 / best.belief.length, label: 'belief' })));
    const score = robustBeliefScore(best.belief);
    return {
      best: best.path,
      state: projected,
      nodes,
      score,
      algorithmValue: score,
      valueLabel: 'belief robust value',
      improvementReached: score > evaluateState(initialState),
      effectiveDepth: depth,
      debug: { beliefValue: Number(score.toFixed(2)), beliefScores: beliefDebugScores(best.belief) },
    };
  });

export type LrtaHeuristicMemory = Map<string, number>;

export type LrtaDecision = {
  policy: Policy;
  projectedState: NationState;
  nodes: number;
  learnedCost: number;
};

const persistentLrtaMemory: LrtaHeuristicMemory = new Map<string, number>();
let persistentLrtaLoaded = false;

const canUseLocalStorage = (): boolean => typeof globalThis !== 'undefined' && 'localStorage' in globalThis;

const loadPersistentLrtaMemory = (): void => {
  if (persistentLrtaLoaded) return;
  persistentLrtaLoaded = true;
  if (!canUseLocalStorage()) return;
  try {
    const raw = globalThis.localStorage?.getItem('nexus-lrta-memory');
    if (!raw) return;
    const entries = JSON.parse(raw) as Array<[string, number]>;
    if (!Array.isArray(entries)) return;
    for (const [key, value] of entries) {
      if (typeof key === 'string' && Number.isFinite(value)) persistentLrtaMemory.set(key, value);
    }
  } catch {
    // Ignore corrupt local learning caches; LRTA* can rebuild them from new transitions.
  }
};

const savePersistentLrtaMemory = (): void => {
  if (!canUseLocalStorage()) return;
  try {
    const entries = [...persistentLrtaMemory.entries()].slice(-600);
    globalThis.localStorage?.setItem('nexus-lrta-memory', JSON.stringify(entries));
  } catch {
    // Storage may be unavailable or full; keep the in-memory table for this session.
  }
};

export const createLrtaHeuristicMemory = (includePersistent = true): LrtaHeuristicMemory => {
  if (includePersistent) loadPersistentLrtaMemory();
  return includePersistent ? new Map(persistentLrtaMemory) : new Map<string, number>();
};

const lrtaStateKey = (state: NationState): string => {
  const activeEvents = state.active_events.length > 0 ? [...state.active_events].sort().join(',') : 'no-event';
  return `${stateKey(state)}::${activeEvents}`;
};

const lrtaDefaultHeuristic = (state: NationState): number => strategicDistance(state) / 10 + state.active_events.length * 4;

const getLrtaHeuristic = (state: NationState, table: LrtaHeuristicMemory, usePersistent = true): number => {
  const key = lrtaStateKey(state);
  const local = table.get(key);
  if (local !== undefined) return local;
  const persistent = usePersistent ? persistentLrtaMemory.get(key) : undefined;
  if (persistent !== undefined) {
    table.set(key, persistent);
    return persistent;
  }
  const initial = lrtaDefaultHeuristic(state);
  table.set(key, initial);
  return initial;
};

const setLrtaHeuristic = (state: NationState, value: number, table: LrtaHeuristicMemory, learningRate = 0.25, persist = true) => {
  const key = lrtaStateKey(state);
  const oldValue = getLrtaHeuristic(state, table, persist);
  const nextValue = oldValue * (1 - learningRate) + value * learningRate;
  table.set(key, nextValue);
  if (persist) {
    loadPersistentLrtaMemory();
    persistentLrtaMemory.set(key, nextValue);
    savePersistentLrtaMemory();
  }
};

export const learnLrtaTransition = (
  before: NationState,
  policyId: string,
  after: NationState,
  heuristicTable: LrtaHeuristicMemory = persistentLrtaMemory,
  persist = true,
): void => {
  const policy = getPolicy(policyId);
  if (!policy) return;
  const learnedValue = transitionCost(before, policy, after) + getLrtaHeuristic(after, heuristicTable, persist);
  setLrtaHeuristic(before, learnedValue, heuristicTable, 0.2, persist);
};

export const resetLrtaMemory = (): void => {
  persistentLrtaMemory.clear();
  if (canUseLocalStorage()) {
    try { globalThis.localStorage?.removeItem('nexus-lrta-memory'); } catch { /* no-op */ }
  }
};

export const selectLrtaStarPolicy = (
  currentState: NationState,
  _previousPath: string[] = [],
  heuristicTable: LrtaHeuristicMemory = createLrtaHeuristicMemory(),
  persist = true,
): LrtaDecision | null => {
  const current = cloneState(currentState);
  const policies = getAvailablePolicies(current);
  if (policies.length === 0) return null;

  const evaluated = policies.map((policy) => {
    const projectedState = applyPolicyToState(current, policy);
    const learnedCost = transitionCost(current, policy, projectedState, _previousPath) + getLrtaHeuristic(projectedState, heuristicTable, persist);
    return { policy, projectedState, learnedCost };
  });

  evaluated.sort((a, b) => a.learnedCost - b.learnedCost || a.policy.id.localeCompare(b.policy.id));
  const best = evaluated[0];
  setLrtaHeuristic(current, best.learnedCost, heuristicTable, 0.25, persist);
  if (persist) {
    loadPersistentLrtaMemory();
    persistentLrtaMemory.set(lrtaStateKey(best.projectedState), getLrtaHeuristic(best.projectedState, heuristicTable, true));
    savePersistentLrtaMemory();
  }

  return {
    policy: best.policy,
    projectedState: best.projectedState,
    nodes: evaluated.length,
    learnedCost: best.learnedCost,
  };
};

// 12. LRTA*: online c + learnedH(next), with persistent state-bucket heuristic memory.
export const lrtaStar: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('LRTA*', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(8, options.lrtaLearningMonths ?? requestedDepth));
    const persist = Boolean(settings) && options.lrtaMemoryMode === 'persistent';
    const heuristicTable = createLrtaHeuristicMemory(persist);
    const trace: string[] = [];
    const costs: number[] = [];
    let current = cloneState(initialState);
    let nodes = 1;

    for (let step = 0; step < depth && nodes < MAX_NODES; step += 1) {
      const before = cloneState(current);
      const decision = selectLrtaStarPolicy(before, trace, heuristicTable, persist);
      if (!decision) break;
      trace.push(decision.policy.id);
      costs.push(Number(decision.learnedCost.toFixed(2)));
      nodes += decision.nodes;
      current = decision.projectedState;
      learnLrtaTransition(before, decision.policy.id, current, heuristicTable, persist);
      if (isTerminalBadState(current)) break;
    }

    if (trace.length === 0) {
      return {
        best: [],
        state: cloneState(initialState),
        nodes,
        improvementReached: false,
        effectiveDepth: depth,
        executionMode: 'online',
        displayPolicies: Array.from({ length: depth }, () => null),
        debug: { lrtaMemoryMode: options.lrtaMemoryMode, learnedTransitions: 0 },
      };
    }

    return {
      best: trace,
      state: current,
      nodes,
      score: -costs[0],
      algorithmValue: -costs[0],
      valueLabel: 'LRTA* c + H estimate',
      improvementReached: hasImprovedEnough(initialState, current),
      effectiveDepth: depth,
      executionMode: 'online',
      displayPolicies: trace,
      debug: {
        lrtaMemoryMode: options.lrtaMemoryMode,
        learningTrace: trace,
        learnedCosts: costs,
        learnedTransitions: trace.length,
        firstStepCost: firstPolicyCostDebug(initialState, trace[0]) ?? null,
      },
    };
  });

const INCOMPATIBLE_PAIRS: Array<[string, string]> = POLICY_REVERSAL_PAIRS;

const arePoliciesCompatible = (left: string, right: string): boolean => {
  if (left === right) return true;
  return !INCOMPATIBLE_PAIRS.some(([a, b]) => (left === a && right === b) || (left === b && right === a));
};

const strictnessProfile = (settings?: AIAdvancedSettings) => {
  const strictness = withSettings(settings).constraintStrictness;
  if (strictness === 'relaxed') {
    return { hardDebtRatio: 1.35, hardInflation: 42, hardUnemployment: 42, hardHappiness: 5, softMultiplier: 0.7, criticalNeedPenalty: 20 };
  }
  if (strictness === 'strict') {
    return { hardDebtRatio: 1.05, hardInflation: 28, hardUnemployment: 28, hardHappiness: 12, softMultiplier: 1.35, criticalNeedPenalty: 45 };
  }
  return { hardDebtRatio: 1.2, hardInflation: 35, hardUnemployment: 35, hardHappiness: 8, softMultiplier: 1, criticalNeedPenalty: 30 };
};

const criticalNeedGroups = (state: NationState): string[][] => {
  const groups: string[][] = [];
  if (state.healthcare < 45) groups.push(['health_invest', 'emergency_healthcare', 'welfare']);
  if (state.unemployment > 10) groups.push(['job_program', 'business_grant', 'economic_stimulus', 'vocational_training']);
  if (state.inflation > 7) groups.push(['inflation_control', 'austerity', 'tax_up', 'supply_chain_stabilization']);
  if (state.debt / Math.max(1, state.gdp) > 0.65) groups.push(['pay_debt', 'tax_up', 'austerity']);
  if (state.cybersecurity < 45) groups.push(['cybersec', 'cyber_incident_response']);
  if (state.environment < 45) groups.push(['green_energy', 'emissions', 'forest', 'climate_adaptation']);
  if (state.happiness < 45) groups.push(['stability_op', 'welfare', 'social_dialogue', 'job_program']);
  return groups;
};

const policyConflict = (before: NationState, policy: Policy, after: NationState, settings?: AIAdvancedSettings): Pick<ConflictReport, 'hard' | 'soft'> => {
  const profile = strictnessProfile(settings);
  let hard = 0;
  let soft = 0;
  if (policy.cost > before.budget) hard += 1;
  if (isTerminalBadState(after)) hard += 1;
  const debtRatio = after.debt / Math.max(1, after.gdp);
  if (debtRatio > profile.hardDebtRatio || after.inflation > profile.hardInflation || after.unemployment > profile.hardUnemployment || after.happiness < profile.hardHappiness) hard += 1;

  if (before.happiness < 50 && Number(policy.effect.happiness ?? 0) < 0) soft += 35;
  if (before.happiness < 50 && Number(policy.effect.taxRate ?? 0) > 0) soft += 25;
  if (before.inflation > 7 && Number(policy.effect.inflation ?? 0) > 0) soft += 35;
  if (before.unemployment > 10 && Number(policy.effect.unemployment ?? 0) > 0) soft += 30;
  if (before.debt / Math.max(1, before.gdp) > 0.65 && Number(policy.effect.debt ?? 0) > 0) soft += 40;
  if (before.budget < 120 && policy.cost > 100) soft += 35;
  if (before.environment < 45 && Number(policy.effect.environment ?? 0) < 0) soft += 25;
  if (before.cybersecurity < 45 && Number(policy.effect.technology ?? 0) > 0 && Number(policy.effect.cybersecurity ?? 0) <= 0) soft += 15;
  if (evaluateState(after) < evaluateState(before) - 250) soft += 20;

  return { hard, soft: Number((soft * profile.softMultiplier).toFixed(2)) };
};

const evaluatePlanConflicts = (initialState: NationState, plan: string[], settings?: AIAdvancedSettings): ConflictReport => {
  const profile = strictnessProfile(settings);
  let current = cloneState(initialState);
  let hard = 0;
  let soft = 0;

  for (let index = 0; index < plan.length; index += 1) {
    const policy = getPolicy(plan[index]);
    if (!policy || policy.cost > current.budget) {
      hard += 1;
      soft += 100;
      break;
    }
    if (index > 0 && plan[index - 1] === plan[index]) soft += 18;
    for (let previous = 0; previous < index; previous += 1) {
      if (!arePoliciesCompatible(plan[previous], plan[index])) soft += 28;
      if (plan[previous] === plan[index] && index - previous <= 2) soft += 10;
    }
    const next = applyPolicyToState(current, policy);
    const conflict = policyConflict(current, policy, next, settings);
    hard += conflict.hard;
    soft += conflict.soft;
    current = next;
  }

  for (const group of criticalNeedGroups(initialState)) {
    if (!group.some((id) => plan.includes(id))) soft += profile.criticalNeedPenalty;
  }

  const categoryCounts = plan.reduce<Record<string, number>>((counts, policyId) => {
    const category = getPolicy(policyId)?.category ?? 'unknown';
    counts[category] = (counts[category] ?? 0) + 1;
    return counts;
  }, {});
  const mostUsedCategory = Math.max(0, ...Object.values(categoryCounts));
  if (plan.length >= 3 && mostUsedCategory >= plan.length - 1) soft += 12 * (mostUsedCategory - 1);

  return { hard, soft, score: evaluateState(current), state: current };
};

const conflictValue = (report: ConflictReport): number => report.hard * CSP_HARD_WEIGHT + report.soft;

const isBetterConflictPlan = (candidate: ConflictReport, best: ConflictReport): boolean => {
  if (candidate.hard !== best.hard) return candidate.hard < best.hard;
  if (candidate.soft !== best.soft) return candidate.soft < best.soft;
  return candidate.score > best.score + EPSILON;
};

const buildCspDomainIds = (state: NationState): string[] => {
  const needs = criticalNeedGroups(state).flat();
  const affordable = getAvailablePolicies(state).map((policy) => policy.id);
  return [...new Set([...needs, ...affordable])].filter((id) => getPolicy(id));
};

// 13. Constraint Propagation: filters policy domains by hard/soft constraints before score tie-breaks.
export const constraintPropagation: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Constraint Propagation', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(5, requestedDepth));
    let current = cloneState(initialState);
    const assignment: string[] = [];
    let nodes = 0;

    for (let variable = 0; variable < depth && nodes < MAX_NODES; variable += 1) {
      const candidates = buildCspDomainIds(current)
        .map((id) => getPolicy(id))
        .filter((policy): policy is Policy => Boolean(policy) && policy!.cost <= current.budget)
        .map((policy) => {
          const next = applyPolicyToState(current, policy);
          const immediate = policyConflict(current, policy, next, options);
          const planReport = evaluatePlanConflicts(initialState, [...assignment, policy.id], options);
          return { policy, next, hard: immediate.hard + planReport.hard, soft: immediate.soft + planReport.soft, score: evaluateState(next) };
        });
      nodes += candidates.length;
      if (candidates.length === 0) break;

      const hardMinimum = Math.min(...candidates.map((item) => item.hard));
      const filtered = candidates.filter((item) => item.hard === hardMinimum);
      filtered.sort((a, b) => a.soft - b.soft || b.score - a.score || a.policy.id.localeCompare(b.policy.id));
      const chosen = filtered[0];
      assignment.push(chosen.policy.id);
      current = chosen.next;
    }

    const report = evaluatePlanConflicts(initialState, assignment, options);
    return {
      best: assignment,
      state: report.state ?? current,
      nodes,
      score: report.score - conflictValue(report),
      algorithmValue: report.score - conflictValue(report),
      valueLabel: 'constraint-adjusted score',
      improvementReached: report.hard === 0 && evaluateState(report.state ?? current) > evaluateState(initialState),
      effectiveDepth: depth,
      debug: { hardViolations: report.hard, softConflicts: report.soft, conflictScore: conflictValue(report), strictness: options.constraintStrictness },
    };
  });

// 14. Backtracking CSP: assigns policies month by month and backtracks on hard violations.
export const backtrackingCsp: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Backtracking CSP', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(5, requestedDepth));
    let nodes = 0;
    let bestPlan: string[] = [];
    let bestReport: ConflictReport = { hard: Infinity, soft: Infinity, score: -Infinity, state: cloneState(initialState) };

    const search = (current: NationState, assignment: string[]) => {
      if (nodes >= MAX_NODES) return;
      const report = evaluatePlanConflicts(initialState, assignment, options);
      if (assignment.length > 0 && isBetterConflictPlan(report, bestReport)) {
        bestPlan = [...assignment];
        bestReport = report;
      }
      if (assignment.length >= depth) return;

      const candidates = buildCspDomainIds(current)
        .map((id) => getPolicy(id))
        .filter((policy): policy is Policy => Boolean(policy) && policy!.cost <= current.budget)
        .map((policy) => {
          const next = applyPolicyToState(current, policy);
          const immediate = policyConflict(current, policy, next, options);
          const nextAvailable = getAvailablePolicies(next).length;
          return { policy, next, immediate, nextAvailable, score: evaluateState(next) };
        })
        .sort((a, b) => a.immediate.hard - b.immediate.hard || a.immediate.soft - b.immediate.soft || b.nextAvailable - a.nextAvailable || b.score - a.score);

      for (const candidate of candidates) {
        nodes += 1;
        if (candidate.immediate.hard > 0 && bestReport.hard === 0) continue;
        if (candidate.nextAvailable === 0 && assignment.length + 1 < depth) continue;
        search(candidate.next, [...assignment, candidate.policy.id]);
        if (nodes >= MAX_NODES) return;
      }
    };

    search(cloneState(initialState), []);
    if (bestPlan.length === 0) {
      const fallback = getAvailablePolicies(initialState)[0];
      if (fallback) {
        bestPlan = [fallback.id];
        bestReport = evaluatePlanConflicts(initialState, bestPlan, options);
      }
    }

    const state = bestReport.state ?? cloneState(initialState);
    return {
      best: bestPlan,
      state,
      nodes,
      score: bestReport.score - conflictValue(bestReport),
      algorithmValue: bestReport.score - conflictValue(bestReport),
      valueLabel: 'least-conflict score',
      improvementReached: bestReport.hard === 0 && bestReport.score > evaluateState(initialState),
      effectiveDepth: depth,
      debug: { hardViolations: bestReport.hard, softConflicts: bestReport.soft, conflictScore: conflictValue(bestReport), strictness: options.constraintStrictness },
    };
  });

const initialMinConflictPlan = (initialState: NationState, depth: number, rng: () => number, settings?: AIAdvancedSettings): string[] => {
  const plan: string[] = [];
  let current = cloneState(initialState);
  for (let index = 0; index < depth; index += 1) {
    const candidates = getAvailablePolicies(current)
      .map((policy) => {
        const next = applyPolicyToState(current, policy);
        const conflict = policyConflict(current, policy, next, settings);
        return { policy, next, conflict, score: evaluateState(next) };
      })
      .sort((a, b) => a.conflict.hard - b.conflict.hard || a.conflict.soft - b.conflict.soft || b.score - a.score);
    if (candidates.length === 0) break;
    const pool = candidates.slice(0, Math.max(1, Math.min(8, candidates.length)));
    const selected = pool[Math.floor(rng() * pool.length)];
    plan.push(selected.policy.id);
    current = selected.next;
  }
  return plan;
};

const conflictContributionAt = (initialState: NationState, plan: string[], index: number, settings?: AIAdvancedSettings): number => {
  const original = evaluatePlanConflicts(initialState, plan, settings);
  const removed = [...plan];
  removed.splice(index, 1);
  const without = evaluatePlanConflicts(initialState, removed, settings);
  return Math.max(0, conflictValue(original) - conflictValue(without));
};

// 15. Min-Conflicts CSP: starts complete, then repairs the policy/month with the largest conflict.
export const minConflictsCsp: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Min-Conflicts CSP', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(5, requestedDepth));
    const rng = createRng(hashString(`MC-${stateKey(initialState)}-${depth}`));
    const maxRestarts = 3;
    const maxSteps = depth * 140;
    let nodes = 0;
    let bestPlan: string[] = [];
    let bestReport: ConflictReport = { hard: Infinity, soft: Infinity, score: -Infinity, state: cloneState(initialState) };

    for (let restart = 0; restart < maxRestarts && nodes < MAX_NODES; restart += 1) {
      let assignment = initialMinConflictPlan(initialState, depth, rng, options);
      if (assignment.length === 0) continue;

      for (let step = 0; step < maxSteps && nodes < MAX_NODES; step += 1) {
        const report = evaluatePlanConflicts(initialState, assignment, options);
        if (isBetterConflictPlan(report, bestReport)) {
          bestPlan = [...assignment];
          bestReport = report;
        }
        if (report.hard === 0 && report.soft === 0) break;

        const contributions = assignment.map((_, index) => ({ index, conflict: conflictContributionAt(initialState, assignment, index, options) }));
        contributions.sort((a, b) => b.conflict - a.conflict || a.index - b.index);
        const variable = contributions[0]?.index ?? Math.floor(rng() * assignment.length);
        const prefixState = planState(initialState, assignment.slice(0, variable)) ?? cloneState(initialState);
        const candidates = getAvailablePolicies(prefixState).map((policy) => {
          const candidate = [...assignment];
          candidate[variable] = policy.id;
          const candidateReport = evaluatePlanConflicts(initialState, candidate, options);
          nodes += 1;
          return { value: policy.id, report: candidateReport };
        }).sort((a, b) => conflictValue(a.report) - conflictValue(b.report) || b.report.score - a.report.score || a.value.localeCompare(b.value));
        if (candidates.length === 0) break;
        const noise = rng() < 0.05;
        const pool = noise ? candidates.slice(0, Math.max(1, Math.min(5, candidates.length))) : candidates.slice(0, 1);
        assignment[variable] = pool[Math.floor(rng() * pool.length)].value;
      }
    }

    if (bestPlan.length === 0) {
      const fallback = getAvailablePolicies(initialState)[0];
      if (fallback) {
        bestPlan = [fallback.id];
        bestReport = evaluatePlanConflicts(initialState, bestPlan, options);
      }
    }

    const state = bestReport.state ?? cloneState(initialState);
    return {
      best: bestPlan,
      state,
      nodes,
      score: bestReport.score - conflictValue(bestReport),
      algorithmValue: bestReport.score - conflictValue(bestReport),
      valueLabel: 'least-conflict score',
      improvementReached: bestReport.hard === 0 && bestReport.score > evaluateState(initialState),
      effectiveDepth: depth,
      debug: { hardViolations: bestReport.hard, softConflicts: bestReport.soft, conflictScore: conflictValue(bestReport), strictness: options.constraintStrictness },
    };
  });

const adverseOutcomes = (state: NationState, limit = 4): WeightedState[] => {
  const negativeEvents = EVENTS.filter((event) => !['boom', 'tech_breakthrough', 'trade_pact'].includes(event.id));
  return negativeEvents
    .map((event) => {
      const index = EVENTS.findIndex((item) => item.id === event.id);
      const shocked = applyEventEffect(state, index, 0.85 + riskLevelFor(state) * 0.35);
      const damage = evaluateState(state) - evaluateState(shocked);
      return { state: shocked, probability: getAdjustedEventProbability(state, event), label: event.id, damage };
    })
    .sort((a, b) => (b.damage * 0.75 + b.probability * 250) - (a.damage * 0.75 + a.probability * 250))
    .slice(0, limit)
    .map(({ state: outcomeState, probability, label }) => ({ state: outcomeState, probability, label }));
};

const orderedMaxPolicies = (state: NationState, ordering: boolean): Policy[] => {
  const policies = getAvailablePolicies(state);
  if (!ordering) return policies;
  return policies
    .map((policy) => ({ policy, state: applyPolicyToState(state, policy) }))
    .sort((a, b) => evaluateState(b.state) - evaluateState(a.state) || a.policy.id.localeCompare(b.policy.id))
    .map((item) => item.policy);
};

// 16. Minimax: MAX chooses policies; MIN chooses the worst realistic state-risk shock.
export const minimax: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Minimax', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(settings ? 3 : 2, requestedDepth));
    const minActionLimit = Math.max(2, Math.min(6, options.maxMinActions));
    let nodes = 0;
    const memo = new Map<string, ValueResult>();

    const maxValue = (state: NationState, remaining: number): ValueResult => {
      nodes += 1;
      if (remaining === 0 || nodes >= MAX_NODES || isTerminalBadState(state)) return { value: evaluateState(state), state, path: [] };
      const memoKey = `MAX#${remaining}#${stateKey(state)}`;
      const cached = memo.get(memoKey);
      if (cached) return cached;
      const policies = orderedMaxPolicies(state, false);
      if (policies.length === 0) return { value: evaluateState(state), state, path: [] };
      let best: ValueResult = { value: -Infinity, state, path: [] };
      for (const policy of policies) {
        const afterPolicy = applyPolicyToState(state, policy);
        const child = minValue(afterPolicy, remaining - 1);
        const candidate = { value: child.value, state: child.state, path: [policy.id, ...child.path] };
        if (candidate.value > best.value + EPSILON) best = candidate;
      }
      memo.set(memoKey, best);
      return best;
    };

    const minValue = (state: NationState, remaining: number): ValueResult => {
      nodes += 1;
      if (nodes >= MAX_NODES || isTerminalBadState(state)) return { value: evaluateState(state), state, path: [] };
      const memoKey = `MIN#${remaining}#${stateKey(state)}`;
      const cached = memo.get(memoKey);
      if (cached) return cached;
      const outcomes = adverseOutcomes(state, minActionLimit);
      if (outcomes.length === 0) return maxValue(state, remaining);
      let worst: ValueResult = { value: Infinity, state, path: [] };
      for (const outcome of outcomes) {
        const child = maxValue(outcome.state, remaining);
        if (child.value < worst.value - EPSILON) worst = child;
      }
      memo.set(memoKey, worst);
      return worst;
    };

    const result = maxValue(cloneState(initialState), depth);
    return {
      best: result.path.slice(0, depth),
      state: result.state,
      nodes,
      score: result.value,
      algorithmValue: result.value,
      valueLabel: 'minimax value',
      improvementReached: result.value > evaluateState(initialState),
      effectiveDepth: depth,
      debug: { minimaxValue: Number(result.value.toFixed(2)), maxMinActions: minActionLimit },
    };
  });

// 17. Alpha-Beta: same Minimax value, but prunes branches outside the alpha/beta window.
export const alphaBeta: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Alpha-Beta', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(settings ? 3 : 2, requestedDepth));
    const minActionLimit = Math.max(2, Math.min(6, options.maxMinActions));
    let nodes = 0;
    let prunedBranches = 0;

    const maxValue = (state: NationState, remaining: number, alpha: number, beta: number): ValueResult => {
      nodes += 1;
      if (remaining === 0 || nodes >= MAX_NODES || isTerminalBadState(state)) return { value: evaluateState(state), state, path: [] };
      const policies = orderedMaxPolicies(state, true);
      if (policies.length === 0) return { value: evaluateState(state), state, path: [] };
      let best: ValueResult = { value: -Infinity, state, path: [] };
      let localAlpha = alpha;
      for (const policy of policies) {
        const afterPolicy = applyPolicyToState(state, policy);
        const child = minValue(afterPolicy, remaining - 1, localAlpha, beta);
        const candidate = { value: child.value, state: child.state, path: [policy.id, ...child.path] };
        if (candidate.value > best.value + EPSILON) best = candidate;
        localAlpha = Math.max(localAlpha, best.value);
        if (localAlpha >= beta - EPSILON) {
          prunedBranches += 1;
          break;
        }
      }
      return best;
    };

    const minValue = (state: NationState, remaining: number, alpha: number, beta: number): ValueResult => {
      nodes += 1;
      if (nodes >= MAX_NODES || isTerminalBadState(state)) return { value: evaluateState(state), state, path: [] };
      const outcomes = adverseOutcomes(state, minActionLimit).sort((a, b) => evaluateState(a.state) - evaluateState(b.state));
      if (outcomes.length === 0) return maxValue(state, remaining, alpha, beta);
      let worst: ValueResult = { value: Infinity, state, path: [] };
      let localBeta = beta;
      for (const outcome of outcomes) {
        const child = maxValue(outcome.state, remaining, alpha, localBeta);
        if (child.value < worst.value - EPSILON) worst = child;
        localBeta = Math.min(localBeta, worst.value);
        if (alpha >= localBeta - EPSILON) {
          prunedBranches += 1;
          break;
        }
      }
      return worst;
    };

    const result = maxValue(cloneState(initialState), depth, -Infinity, Infinity);
    return {
      best: result.path.slice(0, depth),
      state: result.state,
      nodes,
      score: result.value,
      algorithmValue: result.value,
      valueLabel: 'alpha-beta minimax value',
      improvementReached: result.value > evaluateState(initialState),
      effectiveDepth: depth,
      debug: { alphaBetaValue: Number(result.value.toFixed(2)), prunedBranches, pruningRatio: Number((prunedBranches / Math.max(1, nodes)).toFixed(3)), maxMinActions: minActionLimit },
    };
  });

// 18. Expectimax: MAX chooses policies; CHANCE nodes compute probability-weighted policy outcomes.
export const expectimax: SearchFn = (initialState, requestedDepth = 3, settings) =>
  measure('Expectimax', () => {
    const options = withSettings(settings);
    const depth = Math.max(1, Math.min(3, options.chanceMonths ?? requestedDepth));
    let nodes = 0;
    const memo = new Map<string, ValueResult>();

    const maxValue = (state: NationState, remaining: number): ValueResult => {
      nodes += 1;
      if (remaining === 0 || nodes >= MAX_NODES || isTerminalBadState(state)) return { value: evaluateState(state), state, path: [] };
      const memoKey = `MAX#${remaining}#${stateKey(state)}`;
      const cached = memo.get(memoKey);
      if (cached) return cached;
      const policies = getAvailablePolicies(state);
      if (policies.length === 0) return { value: evaluateState(state), state, path: [] };
      let best: ValueResult = { value: -Infinity, state, path: [] };
      for (const policy of policies) {
        const child = chanceValue(policyOutcomes(state, policy), remaining - 1);
        const candidate = { value: child.value, state: child.state, path: [policy.id, ...child.path] };
        if (candidate.value > best.value + EPSILON) best = candidate;
      }
      memo.set(memoKey, best);
      return best;
    };

    const chanceValue = (outcomes: WeightedState[], remaining: number): ValueResult => {
      nodes += 1;
      const children = outcomes.map((outcome) => ({ outcome, child: maxValue(outcome.state, remaining) }));
      const value = children.reduce((sum, item) => sum + item.outcome.probability * item.child.value, 0);
      const expectedState = averageStates(children.map((item) => ({ state: item.child.state, probability: item.outcome.probability, label: item.outcome.label })));
      const nominal = children.find((item) => item.outcome.label === 'success') ?? children[0];
      return { value, state: expectedState, path: nominal?.child.path ?? [] };
    };

    const result = maxValue(cloneState(initialState), depth);
    return {
      best: result.path.slice(0, depth),
      state: result.state,
      nodes,
      score: result.value,
      algorithmValue: result.value,
      valueLabel: 'expected value',
      improvementReached: result.value > evaluateState(initialState),
      effectiveDepth: depth,
      debug: { expectedValue: Number(result.value.toFixed(2)), outcomeMode: 'full enumeration', chanceMonths: depth },
    };
  });

export const algorithms: Record<string, SearchFn> = {
  BFS: bfs,
  DFS: dfs,
  IDS: ids,
  UCS: ucs,
  'Greedy Best-First': greedyBestFirst,
  'A*': aStar,
  'Hill Climbing': hillClimbing,
  'Local Beam Search': localBeamSearch,
  'Simulated Annealing': simulatedAnnealing,
  'AND-OR Search': andOrSearch,
  'Belief-State Search': beliefStateSearch,
  'LRTA*': lrtaStar,
  'Constraint Propagation': constraintPropagation,
  'Backtracking CSP': backtrackingCsp,
  'Min-Conflicts CSP': minConflictsCsp,
  Minimax: minimax,
  'Alpha-Beta': alphaBeta,
  Expectimax: expectimax,
};

export interface NationState {
  gdp: number;
  budget: number;
  debt: number;
  taxRate: number;
  inflation: number;
  unemployment: number;
  happiness: number;
  education: number;
  healthcare: number;
  energy: number;
  environment: number;
  military: number;
  technology: number;
  cybersecurity: number;
  infrastructure: number;
  diplomacy: number;
  population: number;
  month: number;
  year: number;
  active_events: string[];
  recentPolicies: string[];
}

export interface Policy {
  id: string;
  name: string;
  category: string;
  description: string;
  cost: number;
  effect: Partial<Record<keyof NationState, number>>;
}

export interface GameEvent {
  id: string;
  name: string;
  description: string;
  probability: number;
  effect: Partial<Record<keyof NationState, number>>;
}

export type AlgorithmDebugValue = string | number | boolean | null | string[] | number[] | Record<string, unknown> | Array<Record<string, unknown>>;

export interface AlgorithmResult {
  algorithm: string;
  /**
   * Full internal plan/trace produced by the algorithm. Only the first policy is
   * meant to be executed immediately; later entries are a forecast preview.
   */
  bestPolicies: string[];
  /** The single policy recommendation for the next month. */
  recommendedPolicyId?: string | null;
  /** UI-facing internal forecast; may contain null placeholders for uncertain branches. */
  planPreview?: Array<string | null>;
  projectedState: NationState;
  score: number;
  nodesExpanded: number;
  runtimeMs: number;
  /** Generic value used by the algorithm itself, e.g. minimax/expected/belief/conflict value. */
  algorithmValue?: number;
  valueLabel?: string;
  /** Whether the simulated result improves the current state. Kept alongside goalReached for compatibility. */
  improvementReached?: boolean;
  goalReached?: boolean;
  effectiveDepth?: number;
  executionMode?: 'planned' | 'online';
  displayPolicies?: Array<string | null>;
  debug?: Record<string, AlgorithmDebugValue>;
  conditionalPlan?: Record<string, unknown> | null;
}

export type SimulationRunStatus = 'completed' | 'collapsed';

/**
 * One user-triggered time advance. A run keeps every monthly snapshot so the
 * report can reproduce the complete simulation chronology instead of only the
 * newest state.
 */
export interface SimulationRun {
  id: string;
  sequence: number;
  requestedMonths: number;
  completedMonths: number;
  startState: NationState;
  endState: NationState;
  snapshots: NationState[];
  status: SimulationRunStatus;
  collapseReasons: string[];
  createdAt: string;
}

export type CollapseSource = 'simulation' | 'policy' | 'event' | 'state';

export interface CollapseNotice {
  source: CollapseSource;
  state: NationState;
  reasons: string[];
  runId?: string;
}

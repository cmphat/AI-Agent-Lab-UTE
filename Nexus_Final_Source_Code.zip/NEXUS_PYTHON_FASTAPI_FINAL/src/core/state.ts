import { NationState, Policy, GameEvent } from './types';
import { POLICIES } from './data';

export type NationHealthLevel = 'stable' | 'warning' | 'crisis' | 'critical' | 'collapsed';

export interface NationHealthAssessment {
  score: number;
  level: NationHealthLevel;
  criticalIndicators: string[];
  groups: {
    economicOutput: number;
    fiscal: number;
    social: number;
    pressureSafety: number;
  };
}

export interface FiscalMetrics {
  monthlyTaxRevenue: number;
  operatingCost: number;
  fiscalBalance: number;
}

const clampNumber = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const average = (values: number[]) => values.reduce((sum, value) => sum + value, 0) / Math.max(1, values.length);

const POSITIVE_EVENT_IDS = new Set(['boom', 'tech_breakthrough', 'trade_pact']);

const POLICY_CATEGORY_BY_ID = new Map(POLICIES.map((policy) => [policy.id, policy.category]));
const STATE_POLICY_REVERSAL_PAIRS: Array<[string, string]> = [
  ['tax_up', 'tax_down'],
  ['borrow', 'pay_debt'],
  ['austerity', 'welfare'],
  ['austerity', 'job_program'],
  ['power_plant', 'green_energy'],
  ['military', 'diplomacy'],
];

const isRecentPolicyReversal = (left: string, right: string): boolean =>
  STATE_POLICY_REVERSAL_PAIRS.some(([a, b]) => (left === a && right === b) || (left === b && right === a));

const recentPolicyStabilityPenalty = (state: NationState): number => {
  const recentPolicies = [...(state.recentPolicies ?? [])].filter((policyId) => POLICY_CATEGORY_BY_ID.has(policyId)).slice(-6);
  if (recentPolicies.length < 2) return 0;

  let penalty = 0;
  const categoryCounts: Record<string, number> = {};

  for (let index = 0; index < recentPolicies.length; index += 1) {
    const policyId = recentPolicies[index];
    const category = POLICY_CATEGORY_BY_ID.get(policyId) ?? 'Khác';
    categoryCounts[category] = (categoryCounts[category] ?? 0) + 1;

    const previous = recentPolicies[index - 1];
    if (!previous) continue;

    const recentBefore = recentPolicies.slice(Math.max(0, index - 4), index);
    if (previous === policyId) penalty += 48;
    if (isRecentPolicyReversal(previous, policyId)) penalty += 78;
    if (recentBefore.includes(policyId)) penalty += 38;
    if (recentBefore.some((recentPolicyId) => isRecentPolicyReversal(recentPolicyId, policyId))) penalty += 58;
  }

  const dominantCategoryCount = Math.max(0, ...Object.values(categoryCounts));
  const concentrationThreshold = Math.ceil(recentPolicies.length * 0.58);
  if (dominantCategoryCount > concentrationThreshold) {
    penalty += (dominantCategoryCount - concentrationThreshold) * 70;
  }

  const economicCount = categoryCounts['Kinh tế'] ?? 0;
  if (economicCount > 2) penalty += (economicCount - 2) * 75;

  return Math.min(650, penalty);
};
const countNegativeEvents = (eventIds: string[]): number => eventIds.filter((id) => !POSITIVE_EVENT_IDS.has(id)).length;

export const getInitialState = (): NationState => ({
  gdp: 1000.0,
  budget: 500.0,
  debt: 200.0,
  taxRate: 20.0,
  inflation: 5.0,
  unemployment: 8.0,
  happiness: 70.0,
  education: 50.0,
  healthcare: 50.0,
  energy: 60.0,
  environment: 60.0,
  military: 40.0,
  technology: 30.0,
  cybersecurity: 35.0,
  infrastructure: 45.0,
  diplomacy: 50.0,
  population: 1000000,
  month: 1,
  year: 2026,
  active_events: [],
  recentPolicies: [],
});

export const calculateMonthlyTaxRevenue = (state: NationState): number =>
  state.gdp * (state.taxRate / 100) / 12;

export const calculateOperatingCost = (state: NationState): number =>
  4 +
  state.education * 0.025 +
  state.healthcare * 0.025 +
  state.energy * 0.02 +
  state.infrastructure * 0.025 +
  state.cybersecurity * 0.02 +
  state.military * 0.015 +
  state.technology * 0.015;

export const calculateFiscalMetrics = (state: NationState): FiscalMetrics => {
  const monthlyTaxRevenue = calculateMonthlyTaxRevenue(state);
  const operatingCost = calculateOperatingCost(state);
  return {
    monthlyTaxRevenue,
    operatingCost,
    fiscalBalance: monthlyTaxRevenue - operatingCost,
  };
};

const calculatePopulationGrowthRate = (state: NationState): number => {
  const basePopulationGrowth = 0.00004;
  const healthcareGrowth = ((state.healthcare - 50) / 100) * 0.00018;
  const happinessGrowth = state.happiness >= 50
    ? ((state.happiness - 50) / 100) * 0.00006
    : 0;
  const happinessDecline = state.happiness < 40
    ? ((40 - state.happiness) / 100) * 0.00016
    : 0;

  return clampNumber(
    basePopulationGrowth + healthcareGrowth + happinessGrowth - happinessDecline,
    -0.00045,
    0.00035,
  );
};

const diminishingAboveAverage = (value: number, baseline: number, k = 25): number => {
  if (value <= baseline) {
    const shortage = baseline - value;
    return clampNumber(value - shortage * 0.15, 0, 100);
  }

  const excess = value - baseline;
  return clampNumber(baseline + k * (1 - Math.exp(-excess / k)), 0, 100);
};

const calculateTargetHappiness = (state: NationState, activeEventCount = state.active_events.length): number => {
  const employmentHealth = clampNumber(100 - state.unemployment, 0, 100);
  const priceHealth = clampNumber(100 - Math.max(0, state.inflation - 3) * 6, 0, 100);
  const taxComfort = clampNumber(100 - Math.max(0, state.taxRate - 20) * 8, 0, 100);
  const crisisComfort = clampNumber(100 - activeEventCount * 20, 0, 100);

  const socialAverage = average([
    state.healthcare,
    state.education,
    employmentHealth,
    priceHealth,
    taxComfort,
    crisisComfort,
  ]);

  const effectiveHealthcare = diminishingAboveAverage(state.healthcare, socialAverage);
  const effectiveEducation = diminishingAboveAverage(state.education, socialAverage);
  const effectiveEmployment = diminishingAboveAverage(employmentHealth, socialAverage);
  const effectivePrice = diminishingAboveAverage(priceHealth, socialAverage);
  const effectiveTax = diminishingAboveAverage(taxComfort, socialAverage);
  const effectiveCrisis = diminishingAboveAverage(crisisComfort, socialAverage);

  return clampNumber(
    effectiveHealthcare * 0.25 +
    effectiveEducation * 0.15 +
    effectiveEmployment * 0.22 +
    effectivePrice * 0.2 +
    effectiveTax * 0.08 +
    effectiveCrisis * 0.1,
    0,
    100,
  );
};

const gdpHealthFor = (state: NationState): number => {
  const populationScale = Math.max(0.1, state.population / 1_000_000);
  const gdpPerMillion = state.gdp / populationScale;
  return clampNumber((gdpPerMillion / 1000) * 100, 0, 100);
};

const budgetHealthFor = (state: NationState): number => {
  const { operatingCost } = calculateFiscalMetrics(state);
  const monthsOfReserve = state.budget / Math.max(1, operatingCost);
  return clampNumber((monthsOfReserve / 24) * 100, 0, 100);
};

const fiscalFlowHealthFor = (state: NationState): number => {
  const { operatingCost, fiscalBalance } = calculateFiscalMetrics(state);
  return clampNumber(50 + (fiscalBalance / Math.max(1, operatingCost)) * 50, 0, 100);
};

const debtSafetyFor = (state: NationState): number => {
  const debtRatio = state.debt / Math.max(1, state.gdp);
  if (debtRatio <= 0.35) return 100;
  return clampNumber(
    100 - (debtRatio - 0.35) * 240 - Math.max(0, debtRatio - 0.65) * 160,
    0,
    100,
  );
};

const inflationHealthFor = (state: NationState): number => {
  const highPenalty = Math.max(0, state.inflation - 3) * 8;
  const lowPenalty = Math.max(0, 1 - state.inflation) * 6;
  return clampNumber(100 - highPenalty - lowPenalty, 0, 100);
};

const employmentHealthFor = (state: NationState): number => {
  const normalPenalty = state.unemployment * 2;
  const severePenalty = Math.max(0, state.unemployment - 18) * 2.5;
  return clampNumber(100 - normalPenalty - severePenalty, 0, 100);
};

const taxBurdenHealthFor = (state: NationState): number => {
  const highPenalty = Math.max(0, state.taxRate - 24) * 8;
  const extremePenalty = Math.max(0, state.taxRate - 34) * 6;
  const lowRevenuePenalty = Math.max(0, 16 - state.taxRate) * 5 + Math.max(0, 10 - state.taxRate) * 5;
  return clampNumber(100 - highPenalty - extremePenalty - lowRevenuePenalty, 0, 100);
};

const resilienceHealthFor = (state: NationState): number => {
  const hardSecurity = average([state.cybersecurity, state.military, state.diplomacy]);
  const productiveBase = average([state.energy, state.infrastructure, state.technology]);
  const publicBase = average([state.education, state.healthcare]);
  const ecologicalBase = state.environment;
  return clampNumber(
    hardSecurity * 0.24 + productiveBase * 0.3 + publicBase * 0.28 + ecologicalBase * 0.18,
    0,
    100,
  );
};

const developmentPotentialFor = (state: NationState): number => {
  const humanCapital = state.education * 0.55 + state.healthcare * 0.45;
  const productiveCapital = state.technology * 0.34 + state.infrastructure * 0.33 + state.energy * 0.33;
  const riskBuffer = state.cybersecurity * 0.32 + state.environment * 0.3 + state.diplomacy * 0.24 + state.military * 0.14;

  return clampNumber(
    humanCapital * 0.34 + productiveCapital * 0.39 + riskBuffer * 0.27,
    0,
    100,
  );
};

const growthOutlookFor = (state: NationState): number => {
  const productivityScore =
    state.education * 0.25 +
    state.technology * 0.25 +
    state.infrastructure * 0.2 +
    state.energy * 0.15 +
    state.healthcare * 0.15;
  const laborReadiness = clampNumber(100 - state.unemployment * 2.2, 0, 100);
  const priceReadiness = inflationHealthFor(state);
  const fiscalReadiness = average([budgetHealthFor(state), fiscalFlowHealthFor(state), debtSafetyFor(state)]);

  return clampNumber(
    productivityScore * 0.42 + laborReadiness * 0.2 + priceReadiness * 0.18 + fiscalReadiness * 0.2,
    0,
    100,
  );
};

const eventSafetyFor = (state: NationState): number =>
  clampNumber(100 - countNegativeEvents(state.active_events) * 25, 0, 100);

const populationTrendHealthFor = (state: NationState): number =>
  clampNumber(50 + calculatePopulationGrowthRate(state) * 500_000, 0, 100);

/**
 * Converts the raw nation state into a 0-100 national sustainability index.
 * The four groups deliberately avoid mixing direct causes with their results:
 * GDP is separated from inflation/unemployment pressure, and healthcare/education
 * flow into happiness/population instead of being counted again as direct social health.
 */
export const assessNationHealth = (state: NationState): NationHealthAssessment => {
  const gdpHealth = gdpHealthFor(state);
  const budgetHealth = budgetHealthFor(state);
  const fiscalFlowHealth = fiscalFlowHealthFor(state);
  const debtSafety = debtSafetyFor(state);
  const populationTrendHealth = populationTrendHealthFor(state);
  const inflationHealth = inflationHealthFor(state);
  const employmentHealth = employmentHealthFor(state);
  const taxBurdenHealth = taxBurdenHealthFor(state);
  const resilienceHealth = resilienceHealthFor(state);
  const developmentPotential = developmentPotentialFor(state);
  const eventSafety = eventSafetyFor(state);

  const economicOutput = gdpHealth;
  const fiscal = clampNumber(
    budgetHealth * 0.28 + fiscalFlowHealth * 0.22 + debtSafety * 0.5,
    0,
    100,
  );
  const social = clampNumber(
    state.happiness * 0.38 +
      populationTrendHealth * 0.16 +
      state.education * 0.23 +
      state.healthcare * 0.23,
    0,
    100,
  );
  const pressureSafety = clampNumber(
    inflationHealth * 0.23 +
      employmentHealth * 0.23 +
      taxBurdenHealth * 0.16 +
      eventSafety * 0.14 +
      resilienceHealth * 0.24,
    0,
    100,
  );

  const groups = {
    economicOutput,
    fiscal,
    social,
    pressureSafety,
  };

  const groupValues = Object.values(groups);
  const baseHealth =
    economicOutput * 0.22 +
    fiscal * 0.24 +
    social * 0.24 +
    pressureSafety * 0.2 +
    developmentPotential * 0.1;
  const weakestGroup = Math.min(...groupValues);
  const weaknessPenalty = Math.max(0, 55 - weakestGroup) * 0.55;
  const groupAverage = average(groupValues);
  const imbalancePenalty = average(groupValues.map((value) => Math.abs(value - groupAverage))) * 0.2;
  const score = clampNumber(baseHealth - weaknessPenalty - imbalancePenalty, 0, 100);

  const criticalIndicators: string[] = [];
  if (gdpHealth < 25) criticalIndicators.push('gdp');
  if (budgetHealth < 20 || fiscalFlowHealth < 15) criticalIndicators.push('budget');
  if (debtSafety < 25) criticalIndicators.push('debt');
  if (state.happiness < 25) criticalIndicators.push('happiness');
  if (populationTrendHealth < 20 || state.population < 100_000) criticalIndicators.push('population');
  if (inflationHealth < 25) criticalIndicators.push('inflation');
  if (employmentHealth < 25) criticalIndicators.push('unemployment');
  if (taxBurdenHealth < 25) criticalIndicators.push('taxRate');
  if (resilienceHealth < 25) criticalIndicators.push('resilience');
  if (eventSafety < 35) criticalIndicators.push('active_events');

  let level: NationHealthLevel;
  if (state.gdp <= 50 || state.population <= 50_000 || score <= 15 || criticalIndicators.length >= 5) {
    level = 'collapsed';
  } else if (criticalIndicators.length >= 3 || score < 30) {
    level = 'critical';
  } else if (criticalIndicators.length >= 2 || score < 50) {
    level = 'crisis';
  } else if (criticalIndicators.length >= 1 || state.active_events.length > 0 || score < 70) {
    level = 'warning';
  } else {
    level = 'stable';
  }

  return { score, level, criticalIndicators, groups };
};

const potentialTowardTarget = (value: number, target = 82, floor = 35): number => {
  const usableProgress = clampNumber(value, floor, target) - floor;
  const targetProgress = Math.max(1, target - floor);
  const progressScore = (usableProgress / targetProgress) * 100;
  const surplusScore = Math.max(0, value - target) * 1.15;
  return clampNumber(progressScore + surplusScore, 0, 130);
};

const calculateFuturePotentialBonus = (state: NationState): number => {
  const rawBonus =
    potentialTowardTarget(state.technology, 78, 28) * 1.05 +
    potentialTowardTarget(state.education, 82, 38) * 0.85 +
    potentialTowardTarget(state.healthcare, 82, 38) * 0.8 +
    potentialTowardTarget(state.infrastructure, 82, 35) * 0.8 +
    potentialTowardTarget(state.energy, 82, 40) * 0.65 +
    potentialTowardTarget(state.cybersecurity, 82, 35) * 0.65 +
    potentialTowardTarget(state.environment, 82, 40) * 0.55 +
    potentialTowardTarget(state.diplomacy, 78, 38) * 0.45 +
    potentialTowardTarget(state.military, 75, 35) * 0.25;

  return Math.min(rawBonus, 520);
};

export const evaluateState = (state: NationState): number => {
  const health = assessNationHealth(state);
  if (health.level === 'collapsed') return -100000;

  const nationHealthScore = health.score * 8.4;
  const futurePotentialScore = developmentPotentialFor(state) * 1.45 + growthOutlookFor(state) * 0.75;
  const futurePotentialBonus = calculateFuturePotentialBonus(state);
  const debtRatio = state.debt / Math.max(1, state.gdp);
  const debtOverhangPenalty =
    Math.max(0, debtRatio - 0.5) * 420 +
    Math.max(0, debtRatio - 0.85) * 760 +
    Math.max(0, debtRatio - 1.15) * 1050;
  const dangerPenalty =
    health.level === 'critical'
      ? 3000
      : health.level === 'crisis'
        ? 1000
        : health.level === 'warning'
          ? 210
          : 0;

  const policyChurnPenalty = recentPolicyStabilityPenalty(state);

  return Number((nationHealthScore + futurePotentialScore + futurePotentialBonus - dangerPenalty - debtOverhangPenalty - policyChurnPenalty).toFixed(2));
};


export const getAdjustedEventProbability = (state: NationState, event: GameEvent): number => {
  const debtRatio = state.debt / Math.max(1, state.gdp);
  const debtRisk = Math.max(0, debtRatio - 0.7);
  const lowDiplomacy = Math.max(0, 50 - state.diplomacy);
  const lowHealthcare = Math.max(0, 55 - state.healthcare);
  const lowCybersecurity = Math.max(0, 60 - state.cybersecurity);
  const lowEnvironment = Math.max(0, 55 - state.environment);
  const lowHappiness = Math.max(0, 45 - state.happiness);
  const lowEnergy = Math.max(0, 45 - state.energy);
  const lowInfrastructure = Math.max(0, 50 - state.infrastructure);
  const lowMilitary = Math.max(0, 50 - state.military);
  const highInflation = Math.max(0, state.inflation - 6);
  const highUnemployment = Math.max(0, state.unemployment - 10);
  const defenseBuffer = Math.max(0, state.military - 55);

  let multiplier = 1;
  switch (event.id) {
    case 'pandemic':
      multiplier += lowHealthcare * 0.008 + Math.max(0, state.population / 1_000_000 - 1) * 0.08;
      break;
    case 'recession':
      multiplier += debtRisk * 0.7 + highInflation * 0.035 + highUnemployment * 0.025;
      break;
    case 'supply_chain':
      multiplier += debtRisk * 0.2 + lowDiplomacy * 0.005 + lowInfrastructure * 0.005 + lowEnergy * 0.004;
      break;
    case 'oil_crisis':
      multiplier += debtRisk * 0.2 + lowEnergy * 0.012 + lowDiplomacy * 0.005;
      break;
    case 'war':
      multiplier += lowDiplomacy * 0.01 + lowMilitary * 0.006 - defenseBuffer * 0.005;
      break;
    case 'cyberattack':
      multiplier += lowCybersecurity * 0.011;
      break;
    case 'protest':
      multiplier += lowHappiness * 0.016 + highInflation * 0.02 + highUnemployment * 0.015;
      break;
    case 'climate':
      multiplier += lowEnvironment * 0.01;
      break;
    case 'disaster':
      multiplier += lowEnvironment * 0.006 + lowInfrastructure * 0.007;
      break;
    case 'boom':
      multiplier += Math.max(0, state.happiness - 65) * 0.003 + Math.max(0, state.infrastructure - 55) * 0.002;
      multiplier -= debtRisk * 0.35 + highInflation * 0.02 + highUnemployment * 0.015;
      break;
    case 'tech_breakthrough':
      multiplier += Math.max(0, state.education - 60) * 0.004 + Math.max(0, state.technology - 60) * 0.003;
      break;
    case 'trade_pact':
      multiplier += Math.max(0, state.diplomacy - 55) * 0.008 + Math.max(0, state.infrastructure - 55) * 0.002 - debtRisk * 0.25;
      break;
    default:
      break;
  }

  return clampNumber(event.probability * clampNumber(multiplier, 0.25, 3), 0, 0.35);
};

export const isNationCollapsed = (state: NationState): boolean =>
  assessNationHealth(state).level === 'collapsed';

/**
 * Returns machine-readable causes used by both the collapse modal and the
 * exported report. The UI translates metric keys through metricName().
 */
export const getCollapseReasons = (state: NationState): string[] => {
  const reasons: string[] = [];
  const health = assessNationHealth(state);

  if (state.gdp <= 50 || health.groups.economicOutput < 20) reasons.push('gdp');
  if (health.groups.fiscal < 20) reasons.push('budget');
  if (debtSafetyFor(state) < 20) reasons.push('debt');
  if (inflationHealthFor(state) < 20) reasons.push('inflation');
  if (employmentHealthFor(state) < 20) reasons.push('unemployment');
  if (state.happiness <= 10 || health.groups.social < 20) reasons.push('happiness');
  if (state.population <= 50_000) reasons.push('population');

  if (reasons.length === 0 && health.score <= 15) {
    reasons.push('system');
  }

  return [...new Set(reasons)];
};

export const applyPolicyToState = (state: NationState, policy: Policy): NationState => {
  if (state.budget < policy.cost) {
    return {
      ...state,
      active_events: [...state.active_events],
      recentPolicies: [...(state.recentPolicies ?? [])].slice(-6),
    };
  }

  const next: NationState = {
    ...state,
    budget: state.budget - policy.cost,
    active_events: [...state.active_events],
    recentPolicies: [...(state.recentPolicies ?? []), policy.id].slice(-6),
  };

  for (const [key, value] of Object.entries(policy.effect)) {
    if (typeof value !== 'number') continue;
    const numericKey = key as Exclude<keyof NationState, 'active_events'>;
    if (typeof next[numericKey] === 'number') {
      (next[numericKey] as number) += value;
    }
  }

  return clampState(next);
};

export const applyEventToState = (state: NationState, event: GameEvent): NationState => {
  const next: NationState = {
    ...state,
    active_events: [...state.active_events],
    recentPolicies: [...(state.recentPolicies ?? [])].slice(-6),
  };

  for (const [key, value] of Object.entries(event.effect)) {
    if (typeof value !== 'number') continue;
    const numericKey = key as Exclude<keyof NationState, 'active_events'>;
    if (typeof next[numericKey] === 'number') {
      (next[numericKey] as number) += value;
    }
  }

  // Events describe crises active in the current month only. Duplicates are removed.
  next.active_events = [...new Set([...next.active_events, event.id])].slice(-4);
  return clampState(next);
};

export const clampState = (state: NationState): NationState => ({
  ...state,
  gdp: Math.max(1, state.gdp),
  budget: Math.max(0, state.budget),
  debt: Math.max(0, state.debt),
  taxRate: clampNumber(state.taxRate, 0, 45),
  population: Math.max(0, Math.round(state.population)),
  happiness: clampNumber(state.happiness, 0, 100),
  education: clampNumber(state.education, 0, 100),
  healthcare: clampNumber(state.healthcare, 0, 100),
  energy: clampNumber(state.energy, 0, 100),
  environment: clampNumber(state.environment, 0, 100),
  military: clampNumber(state.military, 0, 100),
  technology: clampNumber(state.technology, 0, 100),
  cybersecurity: clampNumber(state.cybersecurity, 0, 100),
  infrastructure: clampNumber(state.infrastructure, 0, 100),
  diplomacy: clampNumber(state.diplomacy, 0, 100),
  inflation: clampNumber(state.inflation, -2, 100),
  unemployment: clampNumber(state.unemployment, 0, 100),
  active_events: [...state.active_events],
  recentPolicies: [...(state.recentPolicies ?? [])].slice(-6),
});

/**
 * Advances exactly one simulated month. Random events are intentionally handled
 * by GameProvider so search algorithms remain deterministic. Foundation metrics
 * such as education, healthcare, infrastructure, energy, technology and defense
 * do not auto-change here; policies/events are responsible for changing them.
 */
export const advanceMonth = (state: NationState): NationState => {
  const currentEventCount = countNegativeEvents(state.active_events);
  const next: NationState = {
    ...state,
    active_events: [],
    recentPolicies: [...(state.recentPolicies ?? [])].slice(-6),
  };

  next.month += 1;
  if (next.month > 12) {
    next.month = 1;
    next.year += 1;
  }

  const populationScale = Math.max(0.1, state.population / 1_000_000);

  const baseJobCapacity =
    0.75 +
    state.education * 0.004 +
    state.technology * 0.003 +
    state.infrastructure * 0.003;
  const taxBusinessPressure = Math.max(0, state.taxRate - 24) * 0.009;
  const jobCapacity = baseJobCapacity - taxBusinessPressure;
  const laborPressure = populationScale - jobCapacity;
  next.unemployment += clampNumber(laborPressure * 0.45, -0.35, 0.6);

  const supplyCapacity =
    0.8 +
    state.energy * 0.004 +
    state.infrastructure * 0.003 +
    state.technology * 0.002;
  const demandSupplyGap = populationScale - supplyCapacity;
  const populationPricePressure = clampNumber(demandSupplyGap * 0.2, -0.18, 0.35);
  const energyPricePressure = Math.max(0, 45 - state.energy) * 0.006;
  next.inflation += (3 - state.inflation) * 0.04 + populationPricePressure + energyPricePressure;

  const productivityScore =
    state.education * 0.25 +
    state.technology * 0.25 +
    state.infrastructure * 0.2 +
    state.energy * 0.15 +
    state.healthcare * 0.15;
  const populationGrowthEffect = clampNumber(
    (populationScale - 1) * (productivityScore / 100) * 0.001,
    -0.001,
    0.002,
  );
  const capabilityGrowth =
    state.technology * 0.000006 +
    state.education * 0.000003 +
    state.infrastructure * 0.000004 +
    state.energy * 0.000003;
  const inflationDrag = Math.max(0, next.inflation - 4) * 0.00045;
  const unemploymentDrag = Math.max(0, next.unemployment - 6) * 0.00032;
  const taxDrag = Math.max(0, state.taxRate - 24) * 0.00035;
  const monthlyGrowth = clampNumber(
    0.0015 + capabilityGrowth + populationGrowthEffect - inflationDrag - unemploymentDrag - taxDrag,
    -0.02,
    0.012,
  );

  next.gdp *= 1 + monthlyGrowth;

  const fiscalMetrics = calculateFiscalMetrics(next);
  next.budget += fiscalMetrics.fiscalBalance;
  next.debt *= 1.0025;

  const targetHappiness = calculateTargetHappiness(next, currentEventCount);
  next.happiness += (targetHappiness - state.happiness) * 0.08;

  next.population *= 1 + calculatePopulationGrowthRate(next);

  return clampState(next);
};

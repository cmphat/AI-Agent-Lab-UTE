import { createContext, useContext, useState, ReactNode, useCallback, useEffect, useMemo } from 'react';
import {
  NationState,
  GameEvent,
  Policy,
  SimulationRun,
  CollapseNotice,
} from './types';
import {
  getInitialState,
  applyPolicyToState,
  advanceMonth,
  applyEventToState,
  getCollapseReasons,
  isNationCollapsed,
  getAdjustedEventProbability,
} from './state';
import { EVENTS, POLICIES } from './data';
import { createLrtaHeuristicMemory, learnLrtaTransition, resetLrtaMemory, selectLrtaStarPolicy } from './algorithms';
import { AIAdvancedSettings, readAISettings, normalizeAISettings } from './aiSettings';

interface GameContextType {
  state: NationState;
  history: NationState[];
  simulationRuns: SimulationRun[];
  applyPolicy: (policy: Policy) => void;
  executePolicyPlan: (policyIds: string[]) => void;
  executeOnlinePolicyPlan: (algorithm: string, months: number, firstPolicyId?: string) => void;
  nextMonth: () => void;
  advanceTime: (months: number) => void;
  reset: () => void;
  loadScenarioState: (state: NationState) => void;
  triggerEvent: (event: GameEvent) => void;
  setState: (state: NationState) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  selectedAlgorithm: string;
  setSelectedAlgorithm: (algorithm: string) => void;
  aiSettings: AIAdvancedSettings;
  updateAISetting: <K extends keyof AIAdvancedSettings>(key: K, value: AIAdvancedSettings[K]) => void;
  resetAISettings: () => void;
  isCollapsed: boolean;
  collapseNotice: CollapseNotice | null;
  dismissCollapseNotice: () => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

const cloneState = (state: NationState): NationState => ({
  ...state,
  active_events: [...state.active_events],
  recentPolicies: [...(state.recentPolicies ?? [])].slice(-6),
});

const rollMonthlyEvent = (state: NationState): GameEvent | null => {
  const weightedEvents = EVENTS.map((event) => ({
    event,
    probability: getAdjustedEventProbability(state, event),
  }));
  const monthlyEventChance = 1 - weightedEvents.reduce((remaining, item) => remaining * (1 - item.probability), 1);
  if (Math.random() >= monthlyEventChance) return null;

  const totalWeight = weightedEvents.reduce((sum, item) => sum + item.probability, 0);
  let ticket = Math.random() * totalWeight;
  for (const item of weightedEvents) {
    ticket -= item.probability;
    if (ticket <= 0) return item.event;
  }
  return weightedEvents[weightedEvents.length - 1]?.event ?? null;
};

export const GameProvider = ({ children }: { children: ReactNode }) => {
  const initial = useMemo(() => getInitialState(), []);
  const [state, setGameState] = useState<NationState>(initial);
  const [history, setHistory] = useState<NationState[]>([initial]);
  const [simulationRuns, setSimulationRuns] = useState<SimulationRun[]>([]);
  const [collapseNotice, setCollapseNotice] = useState<CollapseNotice | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const savedTheme = localStorage.getItem('nation-theme');
    if (savedTheme === 'light' || savedTheme === 'dark') return savedTheme;
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });
  const [selectedAlgorithm, setSelectedAlgorithmState] = useState<string>(
    () => localStorage.getItem('nation-selected-algorithm') || 'A*',
  );
  const [aiSettings, setAISettings] = useState<AIAdvancedSettings>(() => readAISettings());

  const isCollapsed = isNationCollapsed(state);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    root.dataset.theme = theme;
    root.style.colorScheme = theme;
    localStorage.setItem('nation-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('nation-selected-algorithm', selectedAlgorithm);
  }, [selectedAlgorithm]);

  useEffect(() => {
    localStorage.setItem('nexus-ai-advanced-settings', JSON.stringify(aiSettings));
  }, [aiSettings]);

  const showExistingCollapse = useCallback((collapsedState: NationState, source: CollapseNotice['source']) => {
    setCollapseNotice({
      source,
      state: cloneState(collapsedState),
      reasons: getCollapseReasons(collapsedState),
    });
  }, []);

  const applyPolicy = useCallback((policy: Policy) => {
    setGameState((previous) => {
      if (isNationCollapsed(previous)) {
        showExistingCollapse(previous, 'policy');
        return previous;
      }

      const next = applyPolicyToState(previous, policy);
      learnLrtaTransition(previous, policy.id, next, undefined, aiSettings.lrtaMemoryMode === 'persistent');
      setHistory((current) => [...current, cloneState(next)]);

      if (isNationCollapsed(next)) {
        setCollapseNotice({
          source: 'policy',
          state: cloneState(next),
          reasons: getCollapseReasons(next),
        });
      }
      return next;
    });
  }, [aiSettings.lrtaMemoryMode, showExistingCollapse]);

  const triggerEvent = useCallback((event: GameEvent) => {
    setGameState((previous) => {
      if (isNationCollapsed(previous)) {
        showExistingCollapse(previous, 'event');
        return previous;
      }

      const next = applyEventToState(previous, event);
      setHistory((current) => [...current, cloneState(next)]);

      if (isNationCollapsed(next)) {
        setCollapseNotice({
          source: 'event',
          state: cloneState(next),
          reasons: getCollapseReasons(next),
        });
      }
      return next;
    });
  }, [showExistingCollapse]);

  const executePolicyPlan = useCallback((policyIds: string[]) => {
    const plannedPolicyIds = policyIds.filter((policyId) => POLICIES.some((policy) => policy.id === policyId));
    if (plannedPolicyIds.length === 0) return;

    setGameState((previous) => {
      if (isNationCollapsed(previous)) {
        showExistingCollapse(previous, 'simulation');
        return previous;
      }

      const startState = cloneState(previous);
      let next = cloneState(previous);
      const snapshots: NationState[] = [];
      let completedMonths = 0;
      let collapsed = false;

      for (const policyId of plannedPolicyIds) {
        const policy = POLICIES.find((item) => item.id === policyId);
        if (!policy) continue;

        // AI plans are committed before execution: each planned policy consumes
        // exactly one simulated month. Monthly crises may change the state, but
        // they do not cause the AI to recalculate or reorder the remaining plan.
        const beforePolicy = cloneState(next);
        next = applyPolicyToState(next, policy);
        next = advanceMonth(next);
        learnLrtaTransition(beforePolicy, policy.id, next, undefined, aiSettings.lrtaMemoryMode === 'persistent');

        const event = rollMonthlyEvent(next);
        if (event) next = applyEventToState(next, event);

        snapshots.push(cloneState(next));
        completedMonths += 1;

        if (isNationCollapsed(next)) {
          collapsed = true;
          break;
        }
      }

      if (snapshots.length > 0) {
        setHistory((current) => [...current, ...snapshots]);
      }

      const runDraft = {
        id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        requestedMonths: plannedPolicyIds.length,
        completedMonths,
        startState,
        endState: cloneState(next),
        snapshots,
        status: collapsed ? 'collapsed' as const : 'completed' as const,
        collapseReasons: collapsed ? getCollapseReasons(next) : [],
        createdAt: new Date().toISOString(),
      };

      setSimulationRuns((current) => {
        const run: SimulationRun = {
          ...runDraft,
          sequence: current.length + 1,
        };

        if (collapsed) {
          setCollapseNotice({
            source: 'simulation',
            state: cloneState(next),
            reasons: run.collapseReasons,
            runId: run.id,
          });
        }

        return [...current, run];
      });

      return next;
    });
  }, [aiSettings.lrtaMemoryMode, showExistingCollapse]);


  const executeOnlinePolicyPlan = useCallback((algorithm: string, months: number, firstPolicyId?: string) => {
    const totalMonths = Math.max(1, Math.min(8, Math.floor(months)));

    if (algorithm !== 'LRTA*') {
      executePolicyPlan(firstPolicyId ? [firstPolicyId] : []);
      return;
    }

    setGameState((previous) => {
      if (isNationCollapsed(previous)) {
        showExistingCollapse(previous, 'simulation');
        return previous;
      }

      const startState = cloneState(previous);
      const usePersistentLrta = aiSettings.lrtaMemoryMode === 'persistent';
      const memory = createLrtaHeuristicMemory(usePersistentLrta);
      const appliedPath: string[] = [];
      const snapshots: NationState[] = [];
      let next = cloneState(previous);
      let completedMonths = 0;
      let collapsed = false;

      for (let step = 0; step < totalMonths; step += 1) {
        // LRTA* is online: before every month it observes the current metrics
        // and any active crisis left by the previous month, then learns/chooses
        // only the next policy instead of following a fixed remaining plan.
        const decision = selectLrtaStarPolicy(next, appliedPath, memory, usePersistentLrta);
        const selectedPolicy = decision?.policy;
        if (!selectedPolicy) break;

        const beforePolicy = cloneState(next);
        next = applyPolicyToState(next, selectedPolicy);
        next = advanceMonth(next);
        learnLrtaTransition(beforePolicy, selectedPolicy.id, next, memory, usePersistentLrta);

        const event = rollMonthlyEvent(next);
        if (event) next = applyEventToState(next, event);

        appliedPath.push(selectedPolicy.id);
        snapshots.push(cloneState(next));
        completedMonths += 1;

        if (isNationCollapsed(next)) {
          collapsed = true;
          break;
        }
      }

      if (snapshots.length > 0) {
        setHistory((current) => [...current, ...snapshots]);
      }

      const runDraft = {
        id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        requestedMonths: totalMonths,
        completedMonths,
        startState,
        endState: cloneState(next),
        snapshots,
        status: collapsed ? 'collapsed' as const : 'completed' as const,
        collapseReasons: collapsed ? getCollapseReasons(next) : [],
        createdAt: new Date().toISOString(),
      };

      setSimulationRuns((current) => {
        const run: SimulationRun = {
          ...runDraft,
          sequence: current.length + 1,
        };

        if (collapsed) {
          setCollapseNotice({
            source: 'simulation',
            state: cloneState(next),
            reasons: run.collapseReasons,
            runId: run.id,
          });
        }

        return [...current, run];
      });

      return next;
    });
  }, [aiSettings.lrtaMemoryMode, executePolicyPlan, showExistingCollapse]);

  const advanceTime = useCallback((months: number) => {
    const boundedMonths = Math.max(1, Math.min(1200, Math.floor(months)));

    setGameState((previous) => {
      if (isNationCollapsed(previous)) {
        showExistingCollapse(previous, 'simulation');
        return previous;
      }

      const startState = cloneState(previous);
      let next = cloneState(previous);
      const snapshots: NationState[] = [];
      let completedMonths = 0;
      let collapsed = false;

      for (let index = 0; index < boundedMonths; index += 1) {
        next = advanceMonth(next);
        const event = rollMonthlyEvent(next);
        if (event) next = applyEventToState(next, event);

        snapshots.push(cloneState(next));
        completedMonths += 1;

        if (isNationCollapsed(next)) {
          collapsed = true;
          break;
        }
      }

      if (snapshots.length > 0) {
        setHistory((current) => [...current, ...snapshots]);
      }

      const runDraft = {
        id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        requestedMonths: boundedMonths,
        completedMonths,
        startState,
        endState: cloneState(next),
        snapshots,
        status: collapsed ? 'collapsed' as const : 'completed' as const,
        collapseReasons: collapsed ? getCollapseReasons(next) : [],
        createdAt: new Date().toISOString(),
      };

      setSimulationRuns((current) => {
        const run: SimulationRun = {
          ...runDraft,
          sequence: current.length + 1,
        };

        if (collapsed) {
          setCollapseNotice({
            source: 'simulation',
            state: cloneState(next),
            reasons: run.collapseReasons,
            runId: run.id,
          });
        }

        return [...current, run];
      });

      return next;
    });
  }, [showExistingCollapse]);

  const nextMonth = useCallback(() => advanceTime(1), [advanceTime]);

  const reset = useCallback(() => {
    const nextInitial = getInitialState();
    setGameState(nextInitial);
    setHistory([nextInitial]);
    setSimulationRuns([]);
    setCollapseNotice(null);
  }, []);

  const loadScenarioState = useCallback((nextState: NationState) => {
    const safeState = cloneState(nextState);
    setGameState(safeState);
    setHistory([safeState]);
    setSimulationRuns([]);

    if (isNationCollapsed(safeState)) {
      setCollapseNotice({
        source: 'state',
        state: safeState,
        reasons: getCollapseReasons(safeState),
      });
    } else {
      setCollapseNotice(null);
    }
  }, []);

  const setState = useCallback((nextState: NationState) => {
    const safeState = cloneState(nextState);
    setGameState(safeState);
    setHistory((current) => [...current, safeState]);

    if (isNationCollapsed(safeState)) {
      setCollapseNotice({
        source: 'state',
        state: safeState,
        reasons: getCollapseReasons(safeState),
      });
    } else {
      setCollapseNotice(null);
    }
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((current) => current === 'light' ? 'dark' : 'light');
  }, []);

  const setSelectedAlgorithm = useCallback((algorithm: string) => {
    setSelectedAlgorithmState(algorithm);
  }, []);

  const updateAISetting = useCallback(<K extends keyof AIAdvancedSettings>(key: K, value: AIAdvancedSettings[K]) => {
    setAISettings((current) => normalizeAISettings({ ...current, [key]: value }));
  }, []);

  const resetAISettings = useCallback(() => {
    setAISettings(normalizeAISettings({}));
    resetLrtaMemory();
  }, []);

  const dismissCollapseNotice = useCallback(() => {
    setCollapseNotice(null);
  }, []);

  return (
    <GameContext.Provider
      value={{
        state,
        history,
        simulationRuns,
        applyPolicy,
        executePolicyPlan,
        executeOnlinePolicyPlan,
        nextMonth,
        advanceTime,
        reset,
        loadScenarioState,
        triggerEvent,
        setState,
        theme,
        toggleTheme,
        selectedAlgorithm,
        setSelectedAlgorithm,
        aiSettings,
        updateAISetting,
        resetAISettings,
        isCollapsed,
        collapseNotice,
        dismissCollapseNotice,
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) throw new Error('useGame must be used within GameProvider');
  return context;
};

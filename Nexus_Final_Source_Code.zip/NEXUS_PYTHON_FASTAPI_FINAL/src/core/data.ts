import { Policy, GameEvent } from './types';

export const POLICIES: Policy[] = [
  // Kinh tế (Economics)
  { id: 'tax_up', name: 'Tăng thuế', category: 'Kinh tế', description: 'Tăng tỷ lệ thuế để cải thiện nguồn thu ngân sách trong các tháng sau, nhưng gây phản ứng xã hội tức thời và tạo áp lực lên tăng trưởng, việc làm theo thời gian', cost: 15, effect: { taxRate: 1.5, happiness: -2.2 } },
  { id: 'tax_down', name: 'Giảm thuế', category: 'Kinh tế', description: 'Giảm tỷ lệ thuế để giảm áp lực lên người dân và doanh nghiệp, đổi lại nguồn thu ngân sách tương lai sẽ thấp hơn', cost: 15, effect: { taxRate: -1.5, happiness: 0.6 } },
  { id: 'borrow', name: 'Vay nợ', category: 'Kinh tế', description: 'Tăng ngân sách ngắn hạn bằng cách tăng nợ công tương ứng, đồng thời tạo thêm áp lực lạm phát và niềm tin xã hội nhẹ', cost: 0, effect: { budget: 150, debt: 150, inflation: 0.8, happiness: -1.2 } },
  { id: 'pay_debt', name: 'Trả nợ', category: 'Kinh tế', description: 'Dùng ngân sách hiện có để giảm nợ công tương ứng, qua đó giảm rủi ro tài chính dài hạn', cost: 150, effect: { debt: -150, happiness: -0.3 } },
  { id: 'business_grant', name: 'Hỗ trợ doanh nghiệp', category: 'Kinh tế', description: 'Hỗ trợ doanh nghiệp mở rộng sản xuất, cải thiện việc làm và năng lực sản xuất thay vì làm GDP tăng ngay lập tức', cost: 75, effect: { unemployment: -1.7, technology: 1.6, infrastructure: 1.6, happiness: 0.3 } },
  { id: 'austerity', name: 'Thắt lưng buộc bụng', category: 'Kinh tế', description: 'Cắt giảm chi tiêu công để hạ áp lực lạm phát, nhưng làm giảm chất lượng dịch vụ công và tăng áp lực việc làm', cost: 0, effect: { inflation: -1.2, unemployment: 1.1, education: -1, healthcare: -1, infrastructure: -1, happiness: -1.2 } },
  { id: 'inflation_control', name: 'Kiểm soát lạm phát', category: 'Kinh tế', description: 'Can thiệp để giảm lạm phát nhưng làm thị trường lao động chịu áp lực ngắn hạn', cost: 35, effect: { inflation: -2, unemployment: 0.6 } },
  { id: 'economic_stimulus', name: 'Gói kích thích kinh tế', category: 'Kinh tế', description: 'Bơm nguồn lực để giảm tác động suy thoái và hỗ trợ việc làm, nhưng làm tăng nợ và lạm phát', cost: 135, effect: { unemployment: -2.4, infrastructure: 2, happiness: 1, inflation: 1, debt: 45 } },
  { id: 'supply_chain_stabilization', name: 'Ổn định chuỗi cung ứng', category: 'Kinh tế', description: 'Can thiệp logistics và thương mại để giảm áp lực đứt gãy chuỗi cung ứng, nhưng làm tăng nợ ngắn hạn', cost: 95, effect: { infrastructure: 4, diplomacy: 2, energy: 1, inflation: -1, debt: 18 } },

  // Xã hội (Social)
  { id: 'edu_invest', name: 'Đầu tư giáo dục', category: 'Xã hội', description: 'Nâng cao chất lượng giáo dục, tạo nền tảng dài hạn cho năng suất, việc làm và đời sống xã hội', cost: 80, effect: { education: 7 } },
  { id: 'health_invest', name: 'Đầu tư y tế', category: 'Xã hội', description: 'Tăng năng lực y tế, cải thiện sức khỏe cộng đồng và hỗ trợ tăng trưởng dân số dài hạn', cost: 85, effect: { healthcare: 7 } },
  { id: 'welfare', name: 'Trợ cấp xã hội', category: 'Xã hội', description: 'Hỗ trợ trực tiếp đời sống người dân, tăng hạnh phúc trong ngắn hạn nhưng không giải quyết nguyên nhân nền', cost: 55, effect: { happiness: 7 } },
  { id: 'job_program', name: 'Chương trình việc làm', category: 'Xã hội', description: 'Tạo việc làm và giảm tỷ lệ thất nghiệp, từ đó gián tiếp cải thiện kinh tế và đời sống xã hội', cost: 75, effect: { unemployment: -2 } },
  { id: 'vocational_training', name: 'Đào tạo lại lao động', category: 'Xã hội', description: 'Đào tạo lại lực lượng lao động để thích nghi với thay đổi công nghệ và nhu cầu thị trường', cost: 70, effect: { education: 3, unemployment: -1.5 } },
  { id: 'emergency_healthcare', name: 'Huy động y tế khẩn cấp', category: 'Xã hội', description: 'Tăng cường hệ thống y tế trong thời gian ngắn để đối phó khủng hoảng sức khỏe cộng đồng, nhưng làm nợ công và lạm phát tăng', cost: 120, effect: { healthcare: 6, happiness: 1, debt: 35, inflation: 0.4 } },
  { id: 'social_dialogue', name: 'Đối thoại và nhượng bộ xã hội', category: 'Xã hội', description: 'Đàm phán và nhượng bộ để hạ nhiệt bất mãn xã hội, nhưng làm giảm nguồn thu thuế trong các tháng sau', cost: 65, effect: { happiness: 5, taxRate: -1.5, debt: 15 } },

  // Công nghệ (Technology)
  { id: 'ai_national', name: 'Phát triển AI quốc gia', category: 'Công nghệ', description: 'Đầu tư quy mô lớn vào AI, tăng năng lực công nghệ quốc gia và tạo nền tảng tăng trưởng dài hạn', cost: 125, effect: { technology: 8 } },
  { id: 'cybersec', name: 'An ninh mạng quốc gia', category: 'Công nghệ', description: 'Tăng năng lực phòng thủ an ninh mạng, giảm nguy cơ bị tấn công mạng trong tương lai', cost: 70, effect: { cybersecurity: 9 } },
  { id: 'cyber_incident_response', name: 'Phản ứng sự cố mạng', category: 'Công nghệ', description: 'Khắc phục hệ thống sau tấn công mạng và tăng cường phòng thủ, nhưng làm gián đoạn một phần hoạt động công nghệ', cost: 85, effect: { cybersecurity: 7, technology: -1, debt: 20 } },
  { id: 'automation', name: 'Tự động hóa công nghiệp', category: 'Công nghệ', description: 'Tăng năng lực công nghệ và năng suất sản xuất, nhưng tạo áp lực thất nghiệp ngắn hạn', cost: 75, effect: { technology: 6, infrastructure: 0.5, unemployment: 0.8 } },
  { id: 'innovation_fund', name: 'Quỹ đổi mới sáng tạo', category: 'Công nghệ', description: 'Hỗ trợ nghiên cứu, đổi mới và đào tạo nhân lực công nghệ, tạo nền tảng phát triển dài hạn', cost: 85, effect: { technology: 5.5, education: 2 } },

  // Hạ tầng & Năng lượng (Infrastructure)
  { id: 'power_plant', name: 'Xây nhà máy điện', category: 'Hạ tầng', description: 'Tăng nhanh năng lực năng lượng quốc gia, nhưng gây áp lực lên môi trường', cost: 105, effect: { energy: 10, environment: -5 } },
  { id: 'green_energy', name: 'Đầu tư năng lượng xanh', category: 'Hạ tầng', description: 'Phát triển nguồn năng lượng sạch, vừa tăng năng lượng vừa cải thiện môi trường', cost: 150, effect: { energy: 7, environment: 9 } },
  { id: 'transit', name: 'Nâng cấp giao thông', category: 'Hạ tầng', description: 'Cải thiện chất lượng hạ tầng giao thông, hỗ trợ sản xuất, việc làm và lưu thông hàng hóa', cost: 110, effect: { infrastructure: 8 } },
  { id: 'modernize', name: 'Hiện đại hóa hạ tầng', category: 'Hạ tầng', description: 'Nâng cấp đồng bộ hạ tầng và hiệu suất năng lượng, tạo nền tảng phát triển dài hạn', cost: 125, effect: { infrastructure: 8, energy: 3 } },
  { id: 'disaster_reconstruction', name: 'Tái thiết sau thiên tai', category: 'Hạ tầng', description: 'Chi ngân sách lớn để tái thiết hạ tầng và ổn định đời sống sau thiên tai', cost: 125, effect: { infrastructure: 6, healthcare: 1, happiness: 1, debt: 35 } },

  // Môi trường (Environment)
  { id: 'emissions', name: 'Giảm phát thải', category: 'Môi trường', description: 'Siết phát thải và giảm ô nhiễm, cải thiện môi trường nhưng làm năng lực năng lượng chịu áp lực ngắn hạn', cost: 45, effect: { environment: 7, energy: -1.5 } },
  { id: 'forest', name: 'Phục hồi rừng', category: 'Môi trường', description: 'Phục hồi hệ sinh thái và tăng chất lượng môi trường, giúp giảm rủi ro khí hậu và thiên tai dài hạn', cost: 65, effect: { environment: 10 } },
  { id: 'climate_adaptation', name: 'Thích ứng khí hậu khẩn cấp', category: 'Môi trường', description: 'Triển khai các biện pháp thích ứng khí hậu để phục hồi môi trường và giảm áp lực lên y tế', cost: 105, effect: { environment: 6, healthcare: 1, energy: -1, debt: 25 } },

  // An ninh & Đối ngoại (Security & Diplomacy)
  { id: 'military', name: 'Tăng quốc phòng', category: 'An ninh', description: 'Tăng năng lực phòng thủ quốc gia, giảm rủi ro chiến tranh nhưng gây áp lực ngoại giao', cost: 110, effect: { military: 10, diplomacy: -3 } },
  { id: 'diplomacy', name: 'Ngoại giao hòa bình', category: 'An ninh', description: 'Tăng quan hệ đối ngoại, giảm rủi ro xung đột và tăng cơ hội hợp tác thương mại', cost: 55, effect: { diplomacy: 7 } },
  { id: 'stability_op', name: 'Duy trì trật tự xã hội', category: 'An ninh', description: 'Ổn định tình hình xã hội trong ngắn hạn, giúp giảm bất mãn nhưng không giải quyết nguyên nhân nền', cost: 45, effect: { happiness: 4 } },
  { id: 'ceasefire_negotiation', name: 'Đàm phán ngừng bắn', category: 'An ninh', description: 'Hạ nhiệt xung đột bằng ngoại giao, cải thiện quan hệ quốc tế nhưng phải nhượng bộ một phần năng lực quân sự', cost: 120, effect: { diplomacy: 7, military: -4, debt: 25 } },
  { id: 'defense_mobilization', name: 'Huy động quốc phòng', category: 'An ninh', description: 'Tăng nhanh năng lực quân sự trong thời gian ngắn, nhưng gây áp lực lớn lên ngân sách, ngoại giao và lạm phát', cost: 170, effect: { military: 10, diplomacy: -6, inflation: 1.2, debt: 45 } },
  { id: 'foreign_resource_deal', name: 'Giao thiệp tài nguyên với nước ngoài', category: 'An ninh', description: 'Đàm phán nhập khẩu tài nguyên và năng lượng từ nước ngoài để giảm áp lực thiếu hụt, nhưng làm tăng nợ công', cost: 120, effect: { energy: 6, diplomacy: 2, inflation: -0.8, debt: 45 } },
];

export const EVENTS: GameEvent[] = [
  { id: 'pandemic', name: 'Đại dịch', description: 'Bùng phát dịch bệnh nghiêm trọng', probability: 0.018, effect: { healthcare: -18, happiness: -8, population: -10000, unemployment: 1.5, budget: -50 } },
  { id: 'war', name: 'Chiến tranh khu vực', description: 'Xung đột ở quốc gia lân cận làm thương mại và an ninh chịu áp lực', probability: 0.018, effect: { diplomacy: -12, inflation: 3.8, military: -6, budget: -50 } },
  { id: 'oil_crisis', name: 'Khủng hoảng dầu mỏ', description: 'Giá năng lượng tăng vọt và nguồn cung bị thắt chặt', probability: 0.022, effect: { energy: -12, inflation: 4, diplomacy: -3 } },
  { id: 'disaster', name: 'Thiên tai lớn', description: 'Bão lụt tàn phá hạ tầng và gây thiệt hại dân cư', probability: 0.03, effect: { infrastructure: -13, environment: -6, budget: -60, population: -7000, healthcare: -3 } },
  { id: 'cyberattack', name: 'Tấn công mạng', description: 'Hệ thống hạ tầng số bị tấn công và phải chi phí khắc phục', probability: 0.026, effect: { cybersecurity: -16, budget: -45, happiness: -3, technology: -1.5 } },
  { id: 'recession', name: 'Suy thoái kinh tế', description: 'Cầu tiêu dùng và đầu tư suy yếu, thất nghiệp tăng và ngân sách hụt thu', probability: 0.022, effect: { unemployment: 5, budget: -80, happiness: -4, inflation: -0.8 } },
  { id: 'protest', name: 'Biểu tình xã hội', description: 'Bất mãn từ người dân lan rộng, gây áp lực lên ngân sách và trật tự xã hội', probability: 0.04, effect: { happiness: -11, budget: -35 } },
  { id: 'climate', name: 'Khủng hoảng khí hậu', description: 'Tác động từ biến đổi khí hậu làm môi trường và sức khỏe cộng đồng suy yếu', probability: 0.025, effect: { environment: -13, healthcare: -4, energy: -2 } },
  { id: 'supply_chain', name: 'Đứt gãy chuỗi cung', description: 'Gián đoạn sản xuất và logistics toàn cầu làm giá cả tăng', probability: 0.032, effect: { inflation: 3.2, infrastructure: -6, unemployment: 1.8, energy: -3 } },
  { id: 'boom', name: 'Bùng nổ kinh tế', description: 'Nhu cầu thị trường tăng mạnh, việc làm và ngân sách cải thiện nhưng có áp lực giá nhẹ', probability: 0.02, effect: { unemployment: -1.5, budget: 70, inflation: 0.6 } },
  { id: 'tech_breakthrough', name: 'Đột phá công nghệ', description: 'Phát minh công nghệ mới nâng năng lực sản xuất và tri thức quốc gia', probability: 0.02, effect: { technology: 12, education: 1.5, cybersecurity: 1 } },
  { id: 'trade_pact', name: 'Hiệp định thương mại', description: 'Ký kết hiệp định FTA lớn giúp cải thiện quan hệ và giảm áp lực chuỗi cung', probability: 0.024, effect: { diplomacy: 10, infrastructure: 2, inflation: -0.8, unemployment: -0.8 } },
];

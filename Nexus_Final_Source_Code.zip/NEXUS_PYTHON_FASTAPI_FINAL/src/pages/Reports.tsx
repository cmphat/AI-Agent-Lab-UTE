import { useMemo } from 'react';
import { useGame } from '../core/GameProvider';
import { useLanguage } from '../core/LanguageProvider';
import { assessNationHealth, evaluateState } from '../core/state';
import { Download, ClipboardCopy, CalendarRange, AlertOctagon, Clock3, ChevronDown } from 'lucide-react';
import { cn } from '../components/layout/Layout';

export const Reports = () => {
  const { simulationRuns, state } = useGame();
  const { language, t, eventName, metricName, locale } = useLanguage();

  const formatDate = (month: number, year: number) =>
    `${language === 'vi' ? 'T' : 'M'}${month.toString().padStart(2, '0')}/${year}`;

  const formatPopulation = (value: number) => new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(value);

  const formatReason = (reason: string) =>
    reason === 'system'
      ? (language === 'vi' ? 'Chỉ số vận hành tổng thể xuống mức 0–15%' : 'Overall national health fell to 0–15%')
      : metricName(reason);

  const totalMonths = useMemo(
    () => simulationRuns.reduce((sum, run) => sum + run.completedMonths, 0),
    [simulationRuns],
  );
  const collapsedRuns = useMemo(
    () => simulationRuns.filter((run) => run.status === 'collapsed').length,
    [simulationRuns],
  );

  const reportData = useMemo(() => {
    const activeCrises = state.active_events.length > 0
      ? state.active_events.map(eventName).join(', ')
      : t('reports.none');
    const health = assessNationHealth(state);

    const runSections = simulationRuns.length === 0
      ? t('reports.noRuns')
      : simulationRuns.map((run) => {
        const startScore = evaluateState(run.startState);
        const endScore = evaluateState(run.endState);
        const eventSet = [...new Set(run.snapshots.flatMap((snapshot) => snapshot.active_events))];
        const statusText = run.status === 'collapsed' ? t('layout.collapsed') : t('layout.completed');
        const collapseText = run.collapseReasons.length > 0
          ? `\n- **${t('reports.collapseReasons')}:** ${run.collapseReasons.map(formatReason).join(', ')}`
          : '';
        const rows = run.snapshots.map((snapshot, index) => {
          const events = snapshot.active_events.length > 0
            ? snapshot.active_events.map(eventName).join(', ')
            : t('reports.noEvents');
          return `| ${index + 1} | ${formatDate(snapshot.month, snapshot.year)} | ${snapshot.gdp.toFixed(1)} | ${snapshot.budget.toFixed(1)} | ${snapshot.debt.toFixed(1)} | ${snapshot.taxRate.toFixed(1)}% | ${snapshot.inflation.toFixed(1)}% | ${snapshot.unemployment.toFixed(1)}% | ${snapshot.happiness.toFixed(1)} | ${formatPopulation(snapshot.population)} | ${evaluateState(snapshot).toFixed(1)} | ${events} |`;
        }).join('\n');

        return `### ${t('layout.runLabel')} #${run.sequence}: ${formatDate(run.startState.month, run.startState.year)} → ${formatDate(run.endState.month, run.endState.year)}

- **${t('reports.requested')}:** ${run.requestedMonths} ${t('layout.months')}
- **${t('reports.completed')}:** ${run.completedMonths} ${t('layout.months')}
- **${t('reports.status')}:** ${statusText}
- **${t('reports.scoreStart')}:** ${startScore.toFixed(1)}
- **${t('reports.scoreEnd')}:** ${endScore.toFixed(1)}
- **${t('reports.events')}:** ${eventSet.length > 0 ? eventSet.map(eventName).join(', ') : t('reports.noEvents')}${collapseText}

#### ${t('reports.runDetails')}

| # | ${t('layout.month')} | GDP (B) | ${metricName('budget')} (B) | ${metricName('debt')} (B) | ${metricName('taxRate')} | ${metricName('inflation')} | ${metricName('unemployment')} | ${metricName('happiness')} | ${metricName('population')} | ${t('reports.score')} | ${t('reports.events')} |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
${rows || `| - | ${formatDate(run.endState.month, run.endState.year)} | ${run.endState.gdp.toFixed(1)} | ${run.endState.budget.toFixed(1)} | ${run.endState.debt.toFixed(1)} | ${run.endState.taxRate.toFixed(1)}% | ${run.endState.inflation.toFixed(1)}% | ${run.endState.unemployment.toFixed(1)}% | ${run.endState.happiness.toFixed(1)} | ${formatPopulation(run.endState.population)} | ${endScore.toFixed(1)} | ${t('reports.noEvents')} |`}`;
      }).join('\n\n---\n\n');

    return `# ${t('reports.reportTitle')} — ${t('reports.month')} ${state.month}, ${t('reports.year')} ${state.year}

## ${t('reports.executiveSummary')}
- **${t('reports.currentScore')}:** ${evaluateState(state).toFixed(1)}
- **${t('layout.systemHealth')}:** ${t(`layout.health.${health.level}`)} (${Math.round(health.score)}%)
- **${t('reports.activeCrises')}:** ${activeCrises}
- **${t('reports.totalRuns')}:** ${simulationRuns.length}
- **${t('reports.totalMonths')}:** ${totalMonths}
- **${t('reports.collapsedRuns')}:** ${collapsedRuns}

## ${t('reports.keyMetrics')}
- **${metricName('gdp')}:** $${state.gdp.toFixed(1)}B
- **${metricName('budget')}:** $${state.budget.toFixed(1)}B
- **${metricName('debt')}:** $${state.debt.toFixed(1)}B
- **${metricName('taxRate')}:** ${state.taxRate.toFixed(1)}%
- **${metricName('inflation')}:** ${state.inflation.toFixed(1)}%
- **${metricName('unemployment')}:** ${state.unemployment.toFixed(1)}%
- **${metricName('population')}:** ${formatPopulation(state.population)}

## ${t('reports.societal')}
- ${metricName('happiness')}: ${state.happiness.toFixed(1)} / 100
- ${metricName('education')}: ${state.education.toFixed(1)} / 100
- ${metricName('healthcare')}: ${state.healthcare.toFixed(1)} / 100
- ${metricName('infrastructure')}: ${state.infrastructure.toFixed(1)} / 100

## ${t('reports.capabilities')}
- ${metricName('military')}: ${state.military.toFixed(1)} / 100
- ${metricName('technology')}: ${state.technology.toFixed(1)} / 100
- ${metricName('cybersecurity')}: ${state.cybersecurity.toFixed(1)} / 100
- ${metricName('diplomacy')}: ${state.diplomacy.toFixed(1)} / 100
- ${metricName('energy')}: ${state.energy.toFixed(1)} / 100
- ${metricName('environment')}: ${state.environment.toFixed(1)} / 100

## ${t('reports.history')}

${runSections}`;
  }, [collapsedRuns, eventName, formatPopulation, formatReason, metricName, simulationRuns, state, t, totalMonths]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(reportData);
    window.alert(t('reports.copied'));
  };

  const handleDownload = () => {
    const blob = new Blob([reportData], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = language === 'vi'
      ? `bao_cao_day_du_${state.year}_${state.month.toString().padStart(2, '0')}.md`
      : `complete_simulation_report_${state.year}_${state.month.toString().padStart(2, '0')}.md`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-in fade-in duration-500">
      <div className="flex justify-between items-start border-b border-border pb-4 mb-6 gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight uppercase">{t('reports.title')}</h2>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">{t('reports.subtitle')}</p>
        </div>

        <div className="flex gap-3">
          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-2 bg-foreground/10 text-foreground px-4 py-2 rounded text-xs font-bold hover:bg-foreground/20 transition-colors uppercase tracking-wider"
          >
            <ClipboardCopy size={16} /> {t('reports.copy')}
          </button>
          <button
            type="button"
            onClick={handleDownload}
            className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded text-xs font-bold hover:opacity-90 transition-opacity whitespace-nowrap shadow-lg shadow-primary/20 uppercase tracking-wider"
          >
            <Download size={16} /> {t('reports.export')}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded border border-border bg-card p-4 flex items-center gap-3">
          <CalendarRange className="text-primary" size={22} />
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('reports.totalRuns')}</p>
            <p className="font-mono text-2xl font-bold">{simulationRuns.length.toLocaleString(locale)}</p>
          </div>
        </div>
        <div className="rounded border border-border bg-card p-4 flex items-center gap-3">
          <Clock3 className="text-primary" size={22} />
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('reports.totalMonths')}</p>
            <p className="font-mono text-2xl font-bold">{totalMonths.toLocaleString(locale)}</p>
          </div>
        </div>
        <div className="rounded border border-border bg-card p-4 flex items-center gap-3">
          <AlertOctagon className={collapsedRuns > 0 ? 'text-rose-500' : 'text-muted-foreground'} size={22} />
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('reports.collapsedRuns')}</p>
            <p className={cn('font-mono text-2xl font-bold', collapsedRuns > 0 && 'text-rose-500')}>{collapsedRuns.toLocaleString(locale)}</p>
          </div>
        </div>
      </div>

      <section className="space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-widest">{t('reports.runSummary')}</h3>
        {simulationRuns.length === 0 ? (
          <div className="rounded border border-border bg-card p-6 text-sm text-muted-foreground">{t('reports.noRuns')}</div>
        ) : (
          <div className="space-y-3">
            {simulationRuns.map((run) => {
              const startScore = evaluateState(run.startState);
              const endScore = evaluateState(run.endState);
              const delta = endScore - startScore;
              const eventIds = [...new Set(run.snapshots.flatMap((snapshot) => snapshot.active_events))];

              return (
                <details key={run.id} className="group rounded border border-border bg-card overflow-hidden" open={run.sequence === simulationRuns.length}>
                  <summary className="cursor-pointer list-none p-4 flex flex-wrap items-center justify-between gap-4 hover:bg-muted/40">
                    <div className="flex items-center gap-3">
                      <ChevronDown size={17} className="text-muted-foreground transition-transform group-open:rotate-180" />
                      <div>
                        <p className="font-bold">{t('layout.runLabel')} #{run.sequence}</p>
                        <p className="text-xs text-muted-foreground font-mono">
                          {formatDate(run.startState.month, run.startState.year)} → {formatDate(run.endState.month, run.endState.year)}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-5 text-xs">
                      <div><span className="text-muted-foreground">{t('reports.requested')}:</span> <strong>{run.requestedMonths}</strong></div>
                      <div><span className="text-muted-foreground">{t('reports.completed')}:</span> <strong>{run.completedMonths}</strong></div>
                      <div className={delta >= 0 ? 'text-emerald-500' : 'text-rose-500'}>{delta >= 0 ? '+' : ''}{delta.toFixed(1)}</div>
                      <span className={cn(
                        'rounded border px-2 py-1 font-bold uppercase tracking-wider',
                        run.status === 'collapsed'
                          ? 'border-rose-500/30 bg-rose-500/10 text-rose-500'
                          : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-500',
                      )}>
                        {run.status === 'collapsed' ? t('layout.collapsed') : t('layout.completed')}
                      </span>
                    </div>
                  </summary>

                  <div className="border-t border-border p-4 space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                      <div className="rounded border border-border bg-background p-3"><span className="text-xs text-muted-foreground">{t('reports.scoreStart')}</span><p className="font-mono font-bold">{startScore.toFixed(1)}</p></div>
                      <div className="rounded border border-border bg-background p-3"><span className="text-xs text-muted-foreground">{t('reports.scoreEnd')}</span><p className="font-mono font-bold">{endScore.toFixed(1)}</p></div>
                      <div className="rounded border border-border bg-background p-3 md:col-span-2"><span className="text-xs text-muted-foreground">{t('reports.events')}</span><p className="font-medium">{eventIds.length > 0 ? eventIds.map(eventName).join(', ') : t('reports.noEvents')}</p></div>
                    </div>

                    {run.collapseReasons.length > 0 && (
                      <div className="rounded border border-rose-500/30 bg-rose-500/5 p-3 text-sm text-rose-500">
                        <strong>{t('reports.collapseReasons')}:</strong> {run.collapseReasons.map(formatReason).join(', ')}
                      </div>
                    )}

                    <div className="max-h-[420px] overflow-auto rounded border border-border">
                      <table className="w-full min-w-[1280px] text-xs">
                        <thead className="sticky top-0 bg-muted uppercase tracking-wider text-muted-foreground">
                          <tr>
                            <th className="px-3 py-2 text-left">#</th>
                            <th className="px-3 py-2 text-left">{t('layout.month')}</th>
                            <th className="px-3 py-2 text-right">GDP</th>
                            <th className="px-3 py-2 text-right">{metricName('budget')}</th>
                            <th className="px-3 py-2 text-right">{metricName('debt')}</th>
                            <th className="px-3 py-2 text-right">{metricName('taxRate')}</th>
                            <th className="px-3 py-2 text-right">{metricName('inflation')}</th>
                            <th className="px-3 py-2 text-right">{metricName('unemployment')}</th>
                            <th className="px-3 py-2 text-right">{metricName('happiness')}</th>
                            <th className="px-3 py-2 text-right">{metricName('population')}</th>
                            <th className="px-3 py-2 text-right">{t('reports.score')}</th>
                            <th className="px-3 py-2 text-left">{t('reports.events')}</th>
                          </tr>
                        </thead>
                        <tbody>
                          {run.snapshots.map((snapshot, index) => (
                            <tr key={`${run.id}-${snapshot.year}-${snapshot.month}-${index}`} className="border-t border-border hover:bg-muted/20">
                              <td className="px-3 py-2 font-mono">{index + 1}</td>
                              <td className="px-3 py-2 font-mono">{formatDate(snapshot.month, snapshot.year)}</td>
                              <td className="px-3 py-2 text-right font-mono">{snapshot.gdp.toFixed(1)}</td>
                              <td className="px-3 py-2 text-right font-mono">{snapshot.budget.toFixed(1)}</td>
                              <td className="px-3 py-2 text-right font-mono">{snapshot.debt.toFixed(1)}</td>
                              <td className="px-3 py-2 text-right font-mono">{snapshot.taxRate.toFixed(1)}%</td>
                              <td className="px-3 py-2 text-right font-mono">{snapshot.inflation.toFixed(1)}%</td>
                              <td className="px-3 py-2 text-right font-mono">{snapshot.unemployment.toFixed(1)}%</td>
                              <td className="px-3 py-2 text-right font-mono">{snapshot.happiness.toFixed(1)}</td>
                              <td className="px-3 py-2 text-right font-mono">{formatPopulation(snapshot.population)}</td>
                              <td className="px-3 py-2 text-right font-mono">{evaluateState(snapshot).toFixed(1)}</td>
                              <td className="px-3 py-2">{snapshot.active_events.length > 0 ? snapshot.active_events.map(eventName).join(', ') : t('reports.noEvents')}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </details>
              );
            })}
          </div>
        )}
      </section>

      <details className="rounded border border-border bg-card overflow-hidden">
        <summary className="cursor-pointer list-none p-4 flex items-center gap-2 font-bold uppercase tracking-wider text-sm hover:bg-muted/40">
          <ChevronDown size={17} className="transition-transform group-open:rotate-180" />
          {t('reports.fullMarkdown')}
        </summary>
        <div className="border-t border-border p-6 max-h-[700px] overflow-auto">
          <pre className="whitespace-pre-wrap font-mono text-sm text-foreground/80 font-medium">{reportData}</pre>
        </div>
      </details>
    </div>
  );
};

import { Activity, AlertTriangle, CheckCircle2, ShieldAlert, Target } from 'lucide-react';
import { useGame } from '../core/GameProvider';
import { useLanguage } from '../core/LanguageProvider';
import { SCENARIO_PRESETS, ScenarioSeverity } from '../core/scenarios';
import { assessNationHealth } from '../core/state';

const severityClasses: Record<ScenarioSeverity, string> = {
  stable: 'border-emerald-500/30 hover:border-emerald-500 text-emerald-400 bg-emerald-500/10',
  warning: 'border-yellow-500/30 hover:border-yellow-500 text-yellow-400 bg-yellow-500/10',
  crisis: 'border-orange-500/30 hover:border-orange-500 text-orange-400 bg-orange-500/10',
  critical: 'border-red-500/30 hover:border-red-500 text-red-400 bg-red-500/10',
};

const severityIcon: Record<ScenarioSeverity, typeof CheckCircle2> = {
  stable: CheckCircle2,
  warning: AlertTriangle,
  crisis: ShieldAlert,
  critical: ShieldAlert,
};

export const Scenarios = () => {
  const { loadScenarioState } = useGame();
  const { t, language, locale, policyName, eventName } = useLanguage();

  const formatNumber = (value: number, maximumFractionDigits = 0) =>
    new Intl.NumberFormat(locale, { maximumFractionDigits }).format(value);

  const formatMoney = (value: number) => `$${formatNumber(value, 1)}B`;
  const formatPercent = (value: number, maximumFractionDigits = 1) => `${formatNumber(value, maximumFractionDigits)}%`;

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-in fade-in duration-500">
      <div className="border-b border-border pb-4 mb-6">
        <h2 className="text-xl font-bold tracking-tight uppercase">{t('scenarios.title')}</h2>
        <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">{t('scenarios.subtitle')}</p>
      </div>

      <div className="bg-card border border-border rounded-lg p-4 flex flex-col md:flex-row gap-3 md:items-center justify-between">
        <div>
          <p className="text-sm font-bold flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            {t('scenarios.reworkedTitle')}
          </p>
          <p className="text-xs text-muted-foreground mt-1 max-w-4xl">{t('scenarios.reworkedHint')}</p>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center text-[10px] uppercase tracking-widest text-muted-foreground">
          <span className="bg-background border border-border rounded px-3 py-2">{t('scenarios.metricPreview')}</span>
          <span className="bg-background border border-border rounded px-3 py-2">{t('scenarios.activeEventPreview')}</span>
          <span className="bg-background border border-border rounded px-3 py-2">{t('scenarios.aiTestPreview')}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {SCENARIO_PRESETS.map((scenario) => {
          const health = assessNationHealth(scenario.state);
          const debtRatio = (scenario.state.debt / Math.max(1, scenario.state.gdp)) * 100;
          const SeverityIcon = severityIcon[scenario.severity];
          const classNames = severityClasses[scenario.severity];
          const activeEvents = scenario.state.active_events.length > 0
            ? scenario.state.active_events.map((eventId) => eventName(eventId)).join(', ')
            : t('layout.noEvents');

          const metrics = [
            { label: t('reports.budget'), value: formatMoney(scenario.state.budget) },
            { label: t('metric.debt'), value: formatMoney(scenario.state.debt) },
            { label: t('scenarios.debtRatio'), value: formatPercent(debtRatio, 1) },
            { label: t('metric.inflation'), value: formatPercent(scenario.state.inflation, 1) },
            { label: t('metric.unemployment'), value: formatPercent(scenario.state.unemployment, 1) },
            { label: t('metric.happiness'), value: formatPercent(scenario.state.happiness, 0) },
          ];

          return (
            <div
              key={scenario.id}
              className={`bg-card border p-5 rounded-lg flex flex-col gap-4 transition-colors ${classNames.split(' ').slice(0, 2).join(' ')}`}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className={`inline-flex items-center gap-2 px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-widest ${classNames.split(' ').slice(2).join(' ')}`}>
                    <SeverityIcon className="w-3.5 h-3.5" />
                    {t(`layout.health.${health.level}`)} · {formatPercent(health.score, 0)}
                  </div>
                  <h3 className="font-bold text-lg mt-3">{scenario.title[language]}</h3>
                </div>
                <button
                  type="button"
                  onClick={() => loadScenarioState(scenario.state)}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2 rounded font-semibold text-sm transition-all whitespace-nowrap"
                >
                  {t('scenarios.load')}
                </button>
              </div>

              <p className="text-sm text-foreground/75 leading-relaxed">{scenario.description[language]}</p>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {metrics.map((metric) => (
                  <div key={metric.label} className="bg-background border border-border rounded p-3">
                    <p className="text-[9px] text-muted-foreground uppercase tracking-widest">{metric.label}</p>
                    <p className="font-mono font-bold mt-1">{metric.value}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-background border border-border rounded p-3">
                  <p className="text-[9px] text-muted-foreground uppercase tracking-widest flex items-center gap-1.5">
                    <Activity className="w-3 h-3" />
                    {t('layout.events')}
                  </p>
                  <p className="text-xs mt-2 leading-relaxed">{activeEvents}</p>
                </div>
                <div className="bg-background border border-border rounded p-3">
                  <p className="text-[9px] text-muted-foreground uppercase tracking-widest flex items-center gap-1.5">
                    <Target className="w-3 h-3" />
                    {t('scenarios.objective')}
                  </p>
                  <p className="text-xs mt-2 leading-relaxed">{scenario.objective[language]}</p>
                </div>
              </div>

              <div className="bg-background/70 border border-border rounded p-3">
                <p className="text-[9px] text-muted-foreground uppercase tracking-widest mb-2">{t('scenarios.focusPolicies')}</p>
                <div className="flex flex-wrap gap-2">
                  {scenario.focusPolicyIds.map((policyId) => (
                    <span key={policyId} className="text-[11px] px-2 py-1 rounded bg-primary/10 text-primary border border-primary/20">
                      {policyName(policyId)}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

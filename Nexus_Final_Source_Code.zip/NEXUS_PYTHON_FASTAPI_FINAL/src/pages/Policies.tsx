import { useMemo, useState } from 'react';
import { useGame } from '../core/GameProvider';
import { useLanguage } from '../core/LanguageProvider';
import { POLICIES } from '../core/data';
import { Search, CheckCircle2 } from 'lucide-react';
import { cn } from '../components/layout/Layout';

export const Policies = () => {
  const { state, applyPolicy } = useGame();
  const { t, policyName, policyDescription, categoryName, metricName } = useLanguage();
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState<string>('all');

  const categories = useMemo(
    () => ['all', ...Array.from(new Set(POLICIES.map((policy) => policy.category)))],
    [],
  );

  const filtered = POLICIES.filter((policy) => {
    const localizedName = policyName(policy.id).toLowerCase();
    const localizedDescription = policyDescription(policy.id).toLowerCase();
    const normalizedSearch = search.trim().toLowerCase();
    const matchSearch =
      normalizedSearch.length === 0 ||
      localizedName.includes(normalizedSearch) ||
      localizedDescription.includes(normalizedSearch);
    const matchCategory = filterCat === 'all' || policy.category === filterCat;
    return matchSearch && matchCategory;
  });

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-in fade-in duration-500">
      <div className="border-b border-border pb-4 mb-6">
        <h2 className="text-xl font-bold tracking-tight uppercase">{t('policies.title')}</h2>
        <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">{t('policies.subtitle')}</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
          <input
            type="text"
            placeholder={t('policies.search')}
            className="w-full bg-card border border-border rounded pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>

        <div className="flex gap-2 w-full sm:w-auto overflow-x-auto pb-2 sm:pb-0 hide-scrollbar">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => setFilterCat(category)}
              className={cn(
                'px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors',
                filterCat === category
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-card border border-border text-foreground hover:bg-foreground/5',
              )}
            >
              {category === 'all' ? t('policies.all') : categoryName(category)}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((policy) => {
          const canAfford = state.budget >= policy.cost;
          return (
            <div
              key={policy.id}
              className="bg-card border border-border p-5 rounded flex flex-col gap-3 transition-colors duration-200 group hover:border-primary/50"
            >
              <div className="flex justify-between items-start gap-3">
                <div>
                  <h3 className="font-semibold">{policyName(policy.id)}</h3>
                  <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">
                    {categoryName(policy.category)}
                  </span>
                </div>
                <div className="bg-background border border-border px-2 py-1 rounded text-sm font-mono whitespace-nowrap">
                  ${policy.cost.toFixed(1)}B
                </div>
              </div>

              <p className="text-sm text-foreground/80 flex-1">{policyDescription(policy.id)}</p>

              <div className="bg-background p-3 rounded border border-border/50 text-xs flex flex-col gap-1.5 font-mono">
                {Object.entries(policy.effect).map(([metric, value]) => (
                  <div key={metric} className="flex justify-between items-center gap-3">
                    <span>{metricName(metric)}</span>
                    <span className={cn((value as number) > 0 ? 'text-green-500' : 'text-red-500', 'font-semibold')}>
                      {(value as number) > 0 ? '+' : ''}
                      {value as number}
                    </span>
                  </div>
                ))}
              </div>

              <button
                type="button"
                disabled={!canAfford}
                onClick={() => applyPolicy(policy)}
                className={cn(
                  'mt-2 w-full flex items-center justify-center gap-2 py-2 rounded font-medium transition-all',
                  canAfford
                    ? 'bg-primary text-primary-foreground hover:opacity-90'
                    : 'bg-muted text-muted-foreground cursor-not-allowed opacity-50',
                )}
              >
                {canAfford ? (
                  <>
                    <CheckCircle2 size={16} />
                    {t('policies.enact')}
                  </>
                ) : (
                  t('policies.insufficient')
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

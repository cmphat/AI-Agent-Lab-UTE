import { useGame } from '../core/GameProvider';
import { useLanguage } from '../core/LanguageProvider';
import { Moon, Sun, AlertTriangle, Languages, BrainCircuit, RotateCcw } from 'lucide-react';
import { cn } from '../components/layout/Layout';
import { AIAdvancedSettings, ConstraintStrictness, LrtaMemoryMode } from '../core/aiSettings';

const numberControls: Array<{
  key: keyof Pick<AIAdvancedSettings,
    'uninformedMonths' |
    'costHeuristicMonths' |
    'localSearchSteps' |
    'beamWidth' |
    'annealingIterations' |
    'andOrMonths' |
    'beliefMonths' |
    'lrtaLearningMonths' |
    'cspMonths' |
    'adversarialMonths' |
    'chanceMonths' |
    'maxMinActions'
  >;
  labelKey: string;
  hintKey: string;
  min: number;
  max: number;
  step?: number;
}> = [
  { key: 'uninformedMonths', labelKey: 'settings.aiUninformedMonths', hintKey: 'settings.aiUninformedMonthsHint', min: 1, max: 5 },
  { key: 'costHeuristicMonths', labelKey: 'settings.aiCostHeuristicMonths', hintKey: 'settings.aiCostHeuristicMonthsHint', min: 1, max: 5 },
  { key: 'localSearchSteps', labelKey: 'settings.aiLocalSearchSteps', hintKey: 'settings.aiLocalSearchStepsHint', min: 1, max: 8 },
  { key: 'beamWidth', labelKey: 'settings.aiBeamWidth', hintKey: 'settings.aiBeamWidthHint', min: 2, max: 8 },
  { key: 'annealingIterations', labelKey: 'settings.aiAnnealingIterations', hintKey: 'settings.aiAnnealingIterationsHint', min: 100, max: 1200, step: 20 },
  { key: 'andOrMonths', labelKey: 'settings.aiAndOrMonths', hintKey: 'settings.aiAndOrMonthsHint', min: 1, max: 3 },
  { key: 'beliefMonths', labelKey: 'settings.aiBeliefMonths', hintKey: 'settings.aiBeliefMonthsHint', min: 1, max: 4 },
  { key: 'lrtaLearningMonths', labelKey: 'settings.aiLrtaLearningMonths', hintKey: 'settings.aiLrtaLearningMonthsHint', min: 1, max: 8 },
  { key: 'cspMonths', labelKey: 'settings.aiCspMonths', hintKey: 'settings.aiCspMonthsHint', min: 1, max: 5 },
  { key: 'adversarialMonths', labelKey: 'settings.aiAdversarialMonths', hintKey: 'settings.aiAdversarialMonthsHint', min: 1, max: 3 },
  { key: 'chanceMonths', labelKey: 'settings.aiChanceMonths', hintKey: 'settings.aiChanceMonthsHint', min: 1, max: 3 },
  { key: 'maxMinActions', labelKey: 'settings.aiMaxMinActions', hintKey: 'settings.aiMaxMinActionsHint', min: 2, max: 6 },
];

export const Settings = () => {
  const { theme, toggleTheme, reset, aiSettings, updateAISetting, resetAISettings } = useGame();
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-in fade-in duration-500">
      <div className="border-b border-border pb-4 mb-6">
        <h2 className="text-xl font-bold tracking-tight uppercase">{t('settings.title')}</h2>
        <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">{t('settings.subtitle')}</p>
      </div>

      <div className="space-y-6">
        <div className="bg-card border border-border p-6 rounded space-y-5">
          <h3 className="font-semibold border-b border-border pb-2">{t('settings.appearance')}</h3>

          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="font-medium">{t('settings.themePreference')}</div>
              <div className="text-sm text-muted-foreground">{t('settings.themeDescription')}</div>
            </div>
            <button
              type="button"
              onClick={toggleTheme}
              className="flex items-center gap-2 px-4 py-2 bg-foreground/10 hover:bg-foreground/20 rounded text-sm font-medium transition-colors whitespace-nowrap"
            >
              {theme === 'dark' ? (
                <><Sun size={16} /> {t('settings.useLight')}</>
              ) : (
                <><Moon size={16} /> {t('settings.useDark')}</>
              )}
            </button>
          </div>

          <div className="border-t border-border pt-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="font-medium flex items-center gap-2"><Languages size={16} /> {t('settings.languagePreference')}</div>
              <div className="text-sm text-muted-foreground">{t('settings.languageDescription')}</div>
            </div>
            <div className="inline-flex border border-border rounded overflow-hidden bg-background self-start sm:self-auto">
              <button
                type="button"
                onClick={() => setLanguage('vi')}
                className={cn(
                  'px-4 py-2 text-sm font-medium transition-colors',
                  language === 'vi' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted text-muted-foreground',
                )}
              >
                {t('settings.vietnamese')}
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={cn(
                  'px-4 py-2 text-sm font-medium transition-colors border-l border-border',
                  language === 'en' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted text-muted-foreground',
                )}
              >
                {t('settings.english')}
              </button>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border p-6 rounded space-y-5">
          <div className="border-b border-border pb-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h3 className="font-semibold flex items-center gap-2"><BrainCircuit size={17} /> {t('settings.aiAdvanced')}</h3>
              <p className="text-sm text-muted-foreground mt-1">{t('settings.aiAdvancedDescription')}</p>
            </div>
            <button
              type="button"
              onClick={resetAISettings}
              className="self-start sm:self-auto flex items-center gap-2 px-3 py-2 border border-border bg-background hover:bg-foreground/5 rounded text-sm font-medium transition-colors"
            >
              <RotateCcw size={15} /> {t('settings.aiReset')}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {numberControls.map((control) => (
              <div key={control.key} className="border border-border bg-background rounded p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium">{t(control.labelKey)}</div>
                    <div className="text-xs text-muted-foreground leading-relaxed mt-1">{t(control.hintKey)}</div>
                  </div>
                  <span className="text-xs font-mono bg-card border border-border px-2 py-1 rounded">{aiSettings[control.key]}</span>
                </div>
                <input
                  type="range"
                  min={control.min}
                  max={control.max}
                  step={control.step ?? 1}
                  value={aiSettings[control.key] as number}
                  onChange={(event) => updateAISetting(control.key, Number(event.target.value))}
                  className="w-full accent-primary"
                />
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-border bg-background rounded p-4 space-y-2">
              <label className="text-sm font-medium">{t('settings.aiConstraintStrictness')}</label>
              <select
                value={aiSettings.constraintStrictness}
                onChange={(event) => updateAISetting('constraintStrictness', event.target.value as ConstraintStrictness)}
                className="w-full bg-card border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              >
                <option value="relaxed">{t('settings.aiStrictnessRelaxed')}</option>
                <option value="balanced">{t('settings.aiStrictnessBalanced')}</option>
                <option value="strict">{t('settings.aiStrictnessStrict')}</option>
              </select>
              <p className="text-xs text-muted-foreground leading-relaxed">{t('settings.aiConstraintStrictnessHint')}</p>
            </div>

            <div className="border border-border bg-background rounded p-4 space-y-2">
              <label className="text-sm font-medium">{t('settings.aiLrtaMemoryMode')}</label>
              <select
                value={aiSettings.lrtaMemoryMode}
                onChange={(event) => updateAISetting('lrtaMemoryMode', event.target.value as LrtaMemoryMode)}
                className="w-full bg-card border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              >
                <option value="temporary">{t('settings.aiMemoryTemporary')}</option>
                <option value="persistent">{t('settings.aiMemoryPersistent')}</option>
              </select>
              <p className="text-xs text-muted-foreground leading-relaxed">{t('settings.aiLrtaMemoryModeHint')}</p>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border p-6 rounded space-y-4">
          <h3 className="font-semibold text-red-500 border-b border-border pb-2">{t('settings.dangerZone')}</h3>

          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="font-medium">{t('settings.reset')}</div>
              <div className="text-sm text-muted-foreground">{t('settings.resetDescription')}</div>
            </div>
            <button
              type="button"
              onClick={() => {
                if (window.confirm(t('settings.resetConfirm'))) reset();
              }}
              className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded text-sm font-medium transition-colors whitespace-nowrap"
            >
              <AlertTriangle size={16} /> {t('settings.resetButton')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

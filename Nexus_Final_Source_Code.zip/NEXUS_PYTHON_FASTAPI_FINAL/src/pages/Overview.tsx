import { useGame } from '../core/GameProvider';
import { useLanguage } from '../core/LanguageProvider';
import { assessNationHealth, evaluateState } from '../core/state';
import { POLICIES } from '../core/data';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Landmark,
  Users,
  Building2,
  ShieldCheck,
  type LucideIcon,
} from 'lucide-react';
import { cn } from '../components/layout/Layout';

const clampNumber = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const average = (values: number[]) => values.reduce((sum, value) => sum + value, 0) / Math.max(1, values.length);
const formatDisplayNumber = (value: number, digits = 1) => {
  const rounded = Number(value.toFixed(digits));
  return Number.isInteger(rounded) ? rounded.toFixed(0) : rounded.toFixed(digits);
};


const SmallMetricTile = ({
  label,
  value,
  trend,
}: {
  label: string;
  value: string;
  trend?: number;
}) => (
  <div className="bg-background/35 border border-border rounded p-3 min-w-0 transition-colors duration-200">
    <div className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider truncate">{label}</div>
    <div className="flex items-baseline gap-2 mt-1">
      <span className="text-lg lg:text-xl font-mono text-foreground font-bold truncate">{value}</span>
      {trend !== undefined && trend !== 0 && (
        <span
          className={cn(
            'text-[10px] font-bold flex items-center uppercase ml-auto shrink-0',
            trend > 0 ? 'text-green-500' : 'text-red-500',
          )}
        >
          {trend > 0 ? <TrendingUp size={12} className="mr-1" /> : <TrendingDown size={12} className="mr-1" />}
          {formatDisplayNumber(Math.abs(trend))}
        </span>
      )}
    </div>
  </div>
);

const IndicatorGroup = ({
  title,
  subtitle,
  scoreLabel,
  score,
  icon: Icon,
  metrics,
}: {
  title: string;
  subtitle: string;
  scoreLabel: string;
  score: number;
  icon: LucideIcon;
  metrics: Array<{ label: string; value: string; trend?: number }>;
}) => (
  <section className="bg-card border border-border rounded p-4 flex flex-col gap-4 min-h-[290px]">
    <div className="flex items-start justify-between gap-4">
      <div className="flex items-start gap-3 min-w-0">
        <div className="h-10 w-10 rounded-full border border-primary/40 bg-primary/10 flex items-center justify-center text-primary shrink-0">
          <Icon size={20} />
        </div>
        <div className="min-w-0">
          <h3 className="text-sm font-bold uppercase tracking-widest text-foreground truncate">{title}</h3>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mt-1">{subtitle}</p>
          <div className="mt-1 text-[10px] text-primary/70 uppercase tracking-wider font-bold">{scoreLabel}</div>
          <div className="text-3xl font-mono font-bold text-primary leading-tight">{formatDisplayNumber(score)}</div>
        </div>
      </div>
      <div className="hidden md:flex h-12 w-24 items-end justify-end opacity-60 text-primary">
        <TrendingUp size={42} strokeWidth={1.4} />
      </div>
    </div>

    <div className={cn('grid gap-3', metrics.length >= 6 ? 'grid-cols-2 xl:grid-cols-3' : 'grid-cols-2 lg:grid-cols-3')}>
      {metrics.map((metric) => (
        <SmallMetricTile key={metric.label} {...metric} />
      ))}
    </div>
  </section>
);

export const Overview = () => {
  const { state, history, applyPolicy, theme } = useGame();
  const { language, t, policyName, eventName, metricName, locale } = useLanguage();

  const currentScore = evaluateState(state);
  const prevScore = history.length > 1 ? evaluateState(history[history.length - 2]) : currentScore;
  const scoreTrend = currentScore - prevScore;
  const nationHealth = assessNationHealth(state);

  const maxChartPoints = 240;
  const chartStep = Math.max(1, Math.ceil(history.length / maxChartPoints));
  const chartHistory = history.filter((_, index) =>
    index === 0 || index === history.length - 1 || index % chartStep === 0,
  );
  const chartData = chartHistory.map((item) => ({
    month: `${language === 'vi' ? 'T' : 'M'}${item.month} ${item.year}`,
    score: evaluateState(item),
    happiness: item.happiness,
    nationHealth: assessNationHealth(item).score,
  }));

  const availablePolicies = POLICIES.filter((policy) => policy.cost <= state.budget).slice(0, 4);
  const chartColors = theme === 'dark'
    ? {
        grid: '#1e293b',
        text: '#94a3b8',
        score: '#3b82f6',
        happiness: '#10b981',
        nationHealth: '#f59e0b',
        tooltipBg: '#161d26',
        tooltipBorder: '#1e293b',
      }
    : {
        grid: '#e2e8f0',
        text: '#64748b',
        score: '#2563eb',
        happiness: '#059669',
        nationHealth: '#d97706',
        tooltipBg: '#ffffff',
        tooltipBorder: '#e2e8f0',
      };

  const formatPopulation = (value: number) => new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(value);
  const formatValue = (value: number, suffix = '') => `${formatDisplayNumber(value)}${suffix}`;
  const formatPercent = (value: number) => formatValue(value, '%');
  const formatMoney = (value: number) => `${formatDisplayNumber(value)}B`;

  const populationScale = Math.max(0.1, state.population / 1_000_000);
  const gdpHealth = clampNumber(((state.gdp / populationScale) / 1000) * 100, 0, 100);
  const budgetHealth = clampNumber((state.budget / 500) * 100, 0, 100);
  const debtSafety = clampNumber(100 - Math.max(0, state.debt / Math.max(1, state.gdp) - 0.4) * 180, 0, 100);
  const taxSafety = clampNumber(100 - Math.max(0, state.taxRate - 24) * 8 - Math.max(0, 8 - state.taxRate) * 4, 0, 100);
  const inflationSafety = clampNumber(100 - Math.max(0, state.inflation - 3) * 8 - Math.max(0, 1 - state.inflation) * 6, 0, 100);
  const employmentHealth = clampNumber(100 - state.unemployment * 2 - Math.max(0, state.unemployment - 18) * 2.5, 0, 100);
  const populationHealth = clampNumber((state.population / 1_000_000) * 100, 0, 100);

  const economicScore = average([gdpHealth, budgetHealth, debtSafety, taxSafety, inflationSafety, employmentHealth]) * 10;
  const socialScore = average([state.happiness, populationHealth, state.education, state.healthcare]) * 10;
  const developmentScore = average([state.energy, state.infrastructure, state.environment, state.technology]) * 10;
  const securityScore = average([state.military, state.cybersecurity, state.diplomacy]) * 10;

  const groupLabels = language === 'vi'
    ? {
        economy: 'A. Kinh tế',
        society: 'B. Xã hội',
        development: 'C. Phát triển & hạ tầng',
        security: 'D. An ninh & đối ngoại',
        economySubtitle: 'Nền tảng tài chính và sức khỏe kinh tế',
        societySubtitle: 'Đời sống dân cư và năng lực xã hội',
        developmentSubtitle: 'Nền tảng sản xuất và khả năng chống chịu',
        securitySubtitle: 'Năng lực bảo vệ và quan hệ quốc tế',
        economyScore: 'Điểm kinh tế',
        societyScore: 'Điểm xã hội',
        developmentScore: 'Điểm phát triển',
        securityScore: 'Điểm an ninh',
      }
    : {
        economy: 'A. Economy',
        society: 'B. Society',
        development: 'C. Development & Infrastructure',
        security: 'D. Security & Foreign Affairs',
        economySubtitle: 'Fiscal foundation and economic pressure',
        societySubtitle: 'Population welfare and social capacity',
        developmentSubtitle: 'Productive base and resilience capacity',
        securitySubtitle: 'Protection capacity and foreign relations',
        economyScore: 'Economic score',
        societyScore: 'Social score',
        developmentScore: 'Development score',
        securityScore: 'Security score',
      };

  const indicatorGroups = [
    {
      title: groupLabels.economy,
      subtitle: groupLabels.economySubtitle,
      scoreLabel: groupLabels.economyScore,
      score: economicScore,
      icon: Landmark,
      metrics: [
        { label: metricName('gdp'), value: formatMoney(state.gdp) },
        { label: metricName('budget'), value: formatMoney(state.budget) },
        {
          label: metricName('debt'),
          value: formatMoney(state.debt),
          trend: history.length > 1 ? state.debt - history[history.length - 2].debt : 0,
        },
        { label: metricName('taxRate'), value: formatPercent(state.taxRate) },
        { label: metricName('inflation'), value: formatPercent(state.inflation) },
        { label: metricName('unemployment'), value: formatPercent(state.unemployment) },
      ],
    },
    {
      title: groupLabels.society,
      subtitle: groupLabels.societySubtitle,
      scoreLabel: groupLabels.societyScore,
      score: socialScore,
      icon: Users,
      metrics: [
        { label: metricName('happiness'), value: formatPercent(state.happiness) },
        { label: metricName('population'), value: formatPopulation(state.population) },
        { label: metricName('education'), value: formatPercent(state.education) },
        { label: metricName('healthcare'), value: formatPercent(state.healthcare) },
      ],
    },
    {
      title: groupLabels.development,
      subtitle: groupLabels.developmentSubtitle,
      scoreLabel: groupLabels.developmentScore,
      score: developmentScore,
      icon: Building2,
      metrics: [
        { label: metricName('energy'), value: formatPercent(state.energy) },
        { label: metricName('infrastructure'), value: formatPercent(state.infrastructure) },
        { label: metricName('environment'), value: formatPercent(state.environment) },
        { label: metricName('technology'), value: formatPercent(state.technology) },
      ],
    },
    {
      title: groupLabels.security,
      subtitle: groupLabels.securitySubtitle,
      scoreLabel: groupLabels.securityScore,
      score: securityScore,
      icon: ShieldCheck,
      metrics: [
        { label: metricName('military'), value: formatPercent(state.military) },
        { label: metricName('cybersecurity'), value: formatPercent(state.cybersecurity) },
        { label: metricName('diplomacy'), value: formatPercent(state.diplomacy) },
      ],
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-in fade-in duration-500">
      <div className="flex items-start justify-between border-b border-border pb-4 mb-6">
        <div>
          <h2 className="text-xl font-bold tracking-tight uppercase">{t('overview.title')}</h2>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">{t('overview.subtitle')}</p>
        </div>

        <div className="bg-primary/10 border border-primary/20 px-6 py-3 rounded flex items-center gap-4">
          <div>
            <div className="text-xs font-semibold text-primary/70 uppercase tracking-wider">{t('overview.nationalScore')}</div>
            <div className="text-3xl font-bold text-primary font-mono">{formatDisplayNumber(currentScore)}</div>
          </div>
          {scoreTrend !== 0 && (
            <div className={cn('flex items-center text-sm font-medium', scoreTrend > 0 ? 'text-green-500' : 'text-red-500')}>
              {scoreTrend > 0 ? <TrendingUp size={16} className="mr-1" /> : <TrendingDown size={16} className="mr-1" />}
              {formatDisplayNumber(Math.abs(scoreTrend))}
            </div>
          )}
        </div>
      </div>

      {state.active_events.length > 0 && (
        <div className="bg-red-500/10 border border-red-500/20 p-4 rounded flex flex-col gap-2">
          <div className="flex items-center gap-2 text-red-500 font-semibold">
            <AlertTriangle size={18} />
            <span>{t('overview.activeCrises')}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {state.active_events.map((event, index) => (
              <span key={`${event}-${index}`} className="bg-red-500/20 text-red-500/90 text-sm px-2 py-1 rounded">
                {eventName(event)}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {indicatorGroups.map((group) => (
          <IndicatorGroup key={group.title} {...group} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-card border border-border rounded flex flex-col h-80 overflow-hidden">
          <div className="p-4 border-b border-border flex items-center justify-between bg-card text-xs font-bold uppercase tracking-widest text-muted-foreground">
            <span>{t('overview.performanceTrend')}</span>
            <span className="font-mono text-primary">{nationHealth.score}/100</span>
          </div>
          <div className="flex-1 p-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                <XAxis dataKey="month" stroke={chartColors.text} fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke={chartColors.text} fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: chartColors.tooltipBg,
                    borderColor: chartColors.tooltipBorder,
                    borderRadius: '4px',
                  }}
                  itemStyle={{ color: chartColors.text }}
                />
                <Line name={t('chart.score')} type="monotone" dataKey="score" stroke={chartColors.score} strokeWidth={2} dot={false} />
                <Line name={t('chart.happiness')} type="monotone" dataKey="happiness" stroke={chartColors.happiness} strokeWidth={1} dot={false} strokeDasharray="3 3" />
                <Line name={t('chart.nationHealth')} type="monotone" dataKey="nationHealth" stroke={chartColors.nationHealth} strokeWidth={1} dot={false} strokeDasharray="3 3" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-card border border-border rounded overflow-hidden flex flex-col">
          <div className="p-4 border-b border-border bg-card text-xs font-bold uppercase tracking-widest text-muted-foreground">
            {t('overview.latestEvents')}
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {availablePolicies.map((policy) => (
              <div key={policy.id} className="p-3 border border-border rounded flex flex-col gap-2">
                <div className="flex justify-between items-start gap-3">
                  <span className="font-medium text-sm">{policyName(policy.id)}</span>
                  <span className="text-xs font-mono text-muted-foreground border border-border px-1.5 py-0.5 rounded bg-background shrink-0">
                    ${policy.cost.toFixed(1)}B
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => applyPolicy(policy)}
                  className="w-full text-xs py-1.5 bg-primary/10 hover:bg-primary/20 text-primary rounded font-medium transition-colors"
                >
                  {t('overview.applyPolicy')}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

import { Info } from 'lucide-react';
import { useLanguage } from '../core/LanguageProvider';

export const About = () => {
  const { t } = useLanguage();

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-in fade-in duration-500">
      <div className="border-b border-border pb-4 mb-6">
        <h2 className="text-xl font-bold tracking-tight uppercase">{t('about.title')}</h2>
        <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">{t('about.subtitle')}</p>
      </div>

      <div className="bg-card border border-border p-6 rounded space-y-4 text-foreground/80 leading-relaxed">
        <div className="flex items-center gap-3 text-primary mb-4">
          <Info size={24} />
          <h3 className="text-xl font-bold">{t('about.architecture')}</h3>
        </div>

        <p>{t('about.intro')}</p>

        <h4 className="font-semibold text-foreground mt-4">{t('about.components')}</h4>
        <ul className="list-disc pl-5 space-y-2">
          <li><strong>{t('about.stateEngine').split(':')[0]}</strong>: {t('about.stateEngine').split(':').slice(1).join(':').trim()}</li>
          <li><strong>{t('about.policyMatrix').split(':')[0]}</strong>: {t('about.policyMatrix').split(':').slice(1).join(':').trim()}</li>
          <li><strong>{t('about.eventGenerator').split(':')[0]}</strong>: {t('about.eventGenerator').split(':').slice(1).join(':').trim()}</li>
          <li><strong>{t('about.aiLab').split(':')[0]}</strong>: {t('about.aiLab').split(':').slice(1).join(':').trim()}</li>
        </ul>

        <h4 className="font-semibold text-foreground mt-4">{t('about.technicalNote')}</h4>
        <p className="text-sm bg-foreground/5 p-4 rounded">{t('about.technicalText')}</p>
      </div>
    </div>
  );
};

import { useState } from 'react';
import { useGame } from '../core/GameProvider';
import { useLanguage } from '../core/LanguageProvider';
import { algorithms } from '../core/algorithms';
import { benchmarkPythonAlgorithm } from '../core/pythonAiClient';
import { getAlgorithmRunLimit } from '../core/aiSettings';
import { POLICIES } from '../core/data';
import { NationState } from '../core/types';
import {
  advanceMonth,
  applyPolicyToState,
  assessNationHealth,
  evaluateState,
  getCollapseReasons,
  isNationCollapsed,
} from '../core/state';
import { Play, Loader2, ArrowUpDown } from 'lucide-react';

const FIVE_YEAR_MONTHS = 60;

type SortField =
  | 'finalScore'
  | 'totalRuntimeMs'
  | 'totalNodesExpanded'
  | 'avgStabilityDeviation'
  | 'finalStability'
  | 'minStability'
  | 'maxMonthlyStabilityDrop'
  | 'policyDiversity'
  | 'noActionMonths'
  | 'completedMonths';

type ProgressState = {
  algorithm: string;
  algorithmIndex: number;
  totalAlgorithms: number;
  month: number;
  totalMonths: number;
};

type AlgorithmComparisonResult = {
  algorithm: string;
  totalRuntimeMs: number;
  totalWallTimeMs: number;
  totalNodesExpanded: number;
  finalScore: number;
  finalStability: number;
  avgStabilityDeviation: number;
  minStability: number;
  maxMonthlyStabilityDrop: number;
  completedMonths: number;
  policyActionMonths: number;
  noActionMonths: number;
  uniquePolicyCount: number;
  policyDiversity: number;
  topPolicyIds: string[];
  finalState: NationState;
  collapsedAtMonth: number | null;
  collapseReasons: string[];
  error?: string;
};

const cloneState = (state: NationState): NationState => ({
  ...state,
  active_events: [...state.active_events],
  recentPolicies: [...(state.recentPolicies ?? [])],
});

const waitForUi = () => new Promise<void>((resolve) => window.setTimeout(resolve, 0));

const average = (values: number[]): number =>
  values.length === 0 ? 0 : values.reduce((sum, value) => sum + value, 0) / values.length;

const toFixedNumber = (value: number, digits = 2): number => Number(value.toFixed(digits));

export const Compare = () => {
  const { state, aiSettings } = useGame();
  const { t, locale, policyName } = useLanguage();
  const [results, setResults] = useState<AlgorithmComparisonResult[]>([]);
  const [isComputing, setIsComputing] = useState(false);
  const [progress, setProgress] = useState<ProgressState | null>(null);
  const [benchmarkWallTimeMs, setBenchmarkWallTimeMs] = useState(0);
  const [sortField, setSortField] = useState<SortField>('finalScore');
  const [sortDesc, setSortDesc] = useState(true);

  const formatNumber = (value: number, maximumFractionDigits = 0) =>
    new Intl.NumberFormat(locale, { maximumFractionDigits }).format(value);

  const formatPercent = (value: number, maximumFractionDigits = 0) => `${formatNumber(value, maximumFractionDigits)}%`;

  const formatMs = (value: number) => {
    if (value >= 1000) return `${formatNumber(value / 1000, 2)} s`;
    return `${formatNumber(value, 2)} ms`;
  };

  const resolveTopPolicies = (policyIds: string[]) => {
    if (policyIds.length === 0) return t('compare.noPolicy');
    return policyIds.map((policyId) => policyName(policyId)).join(', ');
  };

  const simulateAlgorithmForFiveYears = async (
    algorithm: string,
    algorithmIndex: number,
    totalAlgorithms: number,
  ): Promise<AlgorithmComparisonResult> => {
    const runLimit = getAlgorithmRunLimit(algorithm, aiSettings);
    setProgress({ algorithm, algorithmIndex, totalAlgorithms, month: 0, totalMonths: FIVE_YEAR_MONTHS });

    try {
      const pythonResult = await benchmarkPythonAlgorithm(
        algorithm,
        cloneState(state),
        runLimit,
        aiSettings,
        FIVE_YEAR_MONTHS,
      );
      setProgress({ algorithm, algorithmIndex, totalAlgorithms, month: pythonResult.completedMonths, totalMonths: FIVE_YEAR_MONTHS });
      return pythonResult;
    } catch (pythonError) {
      // Keep the original TypeScript path as a resilience fallback so the UI
      // remains usable when the local FastAPI process has not been started.
      console.warn('Python benchmark unavailable; using TypeScript fallback.', pythonError);
    }

    let current = cloneState(state);
    let totalRuntimeMs = 0;
    let totalNodesExpanded = 0;
    let completedMonths = 0;
    let noActionMonths = 0;
    let collapsedAtMonth: number | null = null;
    const collapseReasons: string[] = [];
    const stabilityScores: number[] = [assessNationHealth(current).score];
    const policyUsage: Record<string, number> = {};
    const wallStart = performance.now();

    try {
      for (let month = 1; month <= FIVE_YEAR_MONTHS; month += 1) {
        setProgress({ algorithm, algorithmIndex, totalAlgorithms, month, totalMonths: FIVE_YEAR_MONTHS });

        const runLimit = getAlgorithmRunLimit(algorithm, aiSettings);
        const analysis = algorithms[algorithm](current, runLimit, aiSettings);
        totalRuntimeMs += analysis.runtimeMs;
        totalNodesExpanded += analysis.nodesExpanded;

        const policy = analysis.recommendedPolicyId
          ? POLICIES.find((item) => item.id === analysis.recommendedPolicyId)
          : undefined;

        if (policy && policy.cost <= current.budget) {
          current = applyPolicyToState(current, policy);
          policyUsage[policy.id] = (policyUsage[policy.id] ?? 0) + 1;
        } else {
          noActionMonths += 1;
        }

        current = advanceMonth(current);
        completedMonths = month;
        stabilityScores.push(assessNationHealth(current).score);

        if (isNationCollapsed(current)) {
          collapsedAtMonth = month;
          collapseReasons.push(...getCollapseReasons(current));
          break;
        }

        if (month % 2 === 0) await waitForUi();
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        algorithm,
        totalRuntimeMs: toFixedNumber(totalRuntimeMs),
        totalWallTimeMs: toFixedNumber(performance.now() - wallStart),
        totalNodesExpanded,
        finalScore: -100000,
        finalStability: toFixedNumber(assessNationHealth(current).score, 1),
        avgStabilityDeviation: 100,
        minStability: toFixedNumber(Math.min(...stabilityScores), 1),
        maxMonthlyStabilityDrop: 100,
        completedMonths,
        policyActionMonths: Object.values(policyUsage).reduce((sum, value) => sum + value, 0),
        noActionMonths,
        uniquePolicyCount: Object.keys(policyUsage).length,
        policyDiversity: 0,
        topPolicyIds: [],
        finalState: current,
        collapsedAtMonth,
        collapseReasons,
        error: message,
      };
    }

    const deviations = stabilityScores.slice(1).map((score, index) => Math.abs(score - stabilityScores[index]));
    const drops = stabilityScores.slice(1).map((score, index) => Math.max(0, stabilityScores[index] - score));
    const policyActionMonths = Object.values(policyUsage).reduce((sum, value) => sum + value, 0);
    const uniquePolicyCount = Object.keys(policyUsage).length;
    const topPolicyIds = Object.entries(policyUsage)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([policyId]) => policyId);

    return {
      algorithm,
      totalRuntimeMs: toFixedNumber(totalRuntimeMs),
      totalWallTimeMs: toFixedNumber(performance.now() - wallStart),
      totalNodesExpanded,
      finalScore: toFixedNumber(evaluateState(current), 1),
      finalStability: toFixedNumber(assessNationHealth(current).score, 1),
      avgStabilityDeviation: toFixedNumber(average(deviations), 2),
      minStability: toFixedNumber(Math.min(...stabilityScores), 1),
      maxMonthlyStabilityDrop: toFixedNumber(Math.max(0, ...drops), 2),
      completedMonths,
      policyActionMonths,
      noActionMonths,
      uniquePolicyCount,
      policyDiversity: policyActionMonths > 0 ? toFixedNumber((uniquePolicyCount / policyActionMonths) * 100, 1) : 0,
      topPolicyIds,
      finalState: current,
      collapsedAtMonth,
      collapseReasons,
    };
  };

  const runAll = async () => {
    setIsComputing(true);
    setResults([]);
    setProgress(null);
    setBenchmarkWallTimeMs(0);
    setSortField('finalScore');
    setSortDesc(true);

    const keys = Object.keys(algorithms);
    const nextResults: AlgorithmComparisonResult[] = [];
    const suiteStart = performance.now();

    for (let index = 0; index < keys.length; index += 1) {
      const algorithm = keys[index];
      const result = await simulateAlgorithmForFiveYears(algorithm, index + 1, keys.length);
      nextResults.push(result);
      setResults([...nextResults]);
      setBenchmarkWallTimeMs(toFixedNumber(performance.now() - suiteStart));
      await waitForUi();
    }

    setBenchmarkWallTimeMs(toFixedNumber(performance.now() - suiteStart));
    setProgress(null);
    setIsComputing(false);
  };

  const sorted = [...results].sort((a, b) => {
    const valueA = a[sortField];
    const valueB = b[sortField];
    return sortDesc ? valueB - valueA : valueA - valueB;
  });

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDesc((current) => !current);
    } else {
      setSortField(field);
      setSortDesc(field !== 'avgStabilityDeviation' && field !== 'totalRuntimeMs' && field !== 'maxMonthlyStabilityDrop');
    }
  };

  const bestFinalScore = results.reduce<AlgorithmComparisonResult | null>(
    (best, item) => (!best || item.finalScore > best.finalScore ? item : best),
    null,
  );
  const steadiest = results.reduce<AlgorithmComparisonResult | null>(
    (best, item) => (!best || item.avgStabilityDeviation < best.avgStabilityDeviation ? item : best),
    null,
  );
  const mostDiverse = results.reduce<AlgorithmComparisonResult | null>(
    (best, item) => (!best || item.policyDiversity > best.policyDiversity ? item : best),
    null,
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-in fade-in duration-500">
      <div className="flex justify-between items-start border-b border-border pb-4 mb-6 gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight uppercase">{t('compare.title')}</h2>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1 max-w-3xl">
            {t('compare.subtitle')}
          </p>
        </div>
        <button
          type="button"
          onClick={() => void runAll()}
          disabled={isComputing}
          className="bg-primary text-primary-foreground px-6 py-2.5 rounded flex items-center justify-center gap-2 hover:opacity-90 transition-opacity font-bold text-xs shadow-lg shadow-primary/20 disabled:opacity-50 whitespace-nowrap"
        >
          {isComputing ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />}
          {isComputing ? t('compare.running') : t('compare.run')}
        </button>
      </div>

      <div className="bg-card border border-border rounded-lg p-4 text-xs text-muted-foreground leading-relaxed">
        <span className="font-bold text-foreground">{t('compare.fiveYearMode')}</span>{' '}
        {t('compare.fiveYearNote')}
      </div>

      {results.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{t('compare.totalBenchmarkTime')}</p>
            <p className="text-xl font-bold font-mono mt-1">{formatMs(benchmarkWallTimeMs)}</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{t('compare.bestFinalScore')}</p>
            <p className="text-xl font-bold text-primary mt-1">{bestFinalScore?.algorithm ?? '-'}</p>
            <p className="text-xs font-mono mt-1">{bestFinalScore ? formatNumber(bestFinalScore.finalScore, 1) : '-'}</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{t('compare.steadiest')}</p>
            <p className="text-xl font-bold text-emerald-400 mt-1">{steadiest?.algorithm ?? '-'}</p>
            <p className="text-xs font-mono mt-1">{steadiest ? formatNumber(steadiest.avgStabilityDeviation, 2) : '-'}</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{t('compare.mostDiverse')}</p>
            <p className="text-xl font-bold text-blue-300 mt-1">{mostDiverse?.algorithm ?? '-'}</p>
            <p className="text-xs font-mono mt-1">{mostDiverse ? formatPercent(mostDiverse.policyDiversity, 1) : '-'}</p>
          </div>
        </div>
      )}

      <div className="bg-card border border-border rounded overflow-hidden min-h-[400px]">
        {results.length === 0 && !isComputing && (
          <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-muted-foreground p-6 text-center">
            <p>{t('compare.empty')}</p>
          </div>
        )}

        {isComputing && results.length === 0 && (
          <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-primary p-6 text-center">
            <Loader2 size={48} className="animate-spin mb-4" />
            <p className="font-medium animate-pulse">{t('compare.fullSuite')}</p>
            {progress && (
              <p className="text-xs text-muted-foreground mt-2">
                {progress.algorithmIndex}/{progress.totalAlgorithms} · {progress.algorithm} · {t('layout.month')} {progress.month}/{progress.totalMonths}
              </p>
            )}
          </div>
        )}

        {results.length > 0 && (
          <div>
            {isComputing && progress && (
              <div className="border-b border-border bg-primary/10 p-3 text-xs text-primary flex items-center gap-2">
                <Loader2 size={14} className="animate-spin" />
                <span>
                  {progress.algorithmIndex}/{progress.totalAlgorithms} · {progress.algorithm} · {t('layout.month')} {progress.month}/{progress.totalMonths}
                </span>
              </div>
            )}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm min-w-[1280px]">
                <thead className="bg-foreground/5 text-foreground">
                  <tr>
                    <th className="p-4 font-medium">{t('compare.algorithm')}</th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('finalScore')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.finalScore')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('totalRuntimeMs')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.totalRuntime')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('totalNodesExpanded')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.totalNodes')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('avgStabilityDeviation')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.avgStabilityDeviation')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('finalStability')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.finalStability')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('minStability')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.minStability')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('maxMonthlyStabilityDrop')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.maxMonthlyDrop')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('policyDiversity')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.policyDiversity')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('noActionMonths')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.noActionMonths')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                    <th className="p-4 font-medium">{t('compare.topPolicies')}</th>
                    <th className="p-4 font-medium cursor-pointer" onClick={() => toggleSort('completedMonths')}>
                      <div className="flex items-center gap-1 hover:text-primary transition-colors">
                        {t('compare.status')} <ArrowUpDown size={14} />
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {sorted.map((result) => (
                    <tr key={result.algorithm} className="hover:bg-foreground/5 transition-colors align-top">
                      <td className="p-4 font-semibold whitespace-nowrap">{result.algorithm}</td>
                      <td className="p-4 font-mono font-bold text-primary">{formatNumber(result.finalScore, 1)}</td>
                      <td className="p-4 font-mono whitespace-nowrap">{formatMs(result.totalRuntimeMs)}</td>
                      <td className="p-4 font-mono">{formatNumber(result.totalNodesExpanded)}</td>
                      <td className="p-4 font-mono">{formatNumber(result.avgStabilityDeviation, 2)}</td>
                      <td className="p-4 font-mono">{formatPercent(result.finalStability, 1)}</td>
                      <td className="p-4 font-mono">{formatPercent(result.minStability, 1)}</td>
                      <td className="p-4 font-mono">{formatNumber(result.maxMonthlyStabilityDrop, 2)}</td>
                      <td className="p-4 font-mono whitespace-nowrap">
                        {formatPercent(result.policyDiversity, 1)}
                        <span className="block text-[10px] text-muted-foreground font-sans">
                          {result.uniquePolicyCount}/{result.policyActionMonths}
                        </span>
                      </td>
                      <td className="p-4 font-mono">{result.noActionMonths}</td>
                      <td className="p-4 min-w-[220px] text-xs leading-relaxed">{resolveTopPolicies(result.topPolicyIds)}</td>
                      <td className="p-4 min-w-[160px]">
                        {result.error ? (
                          <span className="text-red-400 text-xs">{result.error}</span>
                        ) : result.collapsedAtMonth ? (
                          <span className="text-red-400 text-xs">
                            {t('compare.collapsedAt')} {result.collapsedAtMonth}/{FIVE_YEAR_MONTHS}
                          </span>
                        ) : (
                          <span className="text-emerald-400 text-xs">{t('compare.completedRun')}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

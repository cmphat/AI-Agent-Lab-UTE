import { useEffect, useMemo, useState } from 'react';
import { useGame } from '../core/GameProvider';
import { useLanguage } from '../core/LanguageProvider';
import { algorithms } from '../core/algorithms';
import { checkPythonEngine, runPythonAlgorithm } from '../core/pythonAiClient';
import { getAlgorithmRunLimit, getAlgorithmSettingLabelKey, getAlgorithmSettingValue } from '../core/aiSettings';
import { ALGORITHM_DOCS } from '../core/algorithmDocs';
import { POLICIES } from '../core/data';
import { BookOpen, CheckCircle2, Loader2, Play, ShieldCheck, Workflow, X } from 'lucide-react';
import { evaluateState } from '../core/state';
import { AlgorithmResult } from '../core/types';
import { cn } from '../components/layout/Layout';



export const AILab = () => {
  const {
    state,
    executePolicyPlan,
    selectedAlgorithm: algoName,
    setSelectedAlgorithm: setAlgoName,
    aiSettings,
  } = useGame();
  const { t, policyName, categoryName, locale, language } = useLanguage();
  const [isComputing, setIsComputing] = useState(false);
  const [result, setResult] = useState<AlgorithmResult | null>(null);
  const [showPseudocode, setShowPseudocode] = useState(false);
  const [engineMode, setEngineMode] = useState<'checking' | 'python' | 'fallback'>('checking');
  const [engineMessage, setEngineMessage] = useState('');

  const algorithmKeys = Object.keys(algorithms);
  const selectedDoc = useMemo(() => ALGORITHM_DOCS[algoName], [algoName]);
  const runLimit = useMemo(() => getAlgorithmRunLimit(algoName, aiSettings), [algoName, aiSettings]);
  const settingLabelKey = useMemo(() => getAlgorithmSettingLabelKey(algoName), [algoName]);
  const settingValue = useMemo(() => getAlgorithmSettingValue(algoName, aiSettings), [algoName, aiSettings]);

  useEffect(() => {
    if (!algorithms[algoName]) setAlgoName('A*');
  }, [algoName, setAlgoName]);

  useEffect(() => {
    let cancelled = false;
    checkPythonEngine()
      .then((health) => {
        if (cancelled) return;
        setEngineMode('python');
        setEngineMessage(`Python ${health.version} · ${health.algorithms} algorithms`);
      })
      .catch(() => {
        if (cancelled) return;
        setEngineMode('fallback');
        setEngineMessage('Python backend offline · TypeScript fallback');
      });
    return () => { cancelled = true; };
  }, []);

  const runSimulation = async () => {
    setIsComputing(true);
    setResult(null);
    await new Promise<void>((resolve) => window.setTimeout(resolve, 40));

    try {
      const pythonResult = await runPythonAlgorithm(algoName, state, runLimit, aiSettings);
      setResult(pythonResult);
      setEngineMode('python');
      setEngineMessage('Python AI Engine');
    } catch (error) {
      const algorithm = algorithms[algoName];
      if (algorithm) {
        setResult(algorithm(state, runLimit, aiSettings));
        setEngineMode('fallback');
        setEngineMessage(error instanceof Error ? `Fallback: ${error.message}` : 'TypeScript fallback');
      }
    } finally {
      setIsComputing(false);
    }
  };

  const applyRecommendation = () => {
    const policyId = result?.recommendedPolicyId;
    if (!policyId) return;

    // AI algorithms may internally forecast several future months, but gameplay
    // only commits the next-month recommendation. Later plan entries remain a
    // preview, not an auto-executed sequence.
    executePolicyPlan([policyId]);
    setResult(null);
  };

  const recommendedPolicyId = result?.recommendedPolicyId ?? null;
  const previewPolicies = result?.planPreview ?? result?.displayPolicies ?? result?.bestPolicies ?? [];

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-in fade-in duration-500">
      <div className="border-b border-border pb-4 mb-6">
        <h2 className="text-xl font-bold tracking-tight uppercase">{t('ai.title')}</h2>
        <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">{t('ai.subtitle')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-card border border-border p-6 rounded space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium">{t('ai.algorithm')}</label>
            <select
              className="w-full bg-background border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              value={algoName}
              onChange={(event) => {
                setAlgoName(event.target.value);
                setResult(null);
              }}
            >
              {algorithmKeys.map((key) => (
                <option key={key} value={key}>{key}</option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => setShowPseudocode(true)}
              className="w-full border border-border bg-background px-3 py-2 rounded text-sm font-medium flex items-center justify-center gap-2 hover:bg-foreground/5 transition-colors"
            >
              <BookOpen size={16} />
              {t('ai.pseudocode')}
            </button>
          </div>

          {selectedDoc && (
            <div className="border border-border bg-background rounded p-3 space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-primary">
                <ShieldCheck size={15} />
                {t('ai.implementationBadge')}
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {selectedDoc.summary[language]}
              </p>
            </div>
          )}

          <div className="border border-border bg-background rounded p-3 space-y-2">
            <div className="flex justify-between items-center gap-3">
              <label className="text-sm font-medium">{t('ai.activeSetting')}</label>
              <span className="text-xs font-mono bg-card border border-border px-1.5 py-0.5 rounded">{settingValue}</span>
            </div>
            <div className="text-xs font-semibold text-primary">{t(settingLabelKey)}</div>
            <p className="text-xs text-muted-foreground leading-relaxed">{t('ai.activeSettingHint')}</p>
          </div>

          <div className="border border-border bg-background rounded p-3">
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs font-semibold">AI Engine</span>
              <span className={cn(
                'text-[10px] uppercase tracking-wider font-semibold',
                engineMode === 'python' ? 'text-emerald-500' : engineMode === 'checking' ? 'text-amber-500' : 'text-orange-500',
              )}>
                {engineMode === 'python' ? 'Python / FastAPI' : engineMode === 'checking' ? 'Checking' : 'Fallback'}
              </span>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1 break-words">{engineMessage || 'Connecting to Python AI Engine...'}</p>
          </div>

          <button
            type="button"
            onClick={runSimulation}
            disabled={isComputing}
            className="w-full bg-primary text-primary-foreground py-2.5 rounded font-medium flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {isComputing ? <Loader2 size={18} className="animate-spin" /> : <Play size={18} />}
            {isComputing ? t('ai.simulating') : t('ai.run')}
          </button>
        </div>

        <div className="lg:col-span-2 bg-card border border-border rounded overflow-hidden flex flex-col min-h-[440px]">
          <div className="p-4 border-b border-border bg-foreground/5 font-medium flex items-center gap-2">
            <Workflow size={18} className="text-muted-foreground" />
            {t('ai.results')}
          </div>

          <div className="p-6 flex-1 flex flex-col items-center justify-center">
            {!result && !isComputing && (
              <div className="text-center text-muted-foreground max-w-sm">
                <Workflow size={48} className="mx-auto mb-4 opacity-20" />
                <p>{t('ai.empty')}</p>
              </div>
            )}

            {isComputing && (
              <div className="text-center text-primary space-y-4">
                <Loader2 size={48} className="mx-auto animate-spin" />
                <p className="font-medium animate-pulse">{t('ai.computing')}</p>
              </div>
            )}

            {result && !isComputing && (
              <div className="w-full space-y-6 animate-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-bold">{result.algorithm}</h3>
                    <div className="mt-1 inline-flex items-center gap-1.5 text-[11px] text-primary font-medium">
                      <CheckCircle2 size={14} />
                      {t('ai.implementationBadge')}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-muted-foreground">{t('ai.projectedScore')}</div>
                    <div
                      className={cn(
                        'text-2xl font-bold font-mono',
                        result.score > evaluateState(state) ? 'text-green-500' : '',
                      )}
                    >
                      {result.score.toFixed(1)}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
                  <div className="bg-background border border-border p-3 rounded flex flex-col">
                    <span className="text-[10px] text-muted-foreground uppercase">{t('ai.nodes')}</span>
                    <span className="text-lg font-mono">{result.nodesExpanded.toLocaleString(locale)}</span>
                  </div>
                  <div className="bg-background border border-border p-3 rounded flex flex-col">
                    <span className="text-[10px] text-muted-foreground uppercase">{t('ai.runtime')}</span>
                    <span className="text-lg font-mono">{result.runtimeMs} ms</span>
                  </div>
                  <div className="bg-background border border-border p-3 rounded flex flex-col">
                    <span className="text-[10px] text-muted-foreground uppercase">{t('ai.effectiveDepth')}</span>
                    <span className="text-lg font-mono">{result.effectiveDepth ?? runLimit}</span>
                  </div>
                  <div className="bg-background border border-border p-3 rounded flex flex-col">
                    <span className="text-[10px] text-muted-foreground uppercase">{t('ai.goalStatus')}</span>
                    <span className={cn('text-sm font-semibold mt-1', (result.improvementReached ?? result.goalReached) ? 'text-green-500' : 'text-amber-500')}>
                      {(result.improvementReached ?? result.goalReached) ? t('ai.goalReached') : t('ai.goalNotReached')}
                    </span>
                  </div>
                </div>


                <div className="space-y-3">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">{t('ai.recommendation')}</h4>
                    {recommendedPolicyId ? (() => {
                      const policy = POLICIES.find((item) => item.id === recommendedPolicyId);
                      return (
                        <div className="flex items-center gap-3 p-4 bg-primary/10 border border-primary/30 rounded">
                          <div className="bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0">1</div>
                          <div className="flex-1">
                            <div className="font-bold text-sm">{policy ? policyName(policy.id) : recommendedPolicyId}</div>
                            <div className="text-xs text-muted-foreground">{policy ? categoryName(policy.category) : ''}</div>
                          </div>
                          <div className="text-[10px] uppercase tracking-widest font-semibold text-primary bg-background border border-primary/20 px-2 py-1 rounded">
                            {t('ai.nextMonthOnly')}
                          </div>
                        </div>
                      );
                    })() : (
                      <div className="p-3 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded text-sm">
                        {t('ai.noPath')}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">{t('ai.path')}</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{t('ai.forecastHint')}</p>
                  </div>
                  {previewPolicies.length === 0 || !recommendedPolicyId ? (
                    <div className="p-3 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded text-sm">
                      {t('ai.noPath')}
                    </div>
                  ) : (
                    <div className="flex flex-col gap-2">
                      {previewPolicies.map((policyId, index) => {
                        const policy = policyId ? POLICIES.find((item) => item.id === policyId) : null;
                        const isNoAction = policyId === null;
                        const isUnknown = !isNoAction && !policy;
                        return (
                          <div key={`${policyId ?? 'unknown'}-${index}`} className="flex items-center gap-3 p-3 bg-background border border-border rounded">
                            <div className="bg-primary/20 text-primary w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0">
                              {index + 1}
                            </div>
                            <div className="flex-1">
                              <div className="font-medium text-sm">{isNoAction ? t('ai.noAction') : isUnknown ? '?' : policy ? policyName(policy.id) : policyId}</div>
                              <div className="text-xs text-muted-foreground">
                                {index === 0 ? t('ai.nextMonthOnly') : t('ai.internalForecast')}
                                {isNoAction ? ` · ${t('ai.noActionHint')}` : policy ? ` · ${categoryName(policy.category)}` : ''}
                              </div>
                            </div>
                            <div className="text-xs font-mono px-2 py-1 bg-foreground/5 rounded text-foreground/70">
                              {isNoAction ? '$0.0B' : isUnknown ? '?' : `-$${policy?.cost.toFixed(1) ?? '0.0'}B`}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {recommendedPolicyId && (
                  <button
                    type="button"
                    onClick={applyRecommendation}
                    className="w-full bg-foreground text-background py-3 rounded font-bold hover:opacity-90 transition-opacity"
                  >
                    {t('ai.executePlan')}
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {showPseudocode && selectedDoc && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm p-4 flex items-center justify-center"
          role="dialog"
          aria-modal="true"
          aria-label={`${t('ai.pseudocodeTitle')} ${algoName}`}
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setShowPseudocode(false);
          }}
        >
          <div className="w-full max-w-3xl max-h-[88vh] overflow-hidden bg-card border border-border rounded-lg shadow-2xl flex flex-col">
            <div className="flex items-start justify-between gap-4 p-5 border-b border-border">
              <div>
                <p className="text-[10px] text-primary uppercase tracking-[0.18em] font-semibold">{t('ai.pseudocodeTitle')}</p>
                <h3 className="text-xl font-bold mt-1">{algoName}</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowPseudocode(false)}
                className="p-2 rounded border border-border hover:bg-foreground/5 transition-colors"
                aria-label={t('ai.close')}
              >
                <X size={18} />
              </button>
            </div>

            <div className="overflow-y-auto p-5 space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border border-border bg-background rounded p-4">
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{t('ai.family')}</div>
                  <div className="font-semibold mt-1">{selectedDoc.family[language]}</div>
                </div>
                <div className="border border-border bg-background rounded p-4">
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{t('ai.complexity')}</div>
                  <div className="font-mono text-sm mt-1">{selectedDoc.complexity}</div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-sm mb-2">{t('ai.howApplied')}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{selectedDoc.application[language]}</p>
              </div>

              <div>
                <h4 className="font-semibold text-sm mb-2">{t('ai.pseudocodeTitle')}</h4>
                <pre className="bg-background border border-border rounded p-4 text-xs leading-6 font-mono whitespace-pre-wrap overflow-x-auto">
                  {selectedDoc.pseudocode[language]}
                </pre>
              </div>
            </div>

            <div className="p-4 border-t border-border flex justify-end">
              <button
                type="button"
                onClick={() => setShowPseudocode(false)}
                className="px-4 py-2 bg-primary text-primary-foreground rounded text-sm font-semibold hover:opacity-90"
              >
                {t('ai.close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

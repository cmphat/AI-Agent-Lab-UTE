import { useState } from 'react';
import { GameProvider } from './core/GameProvider';
import { LanguageProvider } from './core/LanguageProvider';
import { Layout } from './components/layout/Layout';
import { Overview } from './pages/Overview';
import { Policies } from './pages/Policies';
import { AILab } from './pages/AILab';
import { Compare } from './pages/Compare';
import { Scenarios } from './pages/Scenarios';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';
import { About } from './pages/About';

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview': return <Overview />;
      case 'policies': return <Policies />;
      case 'ai-lab': return <AILab />;
      case 'compare': return <Compare />;
      case 'scenarios': return <Scenarios />;
      case 'reports': return <Reports />;
      case 'settings': return <Settings />;
      case 'about': return <About />;
      default: return <Overview />;
    }
  };

  return (
    <LanguageProvider>
      <GameProvider>
        <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
          {renderContent()}
        </Layout>
      </GameProvider>
    </LanguageProvider>
  );
}

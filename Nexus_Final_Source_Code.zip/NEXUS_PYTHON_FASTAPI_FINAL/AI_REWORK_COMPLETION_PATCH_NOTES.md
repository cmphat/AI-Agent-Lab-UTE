# AI Rework Completion Patch Notes

This patch completes the remaining AI design items agreed after the first rework pass.

## Completed

- Wired advanced AI settings into the actual algorithm calls from AI Lab and Compare.
- Local Beam Search now uses `beamWidth` from Settings instead of deriving it from the calculation limit.
- Simulated Annealing now uses `annealingIterations` directly.
- Hill Climbing now uses `localSearchSteps` directly instead of doubling the old depth value.
- Minimax and Alpha-Beta now read `maxMinActions` from Settings.
- Minimax, Alpha-Beta, and Expectimax can use the configured 3 internal turns when called from the app settings path.
- CSP algorithms now use `constraintStrictness` to adjust hard thresholds and soft conflict weight.
- LRTA* now performs multiple internal learning steps and returns the first step as the next-month recommendation.
- LRTA* persistent memory is saved to `localStorage` under `nexus-lrta-memory` and can be reset by resetting AI settings.
- AND-OR now returns a conditional plan tree in `conditionalPlan` instead of only a linear path.
- Alpha-Beta now records `prunedBranches` and `pruningRatio` in debug output.
- Belief-State, CSP, LRTA*, UCS/A*, Minimax/Alpha-Beta, and Expectimax now expose algorithm-specific debug details.
- AI Lab displays a compact "Algorithm details" panel from result debug output.
- `assessNationHealth()` no longer rounds the internal health score to an integer before AI scoring.
- Algorithm docs/pseudocode were adjusted away from old goal-stop language where it conflicted with the new design.

## Still intentionally compatible

- `goalReached` remains in the TypeScript result shape as a compatibility alias, but UI text now treats it as simulated improvement.
- `bestPolicies` is still present for older code paths, but the UI applies only `recommendedPolicyId` for the next month.

## Validation

- `npm run lint` passed.
- `npm run test:algorithms` passed for all 18 algorithms.
- `npm run test:simulation` passed.
- `npm run build` passed. Vite still warns about one large JS chunk, which is a build-size warning, not a build failure.

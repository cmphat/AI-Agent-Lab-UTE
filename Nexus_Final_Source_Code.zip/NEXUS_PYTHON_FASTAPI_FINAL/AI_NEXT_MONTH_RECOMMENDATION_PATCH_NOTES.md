# AI Next-Month Recommendation Patch

This patch separates internal multi-month calculation from gameplay execution.

## Key behavior

- Algorithms may still compute an internal multi-month plan/trace.
- The UI exposes the first policy as `recommendedPolicyId` for the next month.
- Later entries are shown only as an internal forecast/reference plan.
- AI Lab applies only `[recommendedPolicyId]`, never the full `bestPolicies` trace.

## Main files changed

- `src/core/types.ts`
  - Added `recommendedPolicyId` and `planPreview` to `AlgorithmResult`.
- `src/core/algorithms.ts`
  - Standardized algorithm output so `bestPolicies` is treated as internal forecast and `recommendedPolicyId` is the single next-month action.
- `src/pages/AILab.tsx`
  - Split UI into next-month recommendation and internal forecast preview.
  - Changed apply button to enact only the recommendation for one month.
- `src/pages/Compare.tsx`
  - Displays next-month recommendation and internal forecast length.
  - Uses per-algorithm settings instead of hardcoded depth.
- `src/core/LanguageProvider.tsx`
  - Updated labels so the app no longer describes AI output as executing a full plan.

## Validation

- `npm run lint` passed.
- `npm run test:algorithms` passed for all 18 algorithms.
- `npm run test:simulation` passed.
- `npm run build` passed, with only the existing Vite chunk-size warning.

# NEXUS - Scenario Rework Notes

## Mục tiêu

Chức năng Kịch bản đã được sửa để mỗi kịch bản là một trạng thái quốc gia hoàn chỉnh, thay vì chỉ reset game rồi kích hoạt một hoặc hai sự kiện rời rạc. Điều này giúp AI Lab và So sánh thuật toán kiểm thử đúng tình trạng quốc gia hơn.

## Thay đổi chính

- Thêm `src/core/scenarios.ts` để quản lý các preset kịch bản bằng dữ liệu riêng.
- Mỗi kịch bản có đầy đủ GDP, ngân sách, nợ công, thuế, lạm phát, thất nghiệp, hạnh phúc, dân số và các năng lực nền.
- Mỗi kịch bản có danh sách sự kiện đang hoạt động phù hợp với trạng thái đó.
- Khi tải kịch bản, trạng thái và lịch sử mô phỏng được thay thế sạch bằng kịch bản mới để kết quả benchmark không bị lẫn với lịch sử cũ.
- Giao diện kịch bản hiển thị điểm ổn định, mức tình trạng, chỉ số chính, sự kiện đang hoạt động, mục tiêu xử lý và nhóm chính sách nên kiểm thử.

## Bộ kịch bản mới

1. Ổn định và có dư địa phát triển - trạng thái stable.
2. Đại dịch và áp lực xã hội - trạng thái crisis.
3. Suy thoái, biểu tình và đứt gãy chuỗi cung - trạng thái critical.
4. Xung đột khu vực và khủng hoảng năng lượng - trạng thái crisis.
5. Tấn công mạng và năng lực số yếu - trạng thái warning.
6. Thiên tai và suy thoái môi trường - trạng thái crisis.

## Kiểm tra

- `npm run lint`: pass.
- `npm run test:algorithms`: pass đủ 18 thuật toán.
- `npm run test:simulation`: pass.
- `npm run build`: pass, đã sinh lại thư mục `dist`.

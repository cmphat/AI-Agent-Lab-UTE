# Policy Balance Patch Notes

## Mục tiêu chỉnh sửa

- Cập nhật toàn bộ `POLICIES` theo các nhóm đã chốt.
- Không để policy tăng trực tiếp chỉ số kết quả nếu chỉ số nguyên nhân đã tự kéo kết quả đó trong `advanceMonth()`.
- Thêm áp lực thuế vào tăng trưởng GDP, thị trường lao động và target happiness.
- Tăng áp lực nợ công để `borrow` không quá an toàn khi tắt sự kiện ngẫu nhiên.
- Thêm chính sách `vocational_training` để nối giữa giáo dục dài hạn và việc làm ngắn hạn.

## File đã chỉnh

- `src/core/data.ts`
  - Cập nhật cost/effect/description của toàn bộ chính sách.
  - Thêm `vocational_training` trong nhóm Xã hội.
- `src/core/state.ts`
  - `calculateTargetHappiness()`: tăng tác động tiêu cực của thuế cao lên happiness target.
  - `debtSafetyFor()`: tăng penalty khi debt/GDP vượt ngưỡng 40%.
  - `advanceMonth()`: thêm tax drag vào GDP growth.
  - `advanceMonth()`: thêm tax business pressure vào job capacity.
  - `advanceMonth()`: tăng lãi nợ tháng từ `1.0015` lên `1.0025`.
- `src/core/LanguageProvider.tsx`
  - Cập nhật mô tả tiếng Anh của các policy đã đổi.
  - Thêm bản dịch `vocational_training`.
  - Cập nhật About từ 24 lên 25 chính sách.

## Kiểm tra đã chạy

- `npm run lint` — pass.
- `npm run test:simulation` — pass.
- `npm run test:algorithms` — pass đủ 18 thuật toán.
- `npm run build` — pass, còn cảnh báo bundle lớn hơn 500 kB như trước.

## Event Balance Patch

- Rebalanced all 12 random events to follow the new policy/state design.
- Removed direct GDP changes from random events. Events now affect foundation metrics such as healthcare, energy, infrastructure, unemployment, inflation, diplomacy, technology, cybersecurity, population and budget.
- Lowered base event probabilities so a stable nation faces fewer random shocks per month, while risk modifiers still make bad events more likely when related indicators are weak.
- Updated event probability modifiers in `getAdjustedEventProbability()`:
  - Pandemic now reacts to weak healthcare and high population scale.
  - War now reacts to weak diplomacy and weak military, while strong military reduces risk.
  - Recession now reacts to debt, high inflation and high unemployment.
  - Protest now reacts to low happiness, high inflation and high unemployment.
  - Supply-chain disruption now reacts to debt, diplomacy, infrastructure and energy.
  - Boom and trade pact now benefit from stronger happiness, infrastructure and diplomacy but are weakened by debt and pressure indicators.
- Updated scenario/event descriptions that previously implied direct GDP shocks.

## Event Response Policy Expansion

Added 10 always-available response policies to help the player and AI recover from negative events without adding new Policy fields, event locks, or direct event clearing. These policies follow the existing `cost` + `effect` structure and do not modify GDP directly.

New policies:
- `emergency_healthcare` — pandemic / healthcare shock response
- `ceasefire_negotiation` — diplomatic war response
- `defense_mobilization` — military war response
- `foreign_resource_deal` — oil crisis / energy shortage response
- `disaster_reconstruction` — disaster infrastructure recovery
- `cyber_incident_response` — cyberattack recovery
- `economic_stimulus` — recession response
- `social_dialogue` — protest response
- `climate_adaptation` — climate crisis response
- `supply_chain_stabilization` — supply-chain disruption response

Total policies: 35. Total events remain 12.

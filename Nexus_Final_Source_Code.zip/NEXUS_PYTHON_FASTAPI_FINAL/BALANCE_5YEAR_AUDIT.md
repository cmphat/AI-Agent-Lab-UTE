# NEXUS 5-year algorithm audit and balance notes

Audit setup: each of the 18 algorithms was run in a 60-month rolling simulation. Every month the algorithm produced one next-month recommendation; if the best internal action was to pause, the month advanced without applying a new policy.

## Balance changes

- Added long-term development potential to `evaluateState()` and `assessNationHealth()` so education, healthcare, technology, infrastructure, energy, cybersecurity, environment and diplomacy are not undervalued just because their benefit is delayed.
- Increased debt-overhang penalties and made borrow/pay/tax cycling less attractive. Borrowing is now treated as emergency liquidity, not a normal way to fund every investment.
- Added recent-policy anti-churn logic for AI search: repeated policies, reversal pairs such as tax up/tax down and borrow/pay debt, and over-concentration in one category are penalized or temporarily discouraged.
- Added an internal AI-only “pause new policy action” option. This lets cost-based, CSP and adversarial algorithms avoid forcing low-value economic actions every month.
- Kept manual policy execution unchanged; the anti-churn filter is used by the AI search action set, not by the policy page.

## 60-month audit summary

| Algorithm | Health | Level | Actions | Pause months | Unique policies | Max same run | Reversals | Category counts |
|---|---:|---|---:|---:|---:|---:|---:|---|
| BFS | 78.62 | stable | 17 | 43 | 8 | 1 | 0 | Xã hội:7, Hạ tầng:1, Công nghệ:4, Môi trường:1, Kinh tế:4 |
| DFS | 78.62 | stable | 17 | 43 | 8 | 1 | 0 | Xã hội:7, Hạ tầng:1, Công nghệ:4, Môi trường:1, Kinh tế:4 |
| IDS | 78.62 | stable | 17 | 43 | 8 | 1 | 0 | Xã hội:7, Hạ tầng:1, Công nghệ:4, Môi trường:1, Kinh tế:4 |
| UCS | 81.55 | stable | 15 | 45 | 10 | 1 | 0 | Kinh tế:5, Xã hội:4, An ninh:2, Môi trường:3, Công nghệ:1 |
| Greedy Best-First | 77.94 | warning | 15 | 45 | 12 | 1 | 0 | Hạ tầng:1, Kinh tế:3, Xã hội:5, Môi trường:1, Công nghệ:3, An ninh:2 |
| A* | 81.21 | stable | 10 | 50 | 7 | 1 | 0 | Kinh tế:1, Xã hội:4, Công nghệ:3, Môi trường:2 |
| Hill Climbing | 82.8 | stable | 8 | 52 | 6 | 1 | 0 | Hạ tầng:1, Xã hội:4, Môi trường:1, Công nghệ:2 |
| Local Beam Search | 85.44 | stable | 13 | 47 | 7 | 1 | 0 | Xã hội:6, Công nghệ:2, Môi trường:3, Kinh tế:2 |
| Simulated Annealing | 61.35 | warning | 28 | 32 | 13 | 1 | 0 | Xã hội:6, Công nghệ:1, Môi trường:5, Kinh tế:10, An ninh:6 |
| AND-OR Search | 78.36 | stable | 16 | 44 | 12 | 1 | 0 | Xã hội:2, Kinh tế:6, Môi trường:4, Công nghệ:2, An ninh:2 |
| Belief-State Search | 84.26 | stable | 12 | 48 | 7 | 1 | 0 | Xã hội:6, Công nghệ:3, Môi trường:2, Kinh tế:1 |
| LRTA* | 79.11 | stable | 13 | 47 | 10 | 1 | 0 | Kinh tế:2, Xã hội:4, Công nghệ:2, Môi trường:3, An ninh:2 |
| Constraint Propagation | 72.43 | warning | 27 | 33 | 13 | 1 | 0 | Công nghệ:3, Xã hội:5, Môi trường:5, Kinh tế:10, An ninh:4 |
| Backtracking CSP | 69.04 | warning | 27 | 33 | 14 | 1 | 0 | Xã hội:4, Kinh tế:10, Môi trường:4, Hạ tầng:1, Công nghệ:3, An ninh:5 |
| Min-Conflicts CSP | 68.44 | warning | 27 | 33 | 14 | 1 | 0 | Xã hội:5, Công nghệ:3, Môi trường:5, Kinh tế:9, An ninh:5 |
| Minimax | 84.2 | stable | 11 | 49 | 9 | 1 | 0 | Xã hội:5, Công nghệ:2, Kinh tế:2, Môi trường:2 |
| Alpha-Beta | 83.99 | stable | 10 | 50 | 8 | 1 | 0 | Xã hội:4, Công nghệ:3, Hạ tầng:1, Kinh tế:1, Môi trường:1 |
| Expectimax | 83.47 | stable | 8 | 52 | 7 | 1 | 0 | Hạ tầng:1, Kinh tế:1, Xã hội:3, Môi trường:1, An ninh:1, Công nghệ:1 |

Main audit result: all 18 algorithms completed the 5-year run without consecutive policy spam (`max same run` stayed at 1) and without immediate reversal loops (`reversals` stayed at 0). Most algorithms finished stable; the CSP-family algorithms remain more conservative/constraint-driven and can finish in warning, which is acceptable because they are not designed to maximize the same value as heuristic or adversarial search.
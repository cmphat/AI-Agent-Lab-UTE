# Hướng dẫn chạy NEXUS bản Python AI Engine

## Cách nhanh nhất trên Windows

1. Giải nén toàn bộ thư mục.
2. Cài **Python 3.11+** và **Node.js LTS**.
3. Nhấp đúp `CHAY_NEXUS.bat`.
4. Lần chạy đầu chương trình tự tạo `.venv`, cài FastAPI và cài thư viện React.
5. Trình duyệt tự mở tại `http://127.0.0.1:3000`.

Không đóng cửa sổ CMD khi đang sử dụng. Trong **Phòng chiến lược AI**, thẻ `AI Engine` phải hiện `Python / FastAPI`.

## Kiến trúc

```text
React + TypeScript (giao diện, mô phỏng, báo cáo)
                │ JSON/REST
                ▼
FastAPI + Python (18 thuật toán AI và benchmark)
```

## Chạy thủ công

Terminal 1:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r python_backend\requirements.txt
python -m uvicorn python_backend.app:app --host 127.0.0.1 --port 8000
```

Terminal 2:

```powershell
npm install
npm run dev
```

## Kiểm tra

Nhấp đúp `KIEM_TRA_NEXUS.bat`, hoặc chạy:

```powershell
npm run lint
python -m python_backend.smoke_test
npm run test:simulation
npm run test:algorithms
npm run build
```

## Chế độ dự phòng

Khi Python backend chưa chạy, giao diện vẫn có thể dùng bản TypeScript dự phòng để tránh trắng màn hình. Khi nộp và thuyết trình, hãy chạy bằng `CHAY_NEXUS.bat` để toàn bộ thao tác AI đi qua Python.

import { advanceMonth, assessNationHealth, getInitialState } from '../src/core/state';

const initial = getInitialState();
const initialHealth = assessNationHealth(initial);
if (initialHealth.level !== 'stable') {
  throw new Error(`Initial nation should be stable, got ${initialHealth.level} (${initialHealth.score})`);
}

let state = { ...initial, month: 12, year: 2026, active_events: ['pandemic'] };
state = advanceMonth(state);
if (state.month !== 1 || state.year !== 2027) {
  throw new Error(`Month rollover failed: ${state.month}/${state.year}`);
}
if (state.active_events.length !== 0) {
  throw new Error('Monthly events must expire when the next month begins.');
}

state = getInitialState();
for (let index = 0; index < 12; index += 1) state = advanceMonth(state);
if (state.month !== initial.month || state.year !== initial.year + 1) {
  throw new Error(`Twelve-month advance failed: ${state.month}/${state.year}`);
}

let centuryState = getInitialState();
for (let index = 0; index < 1200; index += 1) centuryState = advanceMonth(centuryState);
if (centuryState.month !== initial.month || centuryState.year !== initial.year + 100) {
  throw new Error(`Hundred-year sequential advance failed: ${centuryState.month}/${centuryState.year}`);
}

const collapsed = {
  ...getInitialState(),
  gdp: 40,
  budget: 0,
  inflation: 90,
  unemployment: 66,
  happiness: 0,
  healthcare: 0,
  active_events: ['protest', 'war', 'disaster'],
};
const collapsedHealth = assessNationHealth(collapsed);
if (collapsedHealth.level !== 'collapsed') {
  throw new Error(`Catastrophic nation must be collapsed, got ${collapsedHealth.level} (${collapsedHealth.score})`);
}

console.table([
  { case: 'initial', month: initial.month, year: initial.year, health: initialHealth.level, score: initialHealth.score },
  { case: 'after 12 months', month: state.month, year: state.year, health: assessNationHealth(state).level, score: assessNationHealth(state).score },
  { case: 'catastrophic', month: collapsed.month, year: collapsed.year, health: collapsedHealth.level, score: collapsedHealth.score },
]);
console.log('Simulation smoke test passed.');

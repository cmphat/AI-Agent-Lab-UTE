import { algorithms } from '../src/core/algorithms';
import { getInitialState } from '../src/core/state';
import { ALGORITHM_DOCS } from '../src/core/algorithmDocs';

const state = getInitialState();

if (Object.keys(ALGORITHM_DOCS).length !== Object.keys(algorithms).length) {
  throw new Error('Every algorithm must have a pseudocode document.');
}
for (const name of Object.keys(algorithms)) {
  if (!ALGORITHM_DOCS[name]) throw new Error(`${name}: missing pseudocode document`);
}
const captured = new Map<string, ReturnType<(typeof algorithms)[string]>>();

const rows = Object.entries(algorithms).map(([name, algorithm]) => {
  const first = algorithm(state, 3);
  const second = algorithm(state, 3);

  if (!Number.isFinite(first.score)) throw new Error(`${name}: score is not finite`);
  if (!Number.isFinite(first.runtimeMs)) throw new Error(`${name}: runtime is not finite`);
  if (first.nodesExpanded <= 0) throw new Error(`${name}: nodesExpanded must be positive`);
  if (first.bestPolicies.some((id) => typeof id !== 'string')) {
    throw new Error(`${name}: invalid policy path`);
  }
  if (!first.recommendedPolicyId) {
    throw new Error(`${name}: missing next-month recommendation`);
  }
  if (first.bestPolicies[0] && first.recommendedPolicyId !== first.bestPolicies[0]) {
    throw new Error(`${name}: recommendation must be the first internal plan policy`);
  }
  if (!first.planPreview || first.planPreview.length === 0) {
    throw new Error(`${name}: missing internal plan preview`);
  }
  if (first.score !== second.score || first.bestPolicies.join('|') !== second.bestPolicies.join('|')) {
    throw new Error(`${name}: algorithm is not deterministic for the same input`);
  }

  captured.set(name, first);

  return {
    algorithm: name,
    score: first.score,
    nodes: first.nodesExpanded,
    runtimeMs: first.runtimeMs,
    recommendation: first.recommendedPolicyId,
    forecastSteps: first.planPreview?.length ?? first.bestPolicies.length,
  };
});

const minimaxResult = captured.get('Minimax');
const alphaBetaResult = captured.get('Alpha-Beta');
if (!minimaxResult || !alphaBetaResult) throw new Error('Missing adversarial results');
if (minimaxResult.score !== alphaBetaResult.score) {
  throw new Error('Alpha-Beta must preserve the Minimax value');
}
if (alphaBetaResult.nodesExpanded > minimaxResult.nodesExpanded) {
  throw new Error('Alpha-Beta should not expand more nodes than Minimax');
}

console.table(rows);
console.log(`Smoke test passed for ${rows.length} algorithms.`);

import { algorithms } from '../src/core/algorithms';
import { DEFAULT_AI_SETTINGS, getAlgorithmRunLimit } from '../src/core/aiSettings';
import { POLICIES } from '../src/core/data';
import { advanceMonth, applyPolicyToState, assessNationHealth, getInitialState } from '../src/core/state';

const name = process.argv.slice(2).join(' ');
const byId = new Map(POLICIES.map((policy) => [policy.id, policy]));
let state = getInitialState();
const sequence: string[] = [];
let noActionMonths = 0;
const start = Date.now();

for (let month = 0; month < 60; month += 1) {
  const result = algorithms[name](state, getAlgorithmRunLimit(name, DEFAULT_AI_SETTINGS), DEFAULT_AI_SETTINGS);
  const policy = result.recommendedPolicyId ? byId.get(result.recommendedPolicyId) : undefined;

  if (policy && policy.cost <= state.budget) {
    sequence.push(policy.id);
    state = advanceMonth(applyPolicyToState(state, policy));
  } else {
    noActionMonths += 1;
    state = advanceMonth(state);
  }
}

const counts = sequence.reduce<Record<string, number>>((accumulator, policyId) => {
  accumulator[policyId] = (accumulator[policyId] ?? 0) + 1;
  return accumulator;
}, {});
const categoryCounts = sequence.reduce<Record<string, number>>((accumulator, policyId) => {
  const category = byId.get(policyId)?.category ?? '?';
  accumulator[category] = (accumulator[category] ?? 0) + 1;
  return accumulator;
}, {});
const reversalPairs = [
  ['tax_up', 'tax_down'],
  ['borrow', 'pay_debt'],
  ['austerity', 'welfare'],
  ['power_plant', 'green_energy'],
  ['military', 'diplomacy'],
];
let reversals = 0;
for (let index = 1; index < sequence.length; index += 1) {
  for (const [left, right] of reversalPairs) {
    if ((sequence[index - 1] === left && sequence[index] === right) || (sequence[index - 1] === right && sequence[index] === left)) {
      reversals += 1;
    }
  }
}
let maxSameRun = 0;
let currentRun = 0;
let previousPolicyId = '';
for (const policyId of sequence) {
  currentRun = policyId === previousPolicyId ? currentRun + 1 : 1;
  previousPolicyId = policyId;
  maxSameRun = Math.max(maxSameRun, currentRun);
}

const health = assessNationHealth(state);
console.log(JSON.stringify({
  name,
  ms: Date.now() - start,
  health: Number(health.score.toFixed(2)),
  level: health.level,
  groups: Object.fromEntries(Object.entries(health.groups).map(([key, value]) => [key, Number(value.toFixed(1))])),
  final: {
    gdp: Number(state.gdp.toFixed(1)),
    budget: Number(state.budget.toFixed(1)),
    debt: Number(state.debt.toFixed(1)),
    tax: Number(state.taxRate.toFixed(1)),
    infl: Number(state.inflation.toFixed(2)),
    unemp: Number(state.unemployment.toFixed(2)),
    happy: Number(state.happiness.toFixed(1)),
    edu: Number(state.education.toFixed(1)),
    healthcare: Number(state.healthcare.toFixed(1)),
    energy: Number(state.energy.toFixed(1)),
    env: Number(state.environment.toFixed(1)),
    mil: Number(state.military.toFixed(1)),
    tech: Number(state.technology.toFixed(1)),
    cyber: Number(state.cybersecurity.toFixed(1)),
    infra: Number(state.infrastructure.toFixed(1)),
    dip: Number(state.diplomacy.toFixed(1)),
  },
  actions: sequence.length,
  noActionMonths,
  unique: Object.keys(counts).length,
  maxRun: maxSameRun,
  reversals,
  counts,
  cat: categoryCounts,
  seq: sequence,
}, null, 2));

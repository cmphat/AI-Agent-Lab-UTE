import { EVENTS, POLICIES } from '../src/core/data';
import {
  advanceMonth,
  applyEventToState,
  applyPolicyToState,
  assessNationHealth,
  evaluateState,
  getAdjustedEventProbability,
  getInitialState,
  isNationCollapsed,
} from '../src/core/state';
import type { GameEvent, NationState, Policy } from '../src/core/types';

const byPolicy = new Map(POLICIES.map((p) => [p.id, p]));
const byEvent = new Map(EVENTS.map((e) => [e.id, e]));

const clone = (s: NationState): NationState => ({ ...s, active_events: [...s.active_events], recentPolicies: [...(s.recentPolicies ?? [])].slice(-6) });

const crisisState = () => {
  let s = getInitialState();
  for (const id of ['recession', 'protest']) {
    const e = byEvent.get(id)!;
    s = applyEventToState(s, e);
  }
  return s;
};

const lcg = (seed: number) => {
  let x = seed >>> 0;
  return () => {
    x = (1664525 * x + 1013904223) >>> 0;
    return x / 2 ** 32;
  };
};

const rollMonthlyEvent = (state: NationState, rng: () => number): GameEvent | null => {
  const weighted = EVENTS.map((event) => ({ event, probability: getAdjustedEventProbability(state, event) }));
  const monthlyChance = 1 - weighted.reduce((remaining, item) => remaining * (1 - item.probability), 1);
  if (rng() >= monthlyChance) return null;
  const total = weighted.reduce((sum, item) => sum + item.probability, 0);
  let ticket = rng() * total;
  for (const item of weighted) {
    ticket -= item.probability;
    if (ticket <= 0) return item.event;
  }
  return weighted.at(-1)?.event ?? null;
};

const step = (state: NationState, policy: Policy | null, rng: () => number, events = true): { state: NationState; event: string | null; policy: string | null } => {
  let s = clone(state);
  if (policy && s.budget >= policy.cost) s = applyPolicyToState(s, policy);
  s = advanceMonth(s);
  const event = events ? rollMonthlyEvent(s, rng) : null;
  if (event) s = applyEventToState(s, event);
  return { state: s, event: event?.id ?? null, policy: policy?.id ?? null };
};

const stateSummary = (s: NationState) => ({
  score: assessNationHealth(s).score,
  level: assessNationHealth(s).level,
  eval: evaluateState(s),
  gdp: +s.gdp.toFixed(1),
  budget: +s.budget.toFixed(1),
  debt: +s.debt.toFixed(1),
  tax: +s.taxRate.toFixed(1),
  infl: +s.inflation.toFixed(2),
  unemp: +s.unemployment.toFixed(2),
  happy: +s.happiness.toFixed(1),
  edu: +s.education.toFixed(1),
  health: +s.healthcare.toFixed(1),
  energy: +s.energy.toFixed(1),
  env: +s.environment.toFixed(1),
  mil: +s.military.toFixed(1),
  tech: +s.technology.toFixed(1),
  cyber: +s.cybersecurity.toFixed(1),
  infra: +s.infrastructure.toFixed(1),
  dip: +s.diplomacy.toFixed(1),
  pop: Math.round(s.population),
  events: s.active_events.join(','),
});

const eventResponsePriority: Record<string, string[]> = {
  pandemic: ['emergency_healthcare', 'health_invest', 'welfare'],
  war: ['ceasefire_negotiation', 'defense_mobilization', 'diplomacy', 'military'],
  oil_crisis: ['foreign_resource_deal', 'green_energy', 'power_plant', 'inflation_control'],
  disaster: ['disaster_reconstruction', 'transit', 'modernize'],
  cyberattack: ['cyber_incident_response', 'cybersec'],
  recession: ['economic_stimulus', 'job_program', 'business_grant', 'vocational_training'],
  protest: ['social_dialogue', 'welfare', 'stability_op'],
  climate: ['climate_adaptation', 'forest', 'emissions', 'green_energy'],
  supply_chain: ['supply_chain_stabilization', 'foreign_resource_deal', 'transit', 'inflation_control'],
};

const safePolicyLimits: Record<string, number> = {
  borrow: 1,
  tax_up: 5,
  austerity: 2,
  economic_stimulus: 2,
  social_dialogue: 2,
  emergency_healthcare: 2,
  ceasefire_negotiation: 2,
  defense_mobilization: 1,
  foreign_resource_deal: 2,
};

const strategicScore = (s: NationState) => {
  const health = assessNationHealth(s);
  const debtRatio = s.debt / Math.max(1, s.gdp);
  const extremePenalty = Math.max(0, debtRatio - 0.55) * 450 + Math.max(0, s.taxRate - 34) * 10 + Math.max(0, s.inflation - 8) * 18;
  const foundation =
    (s.education + s.healthcare + s.energy + s.environment + s.infrastructure + s.technology + s.cybersecurity + s.diplomacy + s.military) * 0.35;
  return health.score * 10 + foundation - extremePenalty - (health.level === 'collapsed' ? 100000 : 0);
};

const chooseWise = (state: NationState, history: string[]): Policy | null => {
  const counts = history.reduce<Record<string, number>>((acc, id) => ((acc[id] = (acc[id] ?? 0) + 1), acc), {});
  const active = state.active_events;
  if (active.length) {
    for (const event of active) {
      for (const id of eventResponsePriority[event] ?? []) {
        const p = byPolicy.get(id);
        if (p && p.cost <= state.budget && (counts[id] ?? 0) < (safePolicyLimits[id] ?? 99)) return p;
      }
    }
  }
  let best: { policy: Policy | null; score: number } = { policy: null, score: strategicScore(advanceMonth(state)) };
  const candidates = POLICIES.filter((p) => p.cost <= state.budget && (counts[p.id] ?? 0) < (safePolicyLimits[p.id] ?? 4));
  for (const p of candidates) {
    let after = applyPolicyToState(state, p);
    after = advanceMonth(after);
    // soft test two recovery months without more policies/events to prefer delayed sustainable recovery
    const after2 = advanceMonth(after);
    const after3 = advanceMonth(after2);
    let value = strategicScore(after) * 0.35 + strategicScore(after2) * 0.3 + strategicScore(after3) * 0.35;
    if (p.effect.debt && p.effect.debt > 0) value -= p.effect.debt * 3;
    if (p.id === 'borrow' && state.debt / Math.max(1, state.gdp) > 0.45) value -= 800;
    if (p.id === 'tax_up' && state.taxRate >= 30) value -= 600;
    if (p.id === 'tax_down' && state.taxRate <= 16) value -= 300;
    if (p.id === 'welfare' && state.happiness >= 65) value -= 150;
    if (value > best.score) best = { policy: p, score: value };
  }
  return best.policy;
};

const chooseGreedy = (state: NationState, history: string[]): Policy | null => {
  let best: { policy: Policy | null; score: number } = { policy: null, score: evaluateState(advanceMonth(state)) };
  for (const p of POLICIES.filter((p) => p.cost <= state.budget)) {
    const after = advanceMonth(applyPolicyToState(state, p));
    const score = evaluateState(after);
    if (score > best.score) best = { policy: p, score };
  }
  return best.policy;
};

const chooseNaive = (state: NationState, history: string[], rng: () => number): Policy | null => {
  const affordable = POLICIES.filter((p) => p.cost <= state.budget && !['pay_debt'].includes(p.id));
  return affordable.length ? affordable[Math.floor(rng() * affordable.length)] : null;
};

const chooseBad = (state: NationState, history: string[]): Policy | null => {
  // Bad pattern: borrow to fund repeated prestige/security moves while ignoring social/economic causes.
  const pattern = ['borrow', 'defense_mobilization', 'tax_up', 'borrow', 'austerity'];
  const id = pattern[history.length % pattern.length];
  return byPolicy.get(id) ?? null;
};

const chooseSpam = (id: string) => (state: NationState): Policy | null => byPolicy.get(id) ?? null;

type Strategy = 'wise' | 'greedy' | 'naive' | 'bad' | `spam:${string}` | 'none';

const choose = (strategy: Strategy, state: NationState, history: string[], rng: () => number): Policy | null => {
  if (strategy === 'wise') return chooseWise(state, history);
  if (strategy === 'greedy') return chooseGreedy(state, history);
  if (strategy === 'naive') return chooseNaive(state, history, rng);
  if (strategy === 'bad') return chooseBad(state, history);
  if (strategy === 'none') return null;
  if (strategy.startsWith('spam:')) return chooseSpam(strategy.slice(5))(state);
  return null;
};

const simulate = (strategy: Strategy, seed: number, months = 60, events = true) => {
  const rng = lcg(seed);
  let s = crisisState();
  const startScore = assessNationHealth(s).score;
  const history: string[] = [];
  const eventHistory: string[] = [];
  const snapshots = [clone(s)];
  let collapsedAt: number | null = null;
  for (let m = 1; m <= months; m++) {
    const policy = choose(strategy, s, history, rng);
    const res = step(s, policy, rng, events);
    if (res.policy) history.push(res.policy);
    if (res.event) eventHistory.push(res.event);
    s = res.state;
    snapshots.push(clone(s));
    if (isNationCollapsed(s)) { collapsedAt = m; break; }
  }
  return { strategy, seed, startScore, end: s, history, eventHistory, snapshots, collapsedAt };
};

const aggregate = (strategy: Strategy, seeds: number[], months = 60, events = true) => {
  const runs = seeds.map((seed) => simulate(strategy, seed, months, events));
  const scores = runs.map((r) => assessNationHealth(r.end).score);
  const evals = runs.map((r) => evaluateState(r.end));
  const collapsed = runs.filter((r) => r.collapsedAt !== null).length;
  const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
  return {
    strategy,
    n: runs.length,
    avgScore: +avg(scores).toFixed(2),
    minScore: Math.min(...scores),
    maxScore: Math.max(...scores),
    avgEval: +avg(evals).toFixed(1),
    collapsed,
    avgDebt: +avg(runs.map((r) => r.end.debt)).toFixed(1),
    avgBudget: +avg(runs.map((r) => r.end.budget)).toFixed(1),
    avgGdp: +avg(runs.map((r) => r.end.gdp)).toFixed(1),
    avgEvents: +avg(runs.map((r) => r.eventHistory.length)).toFixed(2),
    samples: runs.slice(0, 3).map((r) => ({ seed: r.seed, end: stateSummary(r.end), policies: r.history.slice(0, 12).join(' -> '), events: r.eventHistory.join(',') })),
    runs,
  };
};

const responsePolicyByEvent: Record<string, string> = {
  pandemic: 'emergency_healthcare',
  war: 'ceasefire_negotiation',
  oil_crisis: 'foreign_resource_deal',
  disaster: 'disaster_reconstruction',
  cyberattack: 'cyber_incident_response',
  recession: 'economic_stimulus',
  protest: 'social_dialogue',
  climate: 'climate_adaptation',
  supply_chain: 'supply_chain_stabilization',
};

const testRecoveryPace = () => {
  const rows: any[] = [];
  for (const [eventId, policyId] of Object.entries(responsePolicyByEvent)) {
    const event = byEvent.get(eventId)!;
    const policy = byPolicy.get(policyId)!;
    const baseline = getInitialState();
    const eventState = applyEventToState(baseline, event);
    let withPolicy = applyPolicyToState(eventState, policy);
    const afterPolicyScore = assessNationHealth(withPolicy).score;
    const scores = [assessNationHealth(eventState).score, afterPolicyScore];
    for (let i = 0; i < 4; i++) {
      withPolicy = advanceMonth(withPolicy);
      scores.push(assessNationHealth(withPolicy).score);
    }
    rows.push({ eventId, policyId, base: assessNationHealth(baseline).score, scores: scores.join(' -> '), final: stateSummary(withPolicy) });
  }
  return rows;
};

const policySpamTest = (id: string, months = 12) => {
  let s = crisisState();
  const scores = [assessNationHealth(s).score];
  for (let m = 0; m < months; m++) {
    const p = byPolicy.get(id)!;
    s = applyPolicyToState(s, p);
    s = advanceMonth(s);
    scores.push(assessNationHealth(s).score);
  }
  return { id, scores, end: stateSummary(s) };
};

const eventImpact = () => EVENTS.map((event) => {
  const base = getInitialState();
  const eventState = applyEventToState(base, event);
  const after1 = advanceMonth(eventState);
  const after2 = advanceMonth(after1);
  return {
    id: event.id,
    prob: event.probability,
    scoreBase: assessNationHealth(base).score,
    scoreEvent: assessNationHealth(eventState).score,
    scoreAfter1: assessNationHealth(after1).score,
    scoreAfter2: assessNationHealth(after2).score,
    deltaEvent: assessNationHealth(eventState).score - assessNationHealth(base).score,
    eventEffect: JSON.stringify(event.effect),
  };
});

const seeds = Array.from({ length: 40 }, (_, i) => 1000 + i * 37);
const strategies: Strategy[] = ['wise', 'greedy', 'naive', 'bad', 'none', 'spam:borrow', 'spam:tax_up', 'spam:austerity', 'spam:welfare', 'spam:economic_stimulus'];
console.log('COUNTS', { policies: POLICIES.length, events: EVENTS.length });
console.log('CRISIS_START', stateSummary(crisisState()));
console.log('5_MONTH_BAD_CHECK');
for (const st of ['bad', 'spam:borrow', 'spam:tax_up', 'spam:austerity', 'naive'] as Strategy[]) {
  const r = aggregate(st, seeds.slice(0, 20), 5, true);
  console.log(st, { avgScore: r.avgScore, minScore: r.minScore, collapsed: r.collapsed, sample: r.samples[0] });
}
console.log('60_MONTH_AGG');
for (const st of strategies) {
  const a = aggregate(st, seeds, 60, true);
  console.log(st, { avgScore: a.avgScore, minScore: a.minScore, maxScore: a.maxScore, collapsed: a.collapsed, avgEval: a.avgEval, avgEvents: a.avgEvents, avgDebt: a.avgDebt, avgBudget: a.avgBudget, avgGdp: a.avgGdp, sample: a.samples[0] });
}
console.log('RECOVERY_PACE');
console.table(testRecoveryPace());
console.log('SPAM_TESTS');
console.table(['borrow','tax_up','austerity','welfare','social_dialogue','economic_stimulus','foreign_resource_deal','cybersec','forest','diplomacy'].map((id) => policySpamTest(id, 12)));
console.log('EVENT_IMPACT');
console.table(eventImpact());

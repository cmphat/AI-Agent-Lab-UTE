@echo off
setlocal
cd /d "%~dp0"
title NEXUS Full Test

if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv 2>nul || python -m venv .venv
)
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r python_backend\requirements.txt
if not exist "node_modules\vite\bin\vite.js" call npm install

call npm run lint || goto :failed
".venv\Scripts\python.exe" -m python_backend.smoke_test || goto :failed
call npm run test:simulation || goto :failed
call npm run test:algorithms || goto :failed
call npm run build || goto :failed

echo.
echo ============================================================
echo TAT CA KIEM TRA DA DAT.
echo ============================================================
pause
exit /b 0

:failed
echo.
echo CO KIEM TRA BI LOI. XEM THONG BAO PHIA TREN.
pause
exit /b 1

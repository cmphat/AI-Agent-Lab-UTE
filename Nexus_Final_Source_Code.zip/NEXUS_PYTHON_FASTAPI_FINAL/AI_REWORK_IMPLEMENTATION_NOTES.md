# NEXUS AI Rework Implementation Notes

## Files changed
- `src/core/algorithms.ts`
- `src/core/GameProvider.tsx`

## Core changes
- Removed shared heuristic top-K policy filtering from the AI core.
- `getAvailablePolicies()` now only keeps policies that are currently affordable; it does not ban repeated policies and does not sort by a shared score.
- Removed early goal-stop behavior from the search algorithms. Algorithms now search within their own bounded limits and return their own best result/fallback.
- Added a richer `transitionCost()` separate from `policy.cost` for UCS, A*, and LRTA*.
- Kept `policy.cost` as the direct budget affordability/cost field.
- Kept raw numeric calculations in AI logic; rounding is only used for approximate cache/state bucket keys.

## Algorithm-specific implementation
- BFS/DFS/IDS: traversal order preserved, best-so-far uses `evaluateState()`.
- UCS: priority and result are based on cumulative strategic transition cost.
- Greedy Best-First: priority is `strategicDistance()` only.
- A*: uses `g + h`, where `g = transitionCost()` and `h = strategicDistance()` normalized.
- Hill Climbing: local improvement by `evaluateState()`, no frontier/random restart.
- Local Beam Search: keeps top-K states by `evaluateState()`.
- Simulated Annealing: controlled random initial plan, mutation, temperature and cooling.
- AND-OR: evaluates all policy outcomes and selects robust/worst-branch-safe actions where possible.
- Belief-State Search: creates exact/optimistic/pessimistic/hiddenRisk belief states from current state.
- LRTA*: uses persistent learned heuristic memory and learns from actual policy transitions recorded through `GameProvider`.
- Constraint Propagation: uses hard/soft constraints and constraint-first selection.
- Backtracking CSP: assigns policies month by month with forward-checking behavior.
- Min-Conflicts CSP: starts with a complete controlled-random plan and repairs conflicts.
- Minimax: MAX policy choice vs realistic state-risk-based MIN shocks.
- Alpha-Beta: same adversarial model/value as Minimax with alpha-beta pruning and move ordering.
- Expectimax: MAX policy choice with probability-normalized chance outcomes.

## Tests run
- `npm run lint` passed.
- `npm run test:algorithms` passed repeatedly for all 18 algorithms.
- `npm run test:simulation` passed.
- Additional depth sanity check passed for depths 1, 2, and 3 across all 18 algorithms.
- `npm run build` passed. Vite still shows only the existing large chunk warning.

## Notes
- Minimax, Alpha-Beta and Expectimax are capped to a smaller effective adversarial/probabilistic depth because they now consider all affordable MAX policies instead of a shared top-K branch cut.
- This keeps correctness safer under the current UI until per-algorithm Advanced Settings are added.

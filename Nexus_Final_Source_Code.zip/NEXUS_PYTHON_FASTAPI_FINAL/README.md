# AI Strategic Nation Simulator

Ứng dụng mô phỏng hỗ trợ ra quyết định chiến lược quốc gia với giao diện React + TypeScript và bộ máy 18 thuật toán AI viết bằng Python + FastAPI.

## Kiến trúc chính thức

- **Frontend:** React, TypeScript, Vite, Tailwind CSS, Recharts.
- **Python AI Engine:** FastAPI triển khai và thực thi 18 thuật toán AI.
- **Giao tiếp:** REST/JSON trên máy cục bộ (`127.0.0.1:8000`).
- **Khởi chạy Windows:** nhấp đúp `CHAY_NEXUS.bat`.

Xem hướng dẫn chi tiết tại `HUONG_DAN_CHAY_PYTHON.md`.
## Điểm nổi bật

- Giao diện song ngữ Việt/Anh, mặc định tiếng Việt.
- Light Mode và Dark Mode trên toàn bộ giao diện.
- 18 thuật toán AI có phần triển khai riêng, không dùng chung một hàm giả lập.
- Mỗi thuật toán có nút **Xem mã giả / View Pseudocode** trong Phòng chiến lược AI.
- Kết quả hiển thị điểm dự kiến, số nút mở rộng thật, thời gian chạy, độ sâu thực thi và trạng thái mục tiêu.
- Báo cáo Markdown tự đổi nội dung và tên file theo ngôn ngữ.
- Không cần API key; toàn bộ mô phỏng chạy cục bộ.

## 18 thuật toán

1. BFS
2. DFS
3. IDS
4. UCS
5. Greedy Best-First
6. A*
7. Hill Climbing
8. Local Beam Search
9. Simulated Annealing
10. AND-OR Search
11. Belief-State Search
12. LRTA*
13. Constraint Propagation + AC-3
14. Backtracking CSP
15. Min-Conflicts CSP
16. Minimax
17. Alpha-Beta
18. Expectimax

## Yêu cầu

- Node.js 18 trở lên.
- Không cần API key.
- Không cần kết nối Internet sau khi đã cài dependencies.

## Chạy project

```bash
npm install
npm run dev
```

Mở địa chỉ Vite hiển thị, thường là:

```text
http://localhost:3000
```

## Kiểm tra trước khi nộp

```bash
npm run lint
npm run test:algorithms
npm run build
```

`npm run test:algorithms` chạy đủ 18 thuật toán hai lần trên cùng trạng thái, kiểm tra:

- Điểm và runtime hợp lệ.
- Số nút mở rộng dương.
- Đường chính sách hợp lệ.
- Kết quả có tính tái lập với cùng đầu vào.
- Mỗi thuật toán đều có tài liệu mã giả.

## Cách xem mã giả

1. Mở **Phòng chiến lược AI / AI Strategy Lab**.
2. Chọn thuật toán trong danh sách.
3. Nhấn **Xem mã giả / View Pseudocode**.
4. Hộp thoại hiển thị nhóm thuật toán, cách áp dụng, độ phức tạp và mã giả Việt/Anh.

## Ghi chú hiệu năng

Các thuật toán duyệt cây được giới hạn số nút và độ sâu để trình duyệt không bị treo. Giới hạn chỉ bảo vệ giao diện; số nút hiển thị vẫn là số nút thực tế mà thuật toán đã mở rộng.

## Điều khiển thời gian

Thanh trên cùng có ba mức chạy thời gian:

- `+1 tháng`: chạy đúng một bước tháng.
- `+1 quý`: chạy tuần tự ba tháng.
- `+1 năm`: chạy tuần tự đủ mười hai tháng; mỗi tháng vẫn tính tăng trưởng, ngân sách, nợ, lạm phát, thất nghiệp, hạnh phúc, ổn định và sự kiện ngẫu nhiên.

Không có thao tác cộng thẳng năm rồi bỏ qua logic trung gian. Tất cả trạng thái tháng đều được lưu vào lịch sử và biểu đồ.

## Kiểm tra logic mô phỏng

```bash
npm run lint
npm run test:simulation
npm run test:algorithms
npm run build
```

`test:simulation` kiểm tra đổi tháng 12 sang tháng 1, chạy đủ 12 tháng, thời hạn cảnh báo sự kiện và phân loại quốc gia sụp đổ. Lựa chọn thuật toán cùng độ sâu được giữ khi chuyển trang và sau khi tải lại ứng dụng.

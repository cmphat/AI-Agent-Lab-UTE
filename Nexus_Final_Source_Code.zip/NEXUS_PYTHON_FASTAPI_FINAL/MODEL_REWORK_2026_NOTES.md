# NEXUS Model Rework Notes

This update applies the agreed model redesign:

- Removed `stability` from `NationState` and from the UI/report tables.
- Added `taxRate` as a core national metric.
- Reworked monthly budget into: tax revenue from GDP and taxRate minus operating cost.
- Operating cost now comes from national systems: education, healthcare, energy, infrastructure, cybersecurity, military and technology.
- Reworked monthly dynamics:
  - population affects unemployment and inflation pressure;
  - unemployment and inflation affect GDP growth;
  - GDP and taxRate affect budget;
  - happiness is now a small composite social score with diminishing returns for over-performing sub-metrics;
  - population growth depends mainly on healthcare, with happiness as a secondary factor.
- Foundation metrics no longer auto-change inside `advanceMonth`; policies/events change them.
- Debt no longer directly drives inflation/GDP. It now affects crisis probabilities through adjusted event probability.
- NationHealth now uses four separate groups to avoid double-counting:
  1. Economic Output
  2. Fiscal Health
  3. Social Health
  4. Pressure & Shock Safety
- `evaluateState()` now uses NationHealth as the main score, with a capped surplus bonus for over-safe national capabilities.
- Existing AI algorithms continue to call `evaluateState()`, so their scoring now follows the new health-first objective.
- LRTA* online execution behavior from the previous update is preserved.

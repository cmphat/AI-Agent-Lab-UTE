@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NEXUS Launcher

 echo ============================================================
 echo       NEXUS - React Frontend + Python FastAPI AI Engine
 echo ============================================================
 echo.

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY_CMD=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [LOI] Khong tim thay Python 3.
    echo Cai Python 3.11 tro len, tick "Add Python to PATH", roi chay lai.
    pause
    exit /b 1
  )
  set "PY_CMD=python"
)

where node >nul 2>nul
if errorlevel 1 (
  echo [LOI] Khong tim thay Node.js.
  echo Cai Node.js LTS roi chay lai file nay.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Tao moi truong Python...
  %PY_CMD% -m venv .venv
  if errorlevel 1 goto :failed
)

 echo [2/5] Kiem tra thu vien Python...
".venv\Scripts\python.exe" -c "import fastapi,uvicorn,pydantic" >nul 2>nul
if errorlevel 1 (
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r python_backend\requirements.txt
  if errorlevel 1 goto :failed
)

if not exist "node_modules\vite\bin\vite.js" (
  echo [3/5] Cai thu vien giao dien...
  call npm install
  if errorlevel 1 goto :failed
) else (
  echo [3/5] Thu vien giao dien da san sang.
)

 echo [4/5] Khoi dong Python AI Engine...
start "NEXUS PYTHON AI ENGINE" /min ".venv\Scripts\python.exe" -m uvicorn python_backend.app:app --host 127.0.0.1 --port 8000

 echo Dang doi Python AI Engine...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ready=$false; for($i=0;$i -lt 40;$i++){ try { $r=Invoke-RestMethod 'http://127.0.0.1:8000/api/health' -TimeoutSec 1; if($r.status -eq 'ok'){ $ready=$true; break } } catch {}; Start-Sleep -Milliseconds 250 }; if(-not $ready){ exit 1 }"
if errorlevel 1 (
  echo [LOI] Python AI Engine khong khoi dong duoc.
  echo Thu chay: .venv\Scripts\python.exe -m uvicorn python_backend.app:app --port 8000
  pause
  exit /b 1
)

 echo [5/5] Khoi dong giao dien NEXUS...
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://127.0.0.1:3000'"
echo.
echo NEXUS dang chay:
echo   Giao dien: http://127.0.0.1:3000
echo   Python AI: http://127.0.0.1:8000/api/health
echo.
echo Giu cua so nay mo. Nhan Ctrl+C de dung giao dien.
echo.
call npm run dev

 echo Dang tat Python AI Engine...
taskkill /FI "WINDOWTITLE eq NEXUS PYTHON AI ENGINE*" /T /F >nul 2>nul
exit /b 0

:failed
echo.
echo [LOI] Qua trinh cai dat/khoi dong that bai.
pause
exit /b 1

# UI AI Settings Rework Notes

## Why this patch exists
The previous AI core patch changed algorithm internals, but the app UI still exposed the old shared `analysisDepth` / “Độ sâu dự báo” slider in AI Lab. That made the app look almost unchanged and also conflicted with the design decision that each algorithm should have its own calculation meaning.

## What changed
- Removed the shared AI Lab prediction-depth slider.
- Removed `analysisDepth` / `setAnalysisDepth` from `GameProvider` context.
- Added `src/core/aiSettings.ts` with per-algorithm-group settings.
- AI Lab now reads the selected algorithm’s own setting and shows it as “Thiết lập đang dùng”.
- Settings page now has an “Cài đặt nâng cao AI” section.
- Added controls for:
  - BFS / DFS / IDS search months
  - UCS / Greedy / A* calculation months
  - Hill / Beam local steps
  - Local Beam width
  - Simulated Annealing iterations
  - AND-OR robust months
  - Belief-State belief months
  - LRTA* learning months
  - CSP group variables/months
  - Minimax / Alpha-Beta adversarial turns
  - Expectimax chance turns
  - Max MIN shocks
  - CSP strictness
  - LRTA* memory mode
- LRTA* memory mode is now wired into policy execution and online execution.
- Added a reset button for AI defaults, which also clears LRTA* persistent heuristic memory.

## Tests run
- `npm run lint` passed.
- `npm run test:algorithms` passed for all 18 algorithms.
- `npm run test:simulation` passed.
- `npm run build` passed.

## Remaining warning
Vite still warns that the bundled JS chunk is larger than 500 kB. This is a build-size warning, not a TypeScript or runtime build failure.

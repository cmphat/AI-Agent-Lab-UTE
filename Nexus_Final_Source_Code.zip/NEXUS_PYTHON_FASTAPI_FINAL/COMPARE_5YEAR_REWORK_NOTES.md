# Compare Page 5-Year Rework

## Mục tiêu

Trang **So sánh thuật toán** không còn chỉ chạy mỗi thuật toán một lần để lấy khuyến nghị tháng sau. Chức năng mới chạy đủ 18 thuật toán như 18 chiến lược độc lập trong 5 năm, bắt đầu từ đúng trạng thái quốc gia hiện tại.

## Cách chạy mới

Với từng thuật toán:

1. Sao chép trạng thái hiện tại làm trạng thái bắt đầu riêng.
2. Lặp 60 tháng.
3. Ở mỗi tháng, gọi thuật toán trên trạng thái mô phỏng hiện tại.
4. Lấy `recommendedPolicyId` làm chính sách của tháng đó.
5. Nếu có chính sách hợp lệ và đủ ngân sách thì áp dụng chính sách.
6. Tua đúng 1 tháng bằng `advanceMonth()`.
7. Ghi lại thời gian chạy, số nút mở rộng, điểm quốc gia và độ ổn định.

So sánh này không sinh sự kiện ngẫu nhiên mới để giữ công bằng giữa các thuật toán.

## Các chỉ số được ghi nhận

- Tổng thời gian chờ: tổng `runtimeMs` của 60 lần gọi thuật toán.
- Không gian đã mở rộng: tổng `nodesExpanded` của 60 lần gọi thuật toán.
- Điểm quốc gia năm thứ 5: `evaluateState()` tại trạng thái cuối.
- Độ lệch ổn định trung bình theo tháng: trung bình `abs(stability[t] - stability[t-1])` với stability lấy từ `assessNationHealth().score`.
- Độ ổn định năm thứ 5.
- Độ ổn định thấp nhất trong 5 năm.
- Mức rơi ổn định mạnh nhất trong một tháng.
- Độ đa dạng chính sách: số chính sách khác nhau / số tháng có ban hành chính sách.
- Số tháng tạm hoãn chính sách mới.
- Các chính sách được dùng nhiều nhất.
- Trạng thái hoàn tất hoặc tháng sụp đổ nếu có.

## File đã sửa

- `src/pages/Compare.tsx`
- `src/core/LanguageProvider.tsx`

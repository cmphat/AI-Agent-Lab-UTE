from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from puzzle8.ui.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("8 Puzzle AI Lab")
    app.setOrganizationName("AI-Agent-Lab-UTE")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())

# 8 Puzzle

> Bản song ngữ Việt/Anh, có thanh cuộn dọc riêng cho khu vực biểu đồ để phần nhận xét không che nhãn thuật toán. — Trực quan hóa thuật toán

> Ứng dụng desktop Python dùng để học, chạy từng bước và so sánh 18 thuật toán trên bài toán 8-puzzle.

**GitHub dùng trong báo cáo:** https://github.com/cmphat/AI-Agent-Lab-UTE



## Chuyển đổi ngôn ngữ

Giao diện hỗ trợ hai ngôn ngữ **Tiếng Việt / English**. Nút chuyển ngôn ngữ nằm trên thanh công cụ, ngay cạnh nút Sáng/Tối. Lựa chọn được lưu bằng `QSettings`, vì vậy ứng dụng sẽ ghi nhớ ngôn ngữ ở lần mở tiếp theo. Việc chuyển đổi không làm mất trạng thái START, GOAL, kết quả chạy, lịch sử hay dữ liệu so sánh.

## Giao diện

![Tổng quan](docs/screenshots/overview.png)

![Phòng thí nghiệm A*](docs/screenshots/lab_astar.png)

![So sánh bằng biểu đồ cột](docs/screenshots/compare_bar.png)

![So sánh bằng biểu đồ phân tán](docs/screenshots/compare_scatter.png)

## Điểm nổi bật

- Toàn bộ **18 thuật toán được cài đặt bằng Python**.
- Giao diện desktop gọn, cân bằng màu sắc và chia chức năng rõ ràng bằng **PySide6**. Phong cách dùng màu trầm, khoảng trắng và điểm nhấn nhỏ để giữ cảm giác của một công cụ học tập do sinh viên xây dựng.
- Sidebar chia rõ Tổng quan, Phòng thí nghiệm, Mã giả, So sánh, Lịch sử và PEAS/Báo cáo.
- Nhập trực tiếp START và GOAL hoặc chọn preset.
- Kiểm tra trạng thái có lời giải bằng parity số nghịch thế.
- Tám ô số có bảng màu riêng, nhất quán giữa START, GOAL và hoạt ảnh để dễ theo dõi.
- Hoạt ảnh có phát, tạm dừng, tiến, lùi và chỉnh tốc độ. Ô số được trượt thực sự từ vị trí cũ sang vị trí mới bằng easing ngắn, không dùng hiệu ứng neon hoặc chuyển cảnh phô trương.
- Hiển thị solution path, số bước, node mở rộng, node sinh, frontier lớn nhất và thời gian.
- Nhật ký chi tiết theo từng pha với `g(n)`, `h(n)`, `f(n)` và ghi chú quyết định.
- Mã giả, độ phức tạp, ưu điểm, hạn chế và ghi chú áp dụng cho từng thuật toán.
- So sánh tối đa ba thuật toán trên cùng điều kiện bằng bảng và **4 loại biểu đồ**: cột, đường, tròn và phân tán.
- Chọn linh hoạt chỉ số cần trực quan hóa: node mở rộng, node sinh, frontier lớn nhất, thời gian và số bước lời giải.
- Biểu đồ phân tán cho phép chọn riêng trục X và trục Y để quan sát mối quan hệ giữa chi phí tìm kiếm và thời gian.
- Tự động tổng hợp thuật toán nhanh nhất, ít node nhất, lời giải ngắn nhất và tỷ lệ thành công.
- Có thể lưu trực tiếp biểu đồ dưới dạng PNG để đưa vào báo cáo cá nhân.
- Lưu lịch sử chạy trong phiên; xuất HTML, CSV và JSON.
- Trang PEAS và checklist đối chiếu trực tiếp yêu cầu báo cáo cá nhân.

## 18 thuật toán

| Nhóm | Thuật toán |
|---|---|
| Tìm kiếm mù thông tin | BFS, DFS, IDS |
| Tìm kiếm có thông tin | UCS, Greedy Best-First, A* |
| Tìm kiếm cục bộ | Hill Climbing, Local Beam Search, Simulated Annealing |
| Môi trường phức tạp | AND-OR Graph Search, Belief-State Search, LRTA* |
| Thỏa mãn ràng buộc | Constraint Propagation (AC-3), Backtracking CSP, Min-Conflicts CSP |
| Tìm kiếm đối kháng | Minimax, Alpha-Beta Pruning, Expectimax |

Chi tiết cách ánh xạ các thuật toán không tự nhiên đối với 8-puzzle nằm tại [docs/ALGORITHM_MAPPING.md](docs/ALGORITHM_MAPPING.md).

## Kiến trúc

```text
main.py
  └── puzzle8.ui.main_window.MainWindow
        ├── Algorithm Lab
        ├── Pseudocode Library
        ├── Comparison Dashboard
        ├── Run History
        └── PEAS & HTML Report

puzzle8.algorithms.registry
  ├── classical.py      # BFS, DFS, IDS, UCS, Greedy, A*
  ├── local_search.py   # Hill, Beam, SA
  ├── complex_env.py    # AND-OR, Belief-State, LRTA*
  ├── csp.py            # AC-3, Backtracking, Min-Conflicts
  └── adversarial.py    # Minimax, Alpha-Beta, Expectimax
```

## Cài đặt và chạy

### Cách 1 — Windows

Giải nén project và nhấp đúp:

```text
CHAY_8_PUZZLE.bat
```

Lần đầu file BAT sẽ tạo `.venv` và cài PySide6.

### Cách 2 — Terminal

```powershell
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe main.py
```

Hoặc:

```powershell
python -m pip install -r requirements.txt
python main.py
```

Yêu cầu: Python 3.11 trở lên.

## Cách demo trước giảng viên

1. Mở **Phòng thí nghiệm**.
2. Giữ preset `Mẫu môn học (5 bước)` để cả 18 thuật toán có thể minh họa nhanh.
3. Chọn A* và bấm **Chạy thuật toán**.
4. Giải thích `g(n)`, `h(n)`, `f(n)` trong tab Nhật ký.
5. Mở tab Mã giả và đối chiếu với trace.
6. Chuyển sang **So sánh**, chọn BFS, A* và Local Beam.
7. Chạy so sánh, đổi giữa biểu đồ cột, đường, tròn và phân tán; thử đổi chỉ số và lưu PNG.
8. Mở **PEAS & Báo cáo**, xuất báo cáo HTML của thuật toán vừa chạy.
9. Mở GitHub ngay từ nút trên sidebar.

## Kiểm thử

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q
python scripts\benchmark_all.py
```

Hoặc nhấp đúp `KIEM_TRA_8_PUZZLE.bat` sau khi đã cài pytest.

Bộ test kiểm tra:

- Registry có đúng 18 thuật toán.
- Preset môn học có lời giải.
- Cả 18 thuật toán đều chạy thành công trên preset mặc định.
- BFS, UCS, A* và IDS trả lời giải 5 bước.
- Mọi solution path đều là chuỗi hành động hợp lệ từ START tới GOAL.

## Lưu ý học thuật

BFS, DFS, IDS, UCS, Greedy, A*, Hill Climbing, Local Beam, Simulated Annealing và LRTA* có thể áp dụng trực tiếp hoặc gần trực tiếp cho 8-puzzle.

CSP được mô hình bằng chuỗi biến trạng thái `X0..Xd`. AND-OR, Belief-State và nhóm đối kháng được triển khai dưới dạng **mô hình giáo dục có giải thích rõ**, vì 8-puzzle chuẩn là môi trường xác định, quan sát đầy đủ và đơn tác tử. Ứng dụng không che giấu điểm này; phần giao diện, mã giả và tài liệu đều nêu rõ giả định mô hình.

## Cấu trúc repository

```text
8_Puzzle_Source_Code/
├── main.py
├── README.md
├── requirements.txt
├── pyproject.toml
├── CHAY_8_PUZZLE.bat
├── KIEM_TRA_8_PUZZLE.bat
├── puzzle8/
│   ├── core.py
│   ├── reporting.py
│   ├── algorithms/
│   └── ui/
├── scripts/
│   └── benchmark_all.py
├── tests/
│   └── test_algorithms.py
└── docs/
    ├── ALGORITHM_MAPPING.md
    └── BAO_CAO_CA_NHAN_GOI_Y.md
```

## Nộp bài

Nên upload **toàn bộ source đã giải nén** lên GitHub, không chỉ upload một file ZIP. Không upload `.venv`, `__pycache__` hoặc thư mục build. File `.gitignore` đã được chuẩn bị sẵn.

## Tác giả và mục đích

Sản phẩm được xây dựng cho bài báo cáo cá nhân học phần Trí tuệ nhân tạo, tập trung vào khả năng hiểu thuật toán, chạy tay, quan sát quá trình tìm kiếm và tái lập thực nghiệm.

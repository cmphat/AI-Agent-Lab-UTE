@echo off
setlocal
cd /d "%~dp0"
title 8 Puzzle

where py >nul 2>nul
if %errorlevel%==0 (
    set PYTHON=py -3
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo [LOI] Khong tim thay Python.
        echo Hay cai Python 3.11+ va chon Add Python to PATH.
        pause
        exit /b 1
    )
    set PYTHON=python
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Dang tao moi truong Python...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto :error
)

echo [2/3] Dang kiem tra PySide6...
.venv\Scripts\python.exe -c "import PySide6" >nul 2>nul
if errorlevel 1 (
    echo Dang cai thu vien lan dau. Vui long doi...
    .venv\Scripts\python.exe -m pip install --upgrade pip
    .venv\Scripts\python.exe -m pip install -r requirements.txt
    if errorlevel 1 goto :error
)

echo [3/3] Khoi dong 8 Puzzle...
.venv\Scripts\python.exe main.py
if errorlevel 1 goto :error
exit /b 0

:error
echo.
echo [LOI] Chuong trinh khong khoi dong thanh cong.
echo Thu chay thu cong:
echo   python -m pip install -r requirements.txt
echo   python main.py
pause
exit /b 1

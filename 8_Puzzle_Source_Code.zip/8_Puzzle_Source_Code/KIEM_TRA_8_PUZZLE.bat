@echo off
setlocal
cd /d "%~dp0"
title Kiem tra 8 Puzzle AI Lab

where py >nul 2>nul
if %errorlevel%==0 (
  set PYTHON=py -3
) else (
  set PYTHON=python
)

%PYTHON% -m compileall -q .
if errorlevel 1 goto :error

set PYTHONPATH=%CD%
%PYTHON% -m pytest -q
if errorlevel 1 goto :error

%PYTHON% scripts\benchmark_all.py
if errorlevel 1 goto :error

echo.
echo TAT CA KIEM TRA DA DAT.
pause
exit /b 0

:error
echo.
echo CO LOI TRONG QUA TRINH KIEM TRA.
pause
exit /b 1

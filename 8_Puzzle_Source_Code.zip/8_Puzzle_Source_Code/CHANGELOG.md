# Changelog

## Bilingual + Chart Scroll Fix

- Giữ nút chuyển **Tiếng Việt / English** cạnh nút sáng tối.
- Thêm thanh cuộn dọc riêng cho khu vực biểu đồ so sánh.
- Đưa nút lưu PNG lên hàng tiêu đề của khung trực quan hóa.
- Đưa nhận xét vào thẻ riêng bên dưới biểu đồ, không che tên thuật toán.
- Giữ nguyên 18 thuật toán, sidebar, animation, lịch sử và chức năng xuất dữ liệu.

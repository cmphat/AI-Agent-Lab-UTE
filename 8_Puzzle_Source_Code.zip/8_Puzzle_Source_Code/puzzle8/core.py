from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Iterable, Iterator, Mapping, Sequence
import json
import random

State = tuple[int, ...]
Action = str
ACTIONS: tuple[Action, ...] = ("U", "D", "L", "R")
ACTION_LABELS = {"U": "Lên", "D": "Xuống", "L": "Trái", "R": "Phải"}

DEFAULT_START: State = (2, 8, 3, 1, 6, 4, 7, 0, 5)
DEFAULT_GOAL: State = (1, 2, 3, 8, 0, 4, 7, 6, 5)
STANDARD_GOAL: State = (1, 2, 3, 4, 5, 6, 7, 8, 0)


@dataclass(slots=True)
class SearchStep:
    index: int
    state: State
    action: Action | None = None
    depth: int = 0
    g: float | None = None
    h: float | None = None
    f: float | None = None
    frontier: int = 0
    explored: int = 0
    phase: str = "EXPAND"
    note: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["state"] = list(self.state)
        return payload


@dataclass(slots=True)
class SearchResult:
    algorithm_id: str
    algorithm_name: str
    category: str
    success: bool
    start: State
    goal: State
    path: list[Action]
    states: list[State]
    steps: list[SearchStep]
    expanded: int
    generated: int
    max_frontier: int
    elapsed_ms: float
    message: str = ""
    score: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def solution_depth(self) -> int:
        return max(0, len(self.states) - 1)

    def to_dict(self) -> dict[str, Any]:
        return {
            "algorithm_id": self.algorithm_id,
            "algorithm_name": self.algorithm_name,
            "category": self.category,
            "success": self.success,
            "start": list(self.start),
            "goal": list(self.goal),
            "path": self.path,
            "states": [list(s) for s in self.states],
            "steps": [s.to_dict() for s in self.steps],
            "expanded": self.expanded,
            "generated": self.generated,
            "max_frontier": self.max_frontier,
            "elapsed_ms": self.elapsed_ms,
            "message": self.message,
            "score": self.score,
            "metadata": self.metadata,
        }

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)


@dataclass(frozen=True, slots=True)
class AlgorithmInfo:
    id: str
    name: str
    short_name: str
    category: str
    description: str
    strengths: str
    limitations: str
    complete: str
    optimal: str
    time_complexity: str
    space_complexity: str
    pseudocode: str
    adaptation_note: str = ""


def validate_state(state: Sequence[int]) -> State:
    values = tuple(int(x) for x in state)
    if len(values) != 9 or sorted(values) != list(range(9)):
        raise ValueError("Trạng thái phải chứa đủ các số từ 0 đến 8, mỗi số đúng một lần.")
    return values


def state_rows(state: State) -> tuple[tuple[int, int, int], ...]:
    return tuple(tuple(state[i : i + 3]) for i in range(0, 9, 3))


def state_text(state: State) -> str:
    return " / ".join(" ".join("_" if x == 0 else str(x) for x in row) for row in state_rows(state))


def state_key(state: State) -> str:
    return "".join(str(x) for x in state)


def inversions(state: State) -> int:
    values = [x for x in state if x != 0]
    return sum(values[i] > values[j] for i in range(len(values)) for j in range(i + 1, len(values)))


def is_solvable(start: State, goal: State) -> bool:
    return inversions(start) % 2 == inversions(goal) % 2


def legal_actions(state: State) -> list[Action]:
    z = state.index(0)
    r, c = divmod(z, 3)
    actions: list[Action] = []
    if r > 0:
        actions.append("U")
    if r < 2:
        actions.append("D")
    if c > 0:
        actions.append("L")
    if c < 2:
        actions.append("R")
    return actions


def apply_action(state: State, action: Action, *, illegal_noop: bool = False) -> State | None:
    z = state.index(0)
    r, c = divmod(z, 3)
    delta = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}.get(action)
    if delta is None:
        raise ValueError(f"Hành động không hợp lệ: {action}")
    nr, nc = r + delta[0], c + delta[1]
    if not (0 <= nr < 3 and 0 <= nc < 3):
        return state if illegal_noop else None
    nz = nr * 3 + nc
    values = list(state)
    values[z], values[nz] = values[nz], values[z]
    return tuple(values)


def neighbors(state: State, action_order: Iterable[Action] = ACTIONS) -> Iterator[tuple[State, Action]]:
    for action in action_order:
        nxt = apply_action(state, action)
        if nxt is not None:
            yield nxt, action


def manhattan(state: State, goal: State) -> int:
    positions = {value: index for index, value in enumerate(goal)}
    total = 0
    for index, value in enumerate(state):
        if value == 0:
            continue
        target = positions[value]
        total += abs(index // 3 - target // 3) + abs(index % 3 - target % 3)
    return total


def misplaced(state: State, goal: State) -> int:
    return sum(1 for i, value in enumerate(state) if value != 0 and value != goal[i])


def linear_conflict(state: State, goal: State) -> int:
    """Manhattan + linear conflict, vẫn admissible cho 8-puzzle."""
    base = manhattan(state, goal)
    goal_pos = {v: i for i, v in enumerate(goal)}
    conflicts = 0

    for row in range(3):
        tiles = [state[row * 3 + col] for col in range(3)]
        candidates = [v for v in tiles if v and goal_pos[v] // 3 == row]
        for i in range(len(candidates)):
            for j in range(i + 1, len(candidates)):
                if goal_pos[candidates[i]] % 3 > goal_pos[candidates[j]] % 3:
                    conflicts += 1

    for col in range(3):
        tiles = [state[row * 3 + col] for row in range(3)]
        candidates = [v for v in tiles if v and goal_pos[v] % 3 == col]
        for i in range(len(candidates)):
            for j in range(i + 1, len(candidates)):
                if goal_pos[candidates[i]] // 3 > goal_pos[candidates[j]] // 3:
                    conflicts += 1

    return base + 2 * conflicts


def reconstruct_path(
    parent: Mapping[State, tuple[State | None, Action | None]], goal: State
) -> tuple[list[Action], list[State]]:
    actions: list[Action] = []
    states: list[State] = []
    current: State | None = goal
    while current is not None:
        states.append(current)
        previous, action = parent[current]
        if action is not None:
            actions.append(action)
        current = previous
    actions.reverse()
    states.reverse()
    return actions, states


def replay_actions(start: State, actions: Sequence[Action], *, illegal_noop: bool = False) -> list[State]:
    states = [start]
    current = start
    for action in actions:
        nxt = apply_action(current, action, illegal_noop=illegal_noop)
        if nxt is None:
            raise ValueError(f"Hành động {action} không hợp lệ tại trạng thái {current}")
        current = nxt
        states.append(current)
    return states


def scramble_from(goal: State, moves: int, *, seed: int | None = None) -> State:
    rng = random.Random(seed)
    current = goal
    previous: State | None = None
    for _ in range(max(1, moves)):
        options = [(s, a) for s, a in neighbors(current) if s != previous]
        nxt, _ = rng.choice(options)
        previous, current = current, nxt
    return current


def random_solvable(goal: State, *, moves: int = 20, seed: int | None = None) -> State:
    return scramble_from(goal, moves=moves, seed=seed)


def path_cost(actions: Sequence[Action]) -> int:
    return len(actions)

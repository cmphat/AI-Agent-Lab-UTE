from __future__ import annotations

import csv
import json
from datetime import datetime
from html import escape
from pathlib import Path

from puzzle8.algorithms.metadata import ALGORITHM_INFOS
from puzzle8.core import ACTION_LABELS, SearchResult, state_rows


def _board_html(state):
    cells = []
    for value in state:
        cls = " blank" if value == 0 else ""
        cells.append(f'<div class="tile{cls}">{"" if value == 0 else value}</div>')
    return '<div class="board">' + "".join(cells) + "</div>"


def export_result_html(result: SearchResult, path: str | Path) -> Path:
    """Export one run as a printable, academic-looking HTML report."""

    path = Path(path)
    info = ALGORITHM_INFOS[result.algorithm_id]

    state_rows_html = []
    for index, state in enumerate(result.states):
        move = "START" if index == 0 else ACTION_LABELS.get(result.path[index - 1], result.path[index - 1])
        state_rows_html.append(
            f"<tr><td>{index}</td><td>{escape(move)}</td><td><code>{escape(str(state_rows(state)))}</code></td></tr>"
        )

    trace_rows = []
    for step in result.steps[:500]:
        trace_rows.append(
            "<tr>"
            f"<td>{step.index}</td><td>{escape(step.phase)}</td><td>{escape(step.action or '')}</td>"
            f"<td>{step.depth}</td><td>{'' if step.g is None else step.g}</td>"
            f"<td>{'' if step.h is None else step.h}</td><td>{'' if step.f is None else step.f}</td>"
            f"<td>{escape(step.note)}</td></tr>"
        )

    readable_path = " → ".join(ACTION_LABELS.get(action, action) for action in result.path) or "Không có"
    status = "Thành công" if result.success else "Chưa đạt đích"

    html = f"""<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<title>Báo cáo {escape(result.algorithm_name)}</title>
<style>
@page {{ size: A4; margin: 18mm; }}
body {{ font-family: "Segoe UI", Arial, sans-serif; color: #20242a; margin: 0; background: #f2f3f5; line-height: 1.5; }}
.report {{ max-width: 1000px; margin: 28px auto; padding: 42px 48px; background: #fff; border: 1px solid #d9dde3; }}
.header {{ border-bottom: 2px solid #2f6fed; padding-bottom: 16px; margin-bottom: 26px; }}
.kicker {{ color: #59616d; font-size: 13px; text-transform: uppercase; letter-spacing: .08em; }}
h1 {{ margin: 5px 0 2px; font-size: 30px; }}
h2 {{ margin-top: 30px; padding-bottom: 6px; border-bottom: 1px solid #dfe3e8; font-size: 20px; }}
h3 {{ margin-bottom: 7px; }}
.meta {{ color: #6a7280; }}
.summary {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 18px 0; }}
.metric {{ border: 1px solid #d9dde3; padding: 12px; }}
.metric b {{ display: block; color: #6a7280; font-size: 12px; margin-bottom: 4px; }}
.states {{ display: flex; gap: 46px; flex-wrap: wrap; align-items: flex-start; }}
.board {{ display: grid; grid-template-columns: repeat(3, 54px); gap: 5px; margin-top: 8px; }}
.tile {{ height: 54px; display: flex; align-items: center; justify-content: center; background: #eef2f8; border: 1px solid #aeb7c4; border-radius: 5px; font-size: 21px; font-weight: 700; }}
.blank {{ background: #fafbfc; border-style: dashed; }}
table {{ width: 100%; border-collapse: collapse; margin: 10px 0 18px; font-size: 13px; }}
th, td {{ border: 1px solid #dfe3e8; padding: 7px 8px; text-align: left; vertical-align: top; }}
th {{ background: #f3f5f7; font-weight: 650; }}
pre {{ white-space: pre-wrap; background: #f5f6f8; border: 1px solid #d9dde3; padding: 16px; overflow-wrap: anywhere; }}
code {{ font-family: Consolas, monospace; }}
.note {{ background: #f6f8fc; border-left: 3px solid #2f6fed; padding: 10px 12px; }}
@media print {{ body {{ background: white; }} .report {{ margin: 0; border: 0; padding: 0; }} }}
</style>
</head>
<body>
<main class="report">
<header class="header">
<div class="kicker">8 Puzzle · Báo cáo thực nghiệm cá nhân</div>
<h1>{escape(result.algorithm_name)}</h1>
<div class="meta">{escape(info.category)} · {datetime.now().strftime('%d/%m/%Y %H:%M')}</div>
</header>

<h2>1. Bài toán và trạng thái</h2>
<div class="states"><div><h3>START</h3>{_board_html(result.start)}</div><div><h3>GOAL</h3>{_board_html(result.goal)}</div></div>

<h2>2. Kết quả thực thi</h2>
<div class="summary">
<div class="metric"><b>Trạng thái</b>{status}</div>
<div class="metric"><b>Số bước</b>{result.solution_depth}</div>
<div class="metric"><b>Node mở rộng</b>{result.expanded}</div>
<div class="metric"><b>Thời gian</b>{result.elapsed_ms:.3f} ms</div>
</div>
<p><b>Thông báo:</b> {escape(result.message)}</p>
<p><b>Chuỗi hành động:</b> {escape(readable_path)}</p>

<h2>3. Phân tích thuật toán</h2>
<p>{escape(info.description)}</p>
<p><b>Ưu điểm:</b> {escape(info.strengths)}</p>
<p><b>Hạn chế:</b> {escape(info.limitations)}</p>
<p><b>Đầy đủ:</b> {escape(info.complete)} &nbsp;·&nbsp; <b>Tối ưu:</b> {escape(info.optimal)}</p>
<p><b>Độ phức tạp:</b> Time {escape(info.time_complexity)} &nbsp;·&nbsp; Space {escape(info.space_complexity)}</p>
{f'<p class="note"><b>Ghi chú áp dụng:</b> {escape(info.adaptation_note)}</p>' if info.adaptation_note else ''}

<h2>4. Mã giả</h2>
<pre>{escape(info.pseudocode)}</pre>

<h2>5. Các bước của lời giải</h2>
<table><tr><th>Bước</th><th>Hành động</th><th>Trạng thái</th></tr>{''.join(state_rows_html)}</table>

<h2>6. Nhật ký tìm kiếm</h2>
<table><tr><th>#</th><th>Pha</th><th>Action</th><th>Depth</th><th>g</th><th>h</th><th>f</th><th>Ghi chú</th></tr>{''.join(trace_rows)}</table>

<h2>7. Kết luận</h2>
<p>Kết quả trên được tạo trực tiếp bởi mã nguồn Python của chương trình 8 Puzzle AI Lab. Dữ liệu thể hiện trạng thái ban đầu, trạng thái mục tiêu, chuỗi hành động, quá trình tìm kiếm và các chỉ số thực nghiệm của thuật toán.</p>
</main>
</body>
</html>"""
    path.write_text(html, encoding="utf-8")
    return path


def export_results_json(results: list[SearchResult], path: str | Path) -> Path:
    path = Path(path)
    path.write_text(
        json.dumps([result.to_dict() for result in results], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return path


def export_results_csv(results: list[SearchResult], path: str | Path) -> Path:
    path = Path(path)
    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        writer.writerow(
            [
                "algorithm",
                "category",
                "success",
                "steps",
                "expanded",
                "generated",
                "max_frontier",
                "elapsed_ms",
                "path",
            ]
        )
        for result in results:
            writer.writerow(
                [
                    result.algorithm_name,
                    result.category,
                    result.success,
                    result.solution_depth,
                    result.expanded,
                    result.generated,
                    result.max_frontier,
                    f"{result.elapsed_ms:.3f}",
                    " ".join(result.path),
                ]
            )
    return path

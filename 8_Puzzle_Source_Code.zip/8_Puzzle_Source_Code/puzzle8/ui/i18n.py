from __future__ import annotations

import re
from typing import Iterable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QGroupBox,
    QLabel,
    QLineEdit,
    QListWidget,
    QMainWindow,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QTabWidget,
    QTableWidget,
    QTextBrowser,
    QWidget,
)

LANG_VI = "vi"
LANG_EN = "en"
SOURCE_ROLE = int(Qt.ItemDataRole.UserRole) + 117

CATEGORY_EN = {
    "Tìm kiếm mù thông tin": "Uninformed search",
    "Tìm kiếm có thông tin": "Informed search",
    "Tìm kiếm cục bộ": "Local search",
    "Môi trường phức tạp": "Complex environments",
    "Bài toán thỏa mãn ràng buộc": "Constraint satisfaction",
    "Tìm kiếm đối kháng": "Adversarial search",
}

# Hand-written English descriptions keep the bilingual mode natural and avoid the
# mechanical tone produced by word-for-word translation.
ALGORITHM_EN: dict[str, dict[str, str]] = {
    "bfs": {
        "description": "Expands every state level by level using a FIFO queue.",
        "strengths": "Complete; optimal when every move has the same cost; easy to visualize.",
        "limitations": "Uses a large amount of memory when the state space grows.",
        "complete": "Yes",
        "optimal": "Yes, when step costs are equal",
    },
    "dfs": {
        "description": "Explores one branch deeply before backtracking, using a LIFO stack.",
        "strengths": "Low memory usage; simple to implement; may reach deep solutions quickly.",
        "limitations": "Not optimal and may spend time in a very deep branch or loop.",
        "complete": "Yes with a depth limit and cycle checking",
        "optimal": "No",
    },
    "ids": {
        "description": "Repeats depth-limited search with limits 0, 1, 2, and so on.",
        "strengths": "Complete like BFS while using memory close to DFS.",
        "limitations": "Shallow levels are expanded repeatedly.",
        "complete": "Yes",
        "optimal": "Yes, when step costs are equal",
    },
    "ucs": {
        "description": "Always expands the state with the smallest path cost g(n).",
        "strengths": "Complete and optimal for positive step costs.",
        "limitations": "Does not use a heuristic and may expand many nodes.",
        "complete": "Yes",
        "optimal": "Yes",
    },
    "greedy": {
        "description": "Prioritizes the state with the smallest heuristic value h(n).",
        "strengths": "Often finds a solution quickly when the heuristic is informative.",
        "limitations": "Not guaranteed to be optimal and can be misled by the heuristic.",
        "complete": "Yes in a finite graph with cycle checking",
        "optimal": "No",
    },
    "astar": {
        "description": "Combines path cost g(n) and estimated remaining cost h(n): f(n)=g(n)+h(n).",
        "strengths": "Complete and optimal with an admissible and consistent heuristic.",
        "limitations": "May require substantial memory.",
        "complete": "Yes",
        "optimal": "Yes with a suitable heuristic",
    },
    "hill": {
        "description": "Moves to the best neighboring state and continues only when it improves the heuristic.",
        "strengths": "Fast and memory efficient.",
        "limitations": "Can get stuck at local optima, plateaus, or ridges.",
        "complete": "No",
        "optimal": "No",
    },
    "beam": {
        "description": "Keeps the best k states and generates the next layer from the whole beam.",
        "strengths": "Explores more alternatives than hill climbing.",
        "limitations": "Beams may converge to the same region; optimality is not guaranteed.",
        "complete": "No",
        "optimal": "No",
    },
    "sa": {
        "description": "Occasionally accepts a worse move with probability exp(-Δ/T) to escape local optima.",
        "strengths": "Can escape local optima and uses little memory.",
        "limitations": "Sensitive to the cooling schedule and random seed.",
        "complete": "No in finite time",
        "optimal": "Asymptotically under ideal conditions",
    },
    "andor": {
        "description": "OR nodes choose actions; AND nodes must account for every possible outcome.",
        "strengths": "Builds conditional plans for nondeterministic environments.",
        "limitations": "The plan tree grows quickly; standard 8-puzzle is deterministic.",
        "complete": "Yes in a finite space with cycle handling",
        "optimal": "Not by default",
        "adaptation_note": "In deterministic 8-puzzle, each legal action has one outcome. The application still displays OR/AND traces to demonstrate the algorithm's structure.",
    },
    "belief": {
        "description": "Searches over sets of possible states when the agent cannot observe the exact state.",
        "strengths": "Suitable for partially observable environments.",
        "limitations": "The belief-state space can grow exponentially.",
        "complete": "Yes in a finite belief space",
        "optimal": "Yes with BFS and uniform action costs",
    },
    "lrta": {
        "description": "Acts online while updating H(s) from experience.",
        "strengths": "Supports real-time decisions and improves across trials.",
        "limitations": "Early trials may be long or repetitive and several trials may be required.",
        "complete": "Yes under standard finite-state assumptions",
        "optimal": "Not on the first trial",
    },
    "ac3": {
        "description": "Models X0..Xd as states over time and removes values that lack support in neighboring domains.",
        "strengths": "Reduces domains before backtracking and clearly demonstrates constraint propagation.",
        "limitations": "Requires a chosen horizon and domains may become large.",
        "complete": "Yes when combined with backtracking on finite domains",
        "optimal": "Yes when horizons are tried from the lower bound upward",
        "adaptation_note": "Each Xi is an 8-puzzle state at step i. The binary constraint requires Xi and Xi+1 to differ by exactly one legal move.",
    },
    "backtracking": {
        "description": "Assigns X1, X2, ... in order and backtracks when the goal cannot be reached within the remaining steps.",
        "strengths": "Clear to trace by hand; forward checking prunes impossible branches.",
        "limitations": "Can grow combinatorially when constraints are weak.",
        "complete": "Yes with a sufficient horizon",
        "optimal": "Yes when the horizon starts from a lower bound",
    },
    "minconflicts": {
        "description": "Starts with a full action sequence and repairs variables that cause conflicts.",
        "strengths": "Effective on many large CSPs and demonstrates local repair clearly.",
        "limitations": "Not guaranteed to find a solution; restarts and a suitable horizon are needed.",
        "complete": "No",
        "optimal": "No",
    },
    "minimax": {
        "description": "MAX chooses a move while MIN models the worst adverse response from the environment.",
        "strengths": "Produces conservative decisions under worst-case assumptions.",
        "limitations": "8-puzzle is not a two-player game; this is an educational adversarial model.",
        "complete": "Yes at finite depth",
        "optimal": "Optimal for the defined adversarial model",
        "adaptation_note": "The application uses receding-horizon search: MAX chooses a move and MIN represents an adverse response. Utility rewards lower Manhattan distance and discourages repetition.",
    },
    "alphabeta": {
        "description": "Returns the same decision as Minimax while pruning branches that cannot affect the final result.",
        "strengths": "Can reduce the node count substantially when move ordering is good.",
        "limitations": "Does not change the underlying adversarial model; effectiveness depends on ordering.",
        "complete": "Yes at finite depth",
        "optimal": "Same as Minimax",
        "adaptation_note": "Uses the same educational adversarial model as Minimax and records the number of pruned branches.",
    },
    "expectimax": {
        "description": "Replaces MIN nodes with CHANCE nodes and computes expected utility from outcome probabilities.",
        "strengths": "Appropriate for random disturbances rather than an always-hostile opponent.",
        "limitations": "Requires a probability model and remains an educational adaptation for 8-puzzle.",
        "complete": "Yes at finite depth",
        "optimal": "Optimal for the assumed probability model",
        "adaptation_note": "The application models a probability of staying on course or drifting to another outcome, then chooses the action with the best expected utility.",
    },
}

EXACT: dict[str, str] = {
    # Main navigation and top bar
    "Tổng quan": "Overview",
    "Chạy thuật toán": "Run algorithm",
    "Mã giả": "Pseudocode",
    "So sánh": "Compare",
    "Lịch sử": "History",
    "PEAS và báo cáo": "PEAS and report",
    "Thư viện mã giả": "Pseudocode library",
    "So sánh thực nghiệm": "Experimental comparison",
    "Trực quan hóa thuật toán\nPython · 18 phương pháp": "Algorithm visualizer\nPython · 18 methods",
    "Python · sẵn sàng": "Python · ready",
    "Sẵn sàng": "Ready",
    "Hoàn tất": "Completed",
    "Đã kết thúc": "Finished",
    "So sánh xong": "Comparison complete",
    "Có lỗi": "Error",
    "Chế độ sáng": "Light mode",
    "Chế độ tối": "Dark mode",
    # Home
    "Chương trình minh họa 18 thuật toán trí tuệ nhân tạo bằng Python trên cùng một bài toán.": "A Python application that demonstrates 18 AI algorithms on the same problem.",
    "Thuật toán": "Algorithms",
    "Nhóm kiến thức": "Algorithm groups",
    "Cấu hình khả đạt": "Reachable states",
    "Ngôn ngữ": "Language",
    "Bài toán đang xét": "Problem definition",
    "Mỗi trạng thái là một bảng 3×3 gồm tám ô số và một ô trống. Tác tử chỉ được di chuyển ô trống lên, xuống, trái hoặc phải. Mục tiêu là tìm chuỗi hành động đưa START về GOAL.": "Each state is a 3×3 board with eight numbered tiles and one blank. The agent may move the blank up, down, left, or right. The goal is to find an action sequence that transforms START into GOAL.",
    "Cách sử dụng nhanh": "Quick start",
    "1. Chọn thuật toán và nhập START, GOAL.\n2. Chạy thuật toán, quan sát hoạt ảnh và nhật ký g(n), h(n), f(n).\n3. So sánh ba thuật toán hoặc xuất báo cáo HTML làm minh chứng.": "1. Choose an algorithm and enter START and GOAL.\n2. Run it and inspect the animation plus the g(n), h(n), f(n) trace.\n3. Compare three algorithms or export an HTML report as evidence.",
    "Mở trang chạy thuật toán": "Open algorithm lab",
    "Các nhóm thuật toán": "Algorithm groups",
    # Lab
    "Thiết lập START, GOAL và theo dõi lời giải từng bước.": "Set START and GOAL, then inspect the solution step by step.",
    "Trạng thái": "States",
    "Mẫu môn học": "Course preset",
    "Dễ · 2 bước": "Easy · 2 moves",
    "Trung bình · 12 lần xáo": "Medium · 12 shuffles",
    "Khó · 24 lần xáo": "Hard · 24 shuffles",
    "Tạo ngẫu nhiên": "Randomize",
    "Giới hạn thực nghiệm": "Experiment limits",
    "Độ sâu tối đa": "Maximum depth",
    "Node tối đa": "Maximum nodes",
    "Timeout (giây)": "Timeout (seconds)",
    "Độ sâu đối kháng": "Adversarial depth",
    "Phím tắt: Ctrl+Enter để chạy · Space để phát/tạm dừng": "Shortcuts: Ctrl+Enter to run · Space to play/pause",
    "Đường đi của lời giải": "Solution path",
    "Trạng thái hiện tại": "Current state",
    "Bắt đầu": "Start",
    "←  Lùi": "←  Back",
    "▶  Phát": "▶  Play",
    "Ⅱ  Tạm dừng": "Ⅱ  Pause",
    "↻  Phát lại": "↻  Replay",
    "Tiếp  →": "Next  →",
    "Tốc độ": "Speed",
    "Số bước": "Steps",
    "Node mở rộng": "Expanded nodes",
    "Thời gian": "Time",
    "Chưa có kết quả": "No result yet",
    "Chọn thuật toán và nhấn Chạy thuật toán.": "Choose an algorithm and press Run algorithm.",
    "Chuỗi hành động": "Action sequence",
    "Phân tích": "Analysis",
    "Nhật ký": "Trace",
    "Pha": "Phase",
    "Ghi chú": "Notes",
    "Không có chuỗi hành động": "No action sequence",
    "Đã tìm thấy lời giải": "Solution found",
    "Chưa đạt đích": "Goal not reached",
    "Đang tính toán…": "Computing…",
    "Lỗi thuật toán": "Algorithm error",
    "Trạng thái không hợp lệ": "Invalid state",
    "Không có lời giải": "No solution",
    "START và GOAL không cùng parity.": "START and GOAL have different inversion parity.",
    "Nhập đủ 1–8, để trống đúng một ô.": "Enter 1–8 exactly once and leave one cell blank.",
    "Không có lời giải: START và GOAL khác parity nghịch thế.": "Unsolvable: START and GOAL have different inversion parity.",
    # Algorithm details
    "Nhóm:": "Group:",
    "Đầy đủ:": "Complete:",
    "Tối ưu:": "Optimal:",
    "Ưu điểm:": "Strengths:",
    "Hạn chế:": "Limitations:",
    "Ghi chú khi áp dụng cho 8-puzzle:": "8-puzzle adaptation note:",
    "Áp dụng cho 8-puzzle:": "8-puzzle adaptation:",
    "Thư viện thuật toán": "Algorithm library",
    "Nguyên lý, độ phức tạp, ưu nhược điểm và mã giả của 18 thuật toán.": "Principles, complexity, strengths, limitations, and pseudocode for 18 algorithms.",
    # Compare
    "Chạy ba thuật toán trên cùng START, GOAL và trực quan hóa kết quả theo nhiều dạng biểu đồ.": "Run three algorithms on the same START and GOAL and visualize the results with several chart types.",
    "Chạy so sánh": "Run comparison",
    "Đang chuẩn bị — %p%": "Preparing — %p%",
    "Hoàn tất — 100%": "Completed — 100%",
    "Nhanh nhất": "Fastest",
    "Ít node nhất": "Fewest nodes",
    "Lời giải ngắn nhất": "Shortest solution",
    "Tỷ lệ thành công": "Success rate",
    "Bảng số liệu": "Data table",
    "Có thể bấm tiêu đề cột để sắp xếp": "Click a column header to sort",
    "Kết quả": "Result",
    "Bước": "Steps",
    "Frontier max": "Max frontier",
    "Xuất CSV": "Export CSV",
    "Xuất JSON": "Export JSON",
    "Trực quan hóa": "Visualization",
    "NHẬN XÉT": "INSIGHT",
    "Loại": "Type",
    "Cột": "Bar",
    "Đường": "Line",
    "Tròn": "Pie",
    "Phân tán": "Scatter",
    "Đổi loại biểu đồ mà không cần chạy lại thuật toán": "Change chart type without rerunning the algorithms",
    "Chỉ số": "Metric",
    "Trục X": "X axis",
    "Giữ thứ tự": "Keep order",
    "Tăng dần": "Ascending",
    "Giảm dần": "Descending",
    "Node sinh ra": "Generated nodes",
    "Frontier lớn nhất": "Maximum frontier",
    "Thời gian (ms)": "Time (ms)",
    "Số bước lời giải": "Solution steps",
    "Chạy so sánh để hệ thống tổng hợp nhận xét.": "Run a comparison to generate an automatic summary.",
    "Lưu biểu đồ PNG": "Save chart PNG",
    "Chưa đủ thuật toán": "Not enough algorithms",
    "Hãy chọn ít nhất hai thuật toán khác nhau để so sánh.": "Choose at least two different algorithms to compare.",
    "Thành công": "Success",
    "Chưa đạt": "Not reached",
    "Chưa có lời giải": "No solution",
    "Mỗi điểm đại diện cho một thuật toán": "Each point represents one algorithm",
    "Lưu biểu đồ": "Save chart",
    "Đã lưu biểu đồ": "Chart saved",
    "Không thể lưu": "Unable to save",
    "Không thể ghi ảnh biểu đồ vào vị trí đã chọn.": "The chart image could not be written to the selected location.",
    "Đã xuất": "Export complete",
    # History
    "Lịch sử thực nghiệm": "Experiment history",
    "Các lần chạy trong phiên hiện tại được lưu lại để đối chiếu và xuất dữ liệu.": "Runs from the current session are stored for review and export.",
    "Xóa lịch sử": "Clear history",
    "Xuất lịch sử": "Export history",
    # Report
    "Yêu cầu bài tập": "Assignment requirements",
    "GitHub và xuất báo cáo": "GitHub and report export",
    "Mã nguồn GitHub": "GitHub source code",
    "Mở repository": "Open repository",
    "Xuất báo cáo cho lần chạy hiện tại": "Export report for the current run",
    "Báo cáo HTML gồm START, GOAL, kết quả, mã giả, độ phức tạp, solution path và tối đa 500 bước trace.": "The HTML report includes START, GOAL, result, pseudocode, complexity, solution path, and up to 500 trace steps.",
    "Xuất báo cáo HTML": "Export HTML report",
    "Hãy chạy một thuật toán trước.": "Run an algorithm first.",
    "Xuất báo cáo": "Export report",
    "Đã tạo báo cáo:\n": "Report created:\n",
}

# Long phrases used in algorithm results, trace notes, and report HTML.
PHRASES: list[tuple[str, str]] = sorted(
    [
        ("BFS tìm thấy lời giải tối ưu theo số bước.", "BFS found a shortest-path solution."),
        ("BFS dừng do giới hạn tài nguyên.", "BFS stopped because a resource limit was reached."),
        ("DFS không tìm thấy lời giải trong giới hạn đã chọn.", "DFS did not find a solution within the selected limit."),
        ("IDS không tìm thấy lời giải trong giới hạn.", "IDS did not find a solution within the limit."),
        ("Không tìm thấy lời giải trong giới hạn.", "No solution was found within the limit."),
        ("Hill Climbing đạt trạng thái đích.", "Hill Climbing reached the goal state."),
        ("Hill Climbing dừng tại cực trị cục bộ.", "Hill Climbing stopped at a local optimum."),
        ("Local Beam hết giới hạn trước khi đạt đích.", "Local Beam reached the limit before the goal."),
        ("Simulated Annealing đạt đích; chu trình trong quỹ đạo đã được rút gọn cho hoạt ảnh.", "Simulated Annealing reached the goal; cycles were removed from the displayed trajectory."),
        ("AND-OR không tìm thấy kế hoạch trong giới hạn.", "AND-OR did not find a plan within the limit."),
        ("Không tìm được chuỗi hành động hợp nhất belief trong giới hạn.", "No conformant action sequence was found within the limit."),
        ("Belief-State BFS tìm được chuỗi hành động đưa mọi trạng thái có thể về goal.", "Belief-State BFS found an action sequence that drives every possible state to the goal."),
        ("LRTA* chưa đạt goal trong giới hạn trial; trả về đường đi tốt nhất.", "LRTA* did not reach the goal within the trial limit and returned the best path found."),
        ("AC-3 không tìm được horizon khả thi trong giới hạn.", "AC-3 did not find a feasible horizon within the limit."),
        ("Backtracking CSP hết giới hạn.", "Backtracking CSP reached its limit."),
        ("Không còn lân cận cải thiện: cực trị cục bộ/plateau", "No improving neighbor remains: local optimum/plateau"),
        ("Lấy node đầu hàng đợi FIFO", "Pop the first node from the FIFO queue"),
        ("Lấy node trên đỉnh stack LIFO", "Pop the top node from the LIFO stack"),
        ("Chọn lân cận có h nhỏ nhất", "Choose the neighbor with the smallest h"),
        ("OR node: chọn một hành động", "OR node: choose an action"),
        ("Forward checking: không đủ bước/parity không phù hợp", "Forward checking: insufficient steps or incompatible parity"),
        ("Nhận xét nhanh:", "Quick insight:"),
        ("có thời gian thấp nhất", "has the lowest runtime"),
        ("mở rộng ít node nhất", "expands the fewest nodes"),
        ("cho lời giải ngắn nhất", "produces the shortest solution"),
        ("cùng một trạng thái đầu và đích", "same start and goal states"),
        ("Mối quan hệ:", "Relationship:"),
        (" và ", " and "),
        ("Đang chạy", "Running"),
        ("Bắt đầu Depth-Limited Search với limit=", "Start Depth-Limited Search with limit="),
        ("Giới hạn hiện tại:", "Current limit:"),
        ("Ưu tiên theo", "Priority by"),
        ("Thế hệ", "Generation"),
        ("chấp nhận", "accepted"),
        ("từ chối", "rejected"),
        ("phải giải được", "must solve"),
        ("kết quả", "outcomes"),
        ("Thử CSP horizon=", "Try CSP horizon="),
        ("Gán X", "Assign X"),
        ("còn", "remaining"),
        ("bước", "steps"),
        ("Quay lui khỏi hành động", "Backtrack from action"),
        ("đạt đích", "reached the goal"),
        ("tìm thấy lời giải", "found a solution"),
        ("không tìm thấy lời giải", "did not find a solution"),
        ("trả về trạng thái tốt nhất", "returns the best state"),
        ("trả về đường đi tốt nhất", "returns the best path"),
        ("Chọn", "Choose"),
        ("giá trị", "value"),
        ("Nhóm", "Group"),
        ("Đầy đủ", "Complete"),
        ("Tối ưu", "Optimal"),
        ("Ưu điểm", "Strengths"),
        ("Hạn chế", "Limitations"),
    ],
    key=lambda item: len(item[0]),
    reverse=True,
)

PSEUDO_REPLACEMENTS: list[tuple[str, str]] = [
    ("không rỗng", "not empty"),
    ("trả về thất bại", "return failure"),
    ("trả về đường đi", "return path"),
    ("trả về", "return"),
    ("mỗi successor", "each successor"),
    ("mỗi resultState", "each resultState"),
    ("mỗi", "each"),
    ("chưa được khám phá", "not explored"),
    ("chưa thăm", "unvisited"),
    ("nếu", "if"),
    ("ngược lại", "otherwise"),
    ("thêm", "add"),
    ("đẩy", "push"),
    ("lấy", "pop"),
    ("hàng đợi", "queue"),
    ("ngăn xếp", "stack"),
    ("giới hạn", "limit"),
    ("đến", "to"),
    ("tăng dần", "in increasing order"),
    ("tốt nhất", "best"),
    ("nhỏ nhất", "smallest"),
    ("lớn nhất", "largest"),
    ("hợp lệ", "valid"),
    ("rỗng", "empty"),
    ("thành công", "success"),
    ("hủy gán", "undo assignment"),
    ("gán", "assign"),
    ("quay lui", "backtrack"),
    ("lặp", "repeat"),
    ("ngẫu nhiên", "random"),
    ("hành động", "action"),
    ("trạng thái", "state"),
]


def algorithm_text(info, field: str, language: str) -> str:
    if language != LANG_EN:
        return str(getattr(info, field))
    if field == "category":
        return CATEGORY_EN.get(info.category, info.category)
    if field == "pseudocode":
        return translate_pseudocode(info.pseudocode)
    return ALGORITHM_EN.get(info.id, {}).get(field, str(getattr(info, field)))


def translate_pseudocode(text: str) -> str:
    result = text
    for source, target in PSEUDO_REPLACEMENTS:
        result = result.replace(source, target)
    return result


def translate_text(text: str, language: str) -> str:
    if language != LANG_EN or not text:
        return text
    if text in EXACT:
        return EXACT[text]
    result = text
    # Category names are safe to replace inside combo labels and rich text.
    for source, target in CATEGORY_EN.items():
        result = result.replace(source, target)
    for source, target in PHRASES:
        result = result.replace(source, target)
    # Common dynamic patterns.
    result = re.sub(r"\bBước\s+(\d+)\s*/\s*(\d+)", r"Step \1 / \2", result)
    result = re.sub(r"Có lời giải\s*·\s*Manhattan ban đầu:\s*(\d+)", r"Solvable · Initial Manhattan: \1", result)
    result = re.sub(r"Di chuyển ô trống:\s*Lên", "Move blank: Up", result)
    result = re.sub(r"Di chuyển ô trống:\s*Xuống", "Move blank: Down", result)
    result = re.sub(r"Di chuyển ô trống:\s*Trái", "Move blank: Left", result)
    result = re.sub(r"Di chuyển ô trống:\s*Phải", "Move blank: Right", result)
    result = re.sub(r"(\d+)\s+bước", r"\1 steps", result)
    result = result.replace("Lên", "Up").replace("Xuống", "Down").replace("Trái", "Left").replace("Phải", "Right")
    return result


def _source_text(widget: QWidget, current: str, prop_name: str) -> str:
    source = widget.property(prop_name)
    if source is None:
        widget.setProperty(prop_name, current)
        return current
    return str(source)


def _apply_text_widget(widget: QWidget, language: str) -> None:
    getter = getattr(widget, "text", None)
    setter = getattr(widget, "setText", None)
    if not callable(getter) or not callable(setter):
        return
    current = getter()
    source = _source_text(widget, current, "i18n_source_text")
    expected = translate_text(source, LANG_EN)
    # A dynamic method may have replaced the text while English is active. Treat a
    # non-matching value as a new Vietnamese source string.
    if language == LANG_EN and current != expected and current != source:
        source = current
        widget.setProperty("i18n_source_text", source)
    setter(source if language == LANG_VI else translate_text(source, LANG_EN))


def _apply_tooltip(widget: QWidget, language: str) -> None:
    current = widget.toolTip()
    if not current:
        return
    source = _source_text(widget, current, "i18n_source_tooltip")
    widget.setToolTip(source if language == LANG_VI else translate_text(source, LANG_EN))


def _apply_combo(combo: QComboBox, language: str) -> None:
    sources = combo.property("i18n_combo_sources")
    if not isinstance(sources, list) or len(sources) != combo.count():
        sources = [combo.itemText(index) for index in range(combo.count())]
        combo.setProperty("i18n_combo_sources", sources)
    for index, source in enumerate(sources):
        combo.setItemText(index, source if language == LANG_VI else translate_text(source, LANG_EN))


def _apply_tabs(tabs: QTabWidget, language: str) -> None:
    sources = tabs.property("i18n_tab_sources")
    if not isinstance(sources, list) or len(sources) != tabs.count():
        sources = [tabs.tabText(index) for index in range(tabs.count())]
        tabs.setProperty("i18n_tab_sources", sources)
    for index, source in enumerate(sources):
        tabs.setTabText(index, source if language == LANG_VI else translate_text(source, LANG_EN))


def _apply_table(table: QTableWidget, language: str) -> None:
    for column in range(table.columnCount()):
        item = table.horizontalHeaderItem(column)
        if item is None:
            continue
        source = item.data(SOURCE_ROLE)
        if source is None:
            source = item.text()
            item.setData(SOURCE_ROLE, source)
        item.setText(str(source) if language == LANG_VI else translate_text(str(source), LANG_EN))
    for row in range(table.rowCount()):
        for column in range(table.columnCount()):
            item = table.item(row, column)
            if item is None:
                continue
            source = item.data(SOURCE_ROLE)
            if source is None:
                source = item.text()
                item.setData(SOURCE_ROLE, source)
            # Numeric cells are intentionally left untouched.
            source_text = str(source)
            item.setText(source_text if language == LANG_VI else translate_text(source_text, LANG_EN))


def _apply_list(widget: QListWidget, language: str) -> None:
    for index in range(widget.count()):
        item = widget.item(index)
        source = item.data(SOURCE_ROLE)
        if source is None:
            source = item.text()
            item.setData(SOURCE_ROLE, source)
        item.setText(str(source) if language == LANG_VI else translate_text(str(source), LANG_EN))


def _apply_plain_text(widget: QPlainTextEdit, language: str) -> None:
    current = widget.toPlainText()
    source = widget.property("i18n_plain_source")
    if source is None:
        source = current
        widget.setProperty("i18n_plain_source", source)
    expected = translate_pseudocode(str(source)) if language == LANG_EN else str(source)
    if language == LANG_EN and current not in (str(source), expected):
        source = current
        widget.setProperty("i18n_plain_source", source)
    widget.setPlainText(str(source) if language == LANG_VI else translate_pseudocode(translate_text(str(source), LANG_EN)))


def _apply_browser(widget: QTextBrowser, language: str) -> None:
    current = widget.toHtml()
    source = widget.property("i18n_html_source")
    if source is None:
        source = current
        widget.setProperty("i18n_html_source", source)
    if language == LANG_EN:
        # If content changed dynamically, remember the new source before translating.
        translated_old = translate_text(str(source), LANG_EN)
        if current not in (str(source), translated_old):
            source = current
            widget.setProperty("i18n_html_source", source)
        widget.setHtml(translate_text(str(source), LANG_EN))
    else:
        widget.setHtml(str(source))


def apply_language(root: QWidget, language: str) -> None:
    """Translate the visible widget tree without rebuilding pages or losing state."""
    widgets: Iterable[QWidget] = [root, *root.findChildren(QWidget)]
    for widget in widgets:
        if widget.property("i18n_managed"):
            continue
        _apply_tooltip(widget, language)
        if isinstance(widget, QComboBox):
            _apply_combo(widget, language)
        elif isinstance(widget, QTabWidget):
            _apply_tabs(widget, language)
        elif isinstance(widget, QTableWidget):
            _apply_table(widget, language)
        elif isinstance(widget, QListWidget):
            _apply_list(widget, language)
        elif isinstance(widget, QPlainTextEdit) and not isinstance(widget, QTextBrowser):
            _apply_plain_text(widget, language)
        elif isinstance(widget, QTextBrowser):
            _apply_browser(widget, language)
        elif isinstance(widget, QProgressBar):
            current = widget.format()
            source = _source_text(widget, current, "i18n_progress_source")
            widget.setFormat(source if language == LANG_VI else translate_text(source, LANG_EN))
        elif isinstance(widget, (QLabel, QPushButton, QGroupBox)):
            _apply_text_widget(widget, language)

    if isinstance(root, QMainWindow):
        source = root.property("i18n_window_title")
        if source is None:
            source = root.windowTitle()
            root.setProperty("i18n_window_title", source)
        root.setWindowTitle(str(source) if language == LANG_VI else "8 Puzzle — Algorithm Visualizer")

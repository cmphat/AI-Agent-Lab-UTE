"""Application themes.

The interface uses a restrained classroom-lab aesthetic: clear hierarchy, muted colour,
small accents and no gradients/glow.  It is intentionally closer to a carefully crafted
student desktop tool than a synthetic dashboard.
"""

DARK_STYLESHEET = r"""
* {
    font-family: "Segoe UI", Arial, sans-serif;
    font-size: 13px;
}
QMainWindow, QWidget {
    background: #0e141b;
    color: #e7edf3;
}
QLabel { background: transparent; }
QFrame#Sidebar {
    background: #111a24;
    border-right: 1px solid #293746;
}
QFrame#Topbar {
    background: #131c26;
    border-bottom: 1px solid #2a3948;
}
QFrame#Panel, QFrame#Card, QGroupBox {
    background: #17212c;
    border: 1px solid #2d3b4a;
    border-radius: 9px;
}
QFrame#InsetPanel {
    background: #121b25;
    border: 1px solid #2b3a49;
    border-radius: 9px;
}
QFrame#BoardSurface {
    background: #0c141d;
    border: 1px solid #34495d;
    border-radius: 14px;
}
QGroupBox {
    margin-top: 12px;
    padding-top: 14px;
    font-weight: 650;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 11px;
    padding: 0 6px;
    color: #dce5ee;
}
QLabel#AppTitle { font-size: 22px; font-weight: 760; color: #f6f8fb; }
QLabel#AppSubtitle { font-size: 11px; color: #8fa1b4; line-height: 1.35; }
QLabel#PageTitle { font-size: 24px; font-weight: 760; color: #f5f7fa; }
QLabel#SectionTitle { font-size: 15px; font-weight: 700; color: #edf2f7; }
QLabel#Muted { color: #9aaabc; }
QLabel#Caption { color: #8293a6; font-size: 11px; }
QLabel#MetricValue { font-size: 22px; font-weight: 760; color: #f4f7fa; }
QLabel#MetricLabel { color: #8fa0b2; font-size: 11px; }
QLabel#MoveChip {
    background: #1a3042;
    color: #b9d9f1;
    border: 1px solid #365a73;
    border-radius: 7px;
    padding: 7px 11px;
    font-size: 13px;
    font-weight: 650;
}
QLabel#StepBadge {
    background: #202b36;
    color: #c8d3dd;
    border: 1px solid #3a4958;
    border-radius: 6px;
    padding: 4px 8px;
    font-size: 11px;
    font-weight: 650;
}
QPushButton {
    background: #386fb8;
    color: #ffffff;
    border: 1px solid #4a81c7;
    border-radius: 7px;
    padding: 8px 14px;
    font-weight: 650;
}
QPushButton:hover { background: #447cc8; border-color: #5a8fd3; }
QPushButton:pressed { background: #2f62a5; }
QPushButton:disabled { background: #27313c; color: #6e7d8d; border-color: #33404e; }
QPushButton#Secondary {
    background: #1b2835;
    color: #dce5ed;
    border: 1px solid #36485a;
}
QPushButton#Secondary:hover { background: #223342; border-color: #4b6177; }
QPushButton#Subtle {
    background: transparent;
    color: #aab7c5;
    border: 1px solid transparent;
}
QPushButton#Subtle:hover { background: #1c2935; color: #ffffff; }
QPushButton#Danger { background: #9f4f5b; border-color: #b76270; }
QPushButton#Success { background: #2e7b67; border-color: #3c927b; }
QPushButton#Success:hover { background: #378b74; }
QPushButton#Playback {
    background: #2e7b67;
    border: 1px solid #3c927b;
    min-width: 76px;
}
QPushButton#Playback:hover { background: #378b74; }
QPushButton#NavButton {
    background: transparent;
    color: #aab7c5;
    border: 0;
    text-align: left;
    padding: 10px 12px;
    border-radius: 7px;
    font-weight: 550;
}
QPushButton#NavButton:hover { background: #192735; color: #f0f4f8; }
QPushButton#NavButton:checked {
    background: #203247;
    color: #ffffff;
    border-left: 3px solid #6b9fd0;
    padding-left: 9px;
}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTextEdit,
QTextBrowser, QListWidget, QTableWidget {
    background: #111a23;
    color: #e7edf3;
    border: 1px solid #344557;
    border-radius: 7px;
    padding: 6px;
    selection-background-color: #355f8e;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QPlainTextEdit:focus,
QTextEdit:focus, QListWidget:focus, QTableWidget:focus { border-color: #6a9fd6; }
QComboBox::drop-down { border: 0; width: 24px; }
QComboBox QAbstractItemView {
    background: #18232e;
    color: #e8edf3;
    border: 1px solid #3b4d60;
    selection-background-color: #2b4f76;
}
QListWidget::item { padding: 7px 8px; border-radius: 5px; }
QListWidget::item:hover { background: #1d2c3a; }
QListWidget::item:selected { background: #29425d; color: white; }
QHeaderView::section {
    background: #1d2a36;
    color: #d4dde7;
    padding: 7px;
    border: 0;
    border-right: 1px solid #314151;
    border-bottom: 1px solid #314151;
    font-weight: 650;
}
QTableWidget { gridline-color: #273542; alternate-background-color: #141e28; }
QTabWidget::pane {
    border: 1px solid #2d3d4d;
    border-radius: 8px;
    background: #17212c;
    top: -1px;
}
QTabBar::tab {
    background: transparent;
    color: #8fa0b2;
    padding: 9px 14px;
    margin-right: 2px;
    border-bottom: 2px solid transparent;
}
QTabBar::tab:hover { color: #d9e1e9; }
QTabBar::tab:selected { color: #ffffff; border-bottom: 2px solid #6a9fd6; }
QProgressBar {
    background: #24313e;
    border: 0;
    border-radius: 4px;
    height: 8px;
    text-align: center;
    color: transparent;
}
QProgressBar::chunk { background: #4e8ecb; border-radius: 4px; }
QSlider::groove:horizontal { height: 5px; background: #344454; border-radius: 2px; }
QSlider::handle:horizontal { width: 15px; margin: -5px 0; background: #6aa7e8; border-radius: 7px; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #3a4a5a; min-height: 30px; border-radius: 4px; }
QScrollBar::handle:vertical:hover { background: #4a6074; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 2px; }
QScrollBar::handle:horizontal { background: #3a4a5a; min-width: 30px; border-radius: 4px; }
QSplitter::handle { background: #23313e; }
QSplitter::handle:hover { background: #3b5064; }
QToolTip { background: #f2f5f7; color: #17202a; border: 1px solid #9ba9b8; padding: 5px; }
QScrollArea#ChartScrollArea { background: transparent; border: 0; }
QWidget#ChartScrollBody { background: transparent; }
QScrollArea#ChartScrollArea QScrollBar:vertical {
    background: #111a23; width: 10px; margin: 2px 0 2px 0; border-radius: 5px;
}
QScrollArea#ChartScrollArea QScrollBar::handle:vertical {
    background: #3a5368; min-height: 34px; border-radius: 5px;
}
QScrollArea#ChartScrollArea QScrollBar::handle:vertical:hover { background: #52728c; }
QScrollArea#ChartScrollArea QScrollBar::add-line:vertical,
QScrollArea#ChartScrollArea QScrollBar::sub-line:vertical { height: 0; }
QFrame#InsightCard {
    background: #111a23;
    border: 1px solid #2b3b4b;
    border-radius: 8px;
}
QLabel#InsightBadge {
    background: #20364a;
    color: #a9c8e4;
    border: 1px solid #38556d;
    border-radius: 5px;
    padding: 4px 8px;
    font-size: 10px;
    font-weight: 700;
}
QLabel#InsightText { color: #c7d2dd; line-height: 1.35; }
"""

LIGHT_STYLESHEET = r"""
* { font-family: "Segoe UI", Arial, sans-serif; font-size: 13px; }
QMainWindow, QWidget { background: #f1f3f5; color: #202833; }
QLabel { background: transparent; }
QFrame#Sidebar { background: #fbfcfd; border-right: 1px solid #d5dce3; }
QFrame#Topbar { background: #ffffff; border-bottom: 1px solid #d5dce3; }
QFrame#Panel, QFrame#Card, QGroupBox { background: #ffffff; border: 1px solid #d6dde4; border-radius: 9px; }
QFrame#InsetPanel { background: #f7f9fb; border: 1px solid #dbe2e8; border-radius: 9px; }
QFrame#BoardSurface { background: #e7edf2; border: 1px solid #c4d0da; border-radius: 14px; }
QGroupBox { margin-top: 12px; padding-top: 14px; font-weight: 650; }
QGroupBox::title { subcontrol-origin: margin; left: 11px; padding: 0 6px; color: #344252; }
QLabel#AppTitle { font-size: 22px; font-weight: 760; color: #1d2732; }
QLabel#AppSubtitle { font-size: 11px; color: #788797; }
QLabel#PageTitle { font-size: 24px; font-weight: 760; color: #1c2630; }
QLabel#SectionTitle { font-size: 15px; font-weight: 700; color: #263443; }
QLabel#Muted { color: #6f7e8e; }
QLabel#Caption { color: #7d8a98; font-size: 11px; }
QLabel#MetricValue { font-size: 22px; font-weight: 760; color: #202a34; }
QLabel#MetricLabel { color: #748291; font-size: 11px; }
QLabel#MoveChip { background: #e7f0f7; color: #315f84; border: 1px solid #b8ccdc; border-radius: 7px; padding: 7px 11px; font-size: 13px; font-weight: 650; }
QLabel#StepBadge { background: #edf1f4; color: #506070; border: 1px solid #d0d8df; border-radius: 6px; padding: 4px 8px; font-size: 11px; font-weight: 650; }
QPushButton { background: #386fb8; color: white; border: 1px solid #386fb8; border-radius: 7px; padding: 8px 14px; font-weight: 650; }
QPushButton:hover { background: #447cc8; border-color: #447cc8; }
QPushButton:pressed { background: #2f62a5; }
QPushButton:disabled { background: #e1e5e9; color: #98a2ad; border-color: #d9dee3; }
QPushButton#Secondary { background: #ffffff; color: #344252; border: 1px solid #c9d2da; }
QPushButton#Secondary:hover { background: #f1f4f7; border-color: #abb8c4; }
QPushButton#Subtle { background: transparent; color: #667585; border: 1px solid transparent; }
QPushButton#Subtle:hover { background: #edf1f4; color: #202a34; }
QPushButton#Danger { background: #aa5360; border-color: #aa5360; }
QPushButton#Success, QPushButton#Playback { background: #2e7b67; border-color: #2e7b67; }
QPushButton#Success:hover, QPushButton#Playback:hover { background: #378b74; }
QPushButton#Playback { min-width: 76px; }
QPushButton#NavButton { background: transparent; color: #5f6e7d; border: 0; text-align: left; padding: 10px 12px; border-radius: 7px; font-weight: 550; }
QPushButton#NavButton:hover { background: #eef2f5; color: #27313b; }
QPushButton#NavButton:checked { background: #e8f0f8; color: #285d96; border-left: 3px solid #4e8ecb; padding-left: 9px; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTextEdit,
QTextBrowser, QListWidget, QTableWidget { background: #ffffff; color: #202833; border: 1px solid #c9d2db; border-radius: 7px; padding: 6px; selection-background-color: #c7dcf1; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QPlainTextEdit:focus, QTextEdit:focus, QListWidget:focus, QTableWidget:focus { border-color: #5e91c6; }
QComboBox::drop-down { border: 0; width: 24px; }
QComboBox QAbstractItemView { background: white; color: #202833; border: 1px solid #c9d2db; selection-background-color: #e2edf7; }
QListWidget::item { padding: 7px 8px; border-radius: 5px; }
QListWidget::item:hover { background: #eef2f5; }
QListWidget::item:selected { background: #e1ecf6; color: #285d96; }
QHeaderView::section { background: #edf1f4; color: #425160; padding: 7px; border: 0; border-right: 1px solid #d8dfe5; border-bottom: 1px solid #d8dfe5; font-weight: 650; }
QTableWidget { gridline-color: #e1e6ea; alternate-background-color: #f8fafb; }
QTabWidget::pane { border: 1px solid #d6dde4; border-radius: 8px; background: white; top: -1px; }
QTabBar::tab { background: transparent; color: #748291; padding: 9px 14px; margin-right: 2px; border-bottom: 2px solid transparent; }
QTabBar::tab:hover { color: #2f3b47; }
QTabBar::tab:selected { color: #285d96; border-bottom: 2px solid #4e8ecb; }
QProgressBar { background: #dfe5ea; border: 0; border-radius: 4px; height: 8px; text-align: center; color: transparent; }
QProgressBar::chunk { background: #4e8ecb; border-radius: 4px; }
QSlider::groove:horizontal { height: 5px; background: #d1d9e0; border-radius: 2px; }
QSlider::handle:horizontal { width: 15px; margin: -5px 0; background: #4e8ecb; border-radius: 7px; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #bdc7d0; min-height: 30px; border-radius: 4px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QSplitter::handle { background: #dce2e7; }
QSplitter::handle:hover { background: #c2ccd5; }
QToolTip { background: #26313b; color: white; border: 1px solid #161d24; padding: 5px; }
QScrollArea#ChartScrollArea { background: transparent; border: 0; }
QWidget#ChartScrollBody { background: transparent; }
QScrollArea#ChartScrollArea QScrollBar:vertical {
    background: #edf1f4; width: 10px; margin: 2px 0 2px 0; border-radius: 5px;
}
QScrollArea#ChartScrollArea QScrollBar::handle:vertical {
    background: #aab8c5; min-height: 34px; border-radius: 5px;
}
QScrollArea#ChartScrollArea QScrollBar::handle:vertical:hover { background: #8fa2b3; }
QScrollArea#ChartScrollArea QScrollBar::add-line:vertical,
QScrollArea#ChartScrollArea QScrollBar::sub-line:vertical { height: 0; }
QFrame#InsightCard {
    background: #f7f9fb;
    border: 1px solid #d7e0e8;
    border-radius: 8px;
}
QLabel#InsightBadge {
    background: #e7f0f7;
    color: #315f84;
    border: 1px solid #bfd0de;
    border-radius: 5px;
    padding: 4px 8px;
    font-size: 10px;
    font-weight: 700;
}
QLabel#InsightText { color: #526273; line-height: 1.35; }
"""

from __future__ import annotations

from typing import Iterable

from PySide6.QtCore import (
    QEasingCurve,
    QParallelAnimationGroup,
    QPropertyAnimation,
    QRectF,
    QTimer,
    Qt,
    Signal,
)
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (
    QFrame,
    QGraphicsDropShadowEffect,
    QGraphicsOpacityEffect,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from puzzle8.core import State, validate_state


# A restrained, hand-tuned palette. Each number keeps one colour throughout the
# application, making the motion easy to follow without turning the interface into
# a game-like or neon dashboard.
TILE_PALETTE: dict[int, tuple[str, str, str]] = {
    1: ("#cfe2f6", "#1f496d", "#79a8d2"),
    2: ("#d5eadb", "#28543b", "#83b996"),
    3: ("#f3e4b8", "#664a17", "#c9a95e"),
    4: ("#e4d9f1", "#533b68", "#aa91c4"),
    5: ("#f0d5db", "#683640", "#c58f9a"),
    6: ("#cfe8e6", "#24575a", "#7eb5b6"),
    7: ("#f1dcc8", "#684126", "#c99d78"),
    8: ("#d8deef", "#38456b", "#929fc5"),
}


def tile_style(value: int, *, large: bool = False, moved: bool = False, editor: bool = False) -> str:
    if value == 0:
        size = 28 if large else 18
        radius = 11 if large else 7
        return (
            "background:#182331;color:transparent;border:1px dashed #526a80;"
            f"border-radius:{radius}px;font-size:{size}px;font-weight:700;"
        )
    bg, fg, border = TILE_PALETTE[value]
    border_width = 3 if moved else 1
    if moved:
        border = "#4b8bc3"
    radius = 11 if large else 7
    font_size = 30 if large else (18 if editor else 16)
    return (
        f"background:{bg};color:{fg};border:{border_width}px solid {border};"
        f"border-radius:{radius}px;font-size:{font_size}px;font-weight:750;padding:0;"
    )


class MetricCard(QFrame):
    """Compact metric used throughout the application."""

    def __init__(self, label: str, value: str = "—", accent: str = "#4c78d8", parent=None):
        super().__init__(parent)
        self.setObjectName("Panel")
        self.setMinimumHeight(78)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 10, 14, 10)
        layout.setSpacing(11)

        accent_bar = QFrame()
        accent_bar.setFixedWidth(4)
        accent_bar.setStyleSheet(f"background:{accent};border:0;border-radius:2px;")
        layout.addWidget(accent_bar)

        text = QVBoxLayout()
        text.setSpacing(1)
        self.label = QLabel(label)
        self.label.setObjectName("MetricLabel")
        self.value = QLabel(value)
        self.value.setObjectName("MetricValue")
        text.addWidget(self.label)
        text.addWidget(self.value)
        layout.addLayout(text, 1)

    def set_value(self, value: str) -> None:
        self.value.setText(value)


class StatusPill(QLabel):
    """Small status badge with restrained, readable state colours."""

    def __init__(self, text: str = "Sẵn sàng", parent=None):
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumWidth(106)
        self.set_status("ready", text)

    def set_status(self, status: str, text: str) -> None:
        palette = {
            "ready": ("#22303d", "#ced8e2", "#405267"),
            "running": ("#493b21", "#f1cb78", "#735d32"),
            "success": ("#203d35", "#82d8bb", "#39725e"),
            "error": ("#472a31", "#f0a3af", "#7d4652"),
        }
        bg, fg, border = palette.get(status, palette["ready"])
        self.setText(text)
        self.setStyleSheet(
            f"background:{bg};color:{fg};border:1px solid {border};"
            "border-radius:7px;padding:6px 11px;font-weight:650;"
        )


class BoardEditor(QFrame):
    state_changed = Signal(tuple)

    def __init__(self, title: str, state: State, parent=None):
        super().__init__(parent)
        self.setObjectName("InsetPanel")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 9, 10, 10)
        outer.setSpacing(7)

        title_label = QLabel(title)
        title_label.setObjectName("Caption")
        title_label.setStyleSheet("font-weight:700;letter-spacing:0.4px;")
        outer.addWidget(title_label)

        grid = QGridLayout()
        grid.setSpacing(5)
        self.edits: list[QLineEdit] = []
        for index in range(9):
            edit = QLineEdit()
            edit.setObjectName("BoardCell")
            edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
            edit.setMaxLength(1)
            edit.setFixedSize(42, 42)
            edit.textChanged.connect(lambda _text, i=index: self._on_text_changed(i))
            self.edits.append(edit)
            grid.addWidget(edit, index // 3, index % 3)
        grid.setAlignment(Qt.AlignmentFlag.AlignCenter)
        outer.addLayout(grid)
        self.set_state(state)

    def _value_at(self, index: int) -> int:
        text = self.edits[index].text().strip()
        if text.isdigit() and 0 <= int(text) <= 8:
            return int(text)
        return 0

    def _on_text_changed(self, index: int) -> None:
        self.edits[index].setStyleSheet(
            "QLineEdit#BoardCell{" + tile_style(self._value_at(index), editor=True) + "}"
        )
        self._emit_if_valid()

    def set_state(self, state: State) -> None:
        for edit, value in zip(self.edits, state):
            edit.blockSignals(True)
            edit.setText("" if value == 0 else str(value))
            edit.blockSignals(False)
        for index in range(9):
            self._on_text_changed(index)
        self._emit_if_valid()

    def state(self) -> State:
        values = []
        for edit in self.edits:
            text = edit.text().strip()
            values.append(0 if text == "" else int(text))
        return validate_state(values)

    def _emit_if_valid(self) -> None:
        try:
            state = self.state()
        except Exception:
            return
        self.state_changed.emit(state)


class PuzzleBoard(QFrame):
    """Main 3×3 board with stable colours and a real sliding-tile transition."""

    def __init__(self, state: State, title: str = "Trạng thái hiện tại", parent=None):
        super().__init__(parent)
        self.setObjectName("InsetPanel")
        self._state = state
        self._motion_groups: list[QParallelAnimationGroup] = []
        self._ghosts: list[QLabel] = []
        self._motion_token = 0

        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 13, 16, 16)
        outer.setSpacing(12)

        self.title_label = QLabel(title)
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label.setObjectName("Caption")
        self.title_label.setStyleSheet("font-weight:700;letter-spacing:0.45px;")
        outer.addWidget(self.title_label)

        self.board_frame = QFrame()
        self.board_frame.setObjectName("BoardSurface")
        board_layout = QVBoxLayout(self.board_frame)
        board_layout.setContentsMargins(16, 16, 16, 16)
        grid = QGridLayout()
        grid.setSpacing(9)
        grid.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.tiles: list[QLabel] = []
        for index in range(9):
            tile = QLabel()
            tile.setObjectName("PuzzleTile")
            tile.setAlignment(Qt.AlignmentFlag.AlignCenter)
            tile.setFixedSize(78, 78)
            tile.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            self.tiles.append(tile)
            grid.addWidget(tile, index // 3, index % 3)
        board_layout.addLayout(grid)
        outer.addStretch(1)
        outer.addWidget(self.board_frame, alignment=Qt.AlignmentFlag.AlignCenter)
        outer.addStretch(1)
        self.set_state(state)

    def _clear_motion(self) -> None:
        self._motion_token += 1
        for group in list(self._motion_groups):
            group.stop()
            group.deleteLater()
        self._motion_groups.clear()
        for ghost in list(self._ghosts):
            ghost.deleteLater()
        self._ghosts.clear()
        for tile in self.tiles:
            tile.setVisible(True)

    def _fade_target(self, tile: QLabel) -> None:
        effect = QGraphicsOpacityEffect(tile)
        tile.setGraphicsEffect(effect)
        animation = QPropertyAnimation(effect, b"opacity", self)
        animation.setDuration(170)
        animation.setStartValue(0.68)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.finished.connect(lambda: tile.setGraphicsEffect(None))
        animation.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)

    def _start_slide(self, source_index: int, target_index: int, value: int, token: int) -> None:
        if token != self._motion_token:
            return
        source = self.tiles[source_index]
        target = self.tiles[target_index]
        start_rect = source.geometry()
        end_rect = target.geometry()
        if start_rect.width() <= 0 or end_rect.width() <= 0:
            target.setVisible(True)
            self._fade_target(target)
            return

        target.setVisible(False)
        ghost = QLabel(str(value), self.board_frame)
        ghost.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ghost.setStyleSheet(tile_style(value, large=True, moved=True))
        ghost.setGeometry(start_rect)
        ghost.raise_()
        ghost.show()

        shadow = QGraphicsDropShadowEffect(ghost)
        shadow.setBlurRadius(18)
        shadow.setOffset(0, 4)
        shadow.setColor(QColor(0, 0, 0, 95))
        ghost.setGraphicsEffect(shadow)

        group = QParallelAnimationGroup(self)
        motion = QPropertyAnimation(ghost, b"geometry", group)
        motion.setDuration(250)
        motion.setStartValue(start_rect)
        motion.setEndValue(end_rect)
        motion.setEasingCurve(QEasingCurve.Type.OutCubic)
        group.addAnimation(motion)

        def finish() -> None:
            if token == self._motion_token:
                target.setVisible(True)
                self._fade_target(target)
            if ghost in self._ghosts:
                self._ghosts.remove(ghost)
            ghost.deleteLater()
            if group in self._motion_groups:
                self._motion_groups.remove(group)
            group.deleteLater()

        group.finished.connect(finish)
        self._ghosts.append(ghost)
        self._motion_groups.append(group)
        group.start()

    def set_state(self, state: State, moved_index: int | None = None) -> None:
        old_state = self._state
        self._clear_motion()
        token = self._motion_token
        self._state = state

        for index, (tile, value) in enumerate(zip(self.tiles, state)):
            is_moved = index == moved_index and value != 0
            tile.setText("" if value == 0 else str(value))
            tile.setStyleSheet(tile_style(value, large=True, moved=is_moved))
            tile.setVisible(True)

        if moved_index is None or old_state == state:
            return
        moved_value = state[moved_index]
        if moved_value == 0 or moved_value not in old_state:
            return
        source_index = old_state.index(moved_value)
        QTimer.singleShot(0, lambda: self._start_slide(source_index, moved_index, moved_value, token))

    def state(self) -> State:
        return self._state


class StatePreview(QFrame):
    """Small read-only board used on summary pages."""

    def __init__(self, title: str, state: State, parent=None):
        super().__init__(parent)
        self.setObjectName("InsetPanel")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(11, 9, 11, 11)
        layout.setSpacing(6)
        label = QLabel(title)
        label.setObjectName("Caption")
        label.setStyleSheet("font-weight:700;letter-spacing:0.4px;")
        layout.addWidget(label)
        grid = QGridLayout()
        grid.setSpacing(4)
        for index, value in enumerate(state):
            tile = QLabel("" if value == 0 else str(value))
            tile.setAlignment(Qt.AlignmentFlag.AlignCenter)
            tile.setFixedSize(35, 35)
            tile.setStyleSheet(tile_style(value))
            grid.addWidget(tile, index // 3, index % 3)
        grid.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addLayout(grid)


class SimpleBarChart(QWidget):
    """Compact comparison chart supporting bar, line, pie and scatter modes.

    The widget intentionally uses a restrained custom QPainter implementation so the
    project stays dependency-light while still giving the comparison page a polished,
    presentation-ready visual layer.
    """

    CHART_LABELS = {
        "bar": "Biểu đồ cột",
        "line": "Biểu đồ đường",
        "pie": "Biểu đồ tròn",
        "scatter": "Biểu đồ phân tán",
    }
    COLORS = [
        "#4c78d8",
        "#2f8f6b",
        "#c98735",
        "#8a68c7",
        "#bf6473",
        "#2d8e9b",
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._data: list[tuple[str, float]] = []
        self._secondary: list[tuple[str, float]] = []
        self._title = ""
        self._subtitle = ""
        self._chart_type = "bar"
        self._x_label = ""
        self._y_label = ""
        self.language = "vi"
        self.setMinimumHeight(330)

    def set_language(self, language: str) -> None:
        self.language = "en" if language == "en" else "vi"
        self.update()

    def set_data(
        self,
        title: str,
        data: Iterable[tuple[str, float]],
        *,
        chart_type: str = "bar",
        secondary: Iterable[tuple[str, float]] | None = None,
        subtitle: str = "",
        x_label: str = "",
        y_label: str = "",
    ) -> None:
        self._title = title
        self._data = list(data)
        self._secondary = list(secondary or [])
        self._chart_type = chart_type if chart_type in self.CHART_LABELS else "bar"
        self._subtitle = subtitle
        self._x_label = x_label
        self._y_label = y_label
        self.update()

    @staticmethod
    def _format_value(value: float) -> str:
        magnitude = abs(value)
        if magnitude >= 1_000_000:
            return f"{value / 1_000_000:.1f}M"
        if magnitude >= 1_000:
            return f"{value / 1_000:.1f}K"
        if magnitude >= 100:
            return f"{value:.0f}"
        if abs(value - round(value)) < 1e-9:
            return f"{value:.0f}"
        return f"{value:.2f}"

    def _draw_header(self, painter: QPainter, rect) -> int:
        foreground = self.palette().color(self.foregroundRole())
        muted = QColor(foreground)
        muted.setAlpha(150)
        painter.setPen(foreground)
        painter.setFont(QFont("Segoe UI", 11, QFont.Weight.DemiBold))
        painter.drawText(14, 24, self._title)
        header_bottom = 38
        if self._subtitle:
            painter.setPen(muted)
            painter.setFont(QFont("Segoe UI", 8))
            painter.drawText(14, 42, self._subtitle)
            header_bottom = 52
        return header_bottom

    def _axis_area(self, rect, header_bottom: int) -> QRectF:
        return QRectF(58, header_bottom + 14, rect.width() - 78, rect.height() - header_bottom - 58)

    def _draw_empty(self, painter: QPainter, rect) -> None:
        foreground = self.palette().color(self.foregroundRole())
        muted = QColor(foreground)
        muted.setAlpha(135)
        painter.setPen(muted)
        painter.setFont(QFont("Segoe UI", 10))
        empty_text = "No data to visualize" if self.language == "en" else "Chưa có dữ liệu để trực quan hóa"
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, empty_text)

    def _draw_grid(self, painter: QPainter, area: QRectF, max_value: float) -> None:
        foreground = self.palette().color(self.foregroundRole())
        muted = QColor(foreground)
        muted.setAlpha(135)
        grid_color = QColor(foreground)
        grid_color.setAlpha(38)
        painter.setFont(QFont("Segoe UI", 8))
        for i in range(5):
            ratio = i / 4
            y = area.bottom() - area.height() * ratio
            painter.setPen(QPen(grid_color, 1))
            painter.drawLine(area.left(), y, area.right(), y)
            painter.setPen(muted)
            value = max_value * ratio
            painter.drawText(
                QRectF(2, y - 9, 50, 18),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                self._format_value(value),
            )

    def _draw_bar(self, painter: QPainter, area: QRectF) -> None:
        foreground = self.palette().color(self.foregroundRole())
        values = [max(0.0, float(value)) for _, value in self._data]
        max_value = max(values) if values else 1.0
        max_value = max(max_value, 1e-9)
        self._draw_grid(painter, area, max_value)
        count = len(self._data)
        gap = max(16.0, area.width() * 0.035)
        bar_width = max(24.0, (area.width() - gap * (count + 1)) / max(1, count))
        for i, ((label, raw_value), value) in enumerate(zip(self._data, values)):
            height = area.height() * (value / max_value)
            x = area.left() + gap + i * (bar_width + gap)
            y = area.bottom() - height
            color = QColor(self.COLORS[i % len(self.COLORS)])
            painter.setBrush(color)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(QRectF(x, y, bar_width, height), 5, 5)
            painter.setPen(foreground)
            painter.setFont(QFont("Segoe UI", 8, QFont.Weight.DemiBold))
            painter.drawText(
                QRectF(x - 16, max(area.top(), y - 22), bar_width + 32, 18),
                Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter,
                self._format_value(float(raw_value)),
            )
            painter.setFont(QFont("Segoe UI", 8))
            painter.drawText(
                QRectF(x - 20, area.bottom() + 6, bar_width + 40, 25),
                Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
                label,
            )

    def _draw_line(self, painter: QPainter, area: QRectF) -> None:
        foreground = self.palette().color(self.foregroundRole())
        values = [max(0.0, float(value)) for _, value in self._data]
        max_value = max(values) if values else 1.0
        max_value = max(max_value, 1e-9)
        self._draw_grid(painter, area, max_value)
        count = len(self._data)
        if count == 1:
            xs = [area.center().x()]
        else:
            xs = [area.left() + i * area.width() / (count - 1) for i in range(count)]
        points = []
        for x, value in zip(xs, values):
            y = area.bottom() - area.height() * (value / max_value)
            points.append((x, y))
        painter.setPen(QPen(QColor("#4c78d8"), 3))
        for index in range(1, len(points)):
            painter.drawLine(points[index - 1][0], points[index - 1][1], points[index][0], points[index][1])
        for i, ((label, raw_value), (x, y)) in enumerate(zip(self._data, points)):
            color = QColor(self.COLORS[i % len(self.COLORS)])
            painter.setBrush(color)
            painter.setPen(QPen(self.palette().color(self.backgroundRole()), 2))
            painter.drawEllipse(QRectF(x - 6, y - 6, 12, 12))
            painter.setPen(foreground)
            painter.setFont(QFont("Segoe UI", 8, QFont.Weight.DemiBold))
            painter.drawText(
                QRectF(x - 42, max(area.top(), y - 25), 84, 18),
                Qt.AlignmentFlag.AlignCenter,
                self._format_value(float(raw_value)),
            )
            painter.setFont(QFont("Segoe UI", 8))
            painter.drawText(
                QRectF(x - 48, area.bottom() + 6, 96, 22),
                Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
                label,
            )

    def _draw_pie(self, painter: QPainter, rect, header_bottom: int) -> None:
        foreground = self.palette().color(self.foregroundRole())
        muted = QColor(foreground)
        muted.setAlpha(150)
        values = [max(0.0, float(value)) for _, value in self._data]
        total = sum(values)
        if total <= 0:
            self._draw_empty(painter, rect)
            return
        diameter = min(rect.height() - header_bottom - 38, rect.width() * 0.47)
        pie_rect = QRectF(34, header_bottom + 18, diameter, diameter)
        start_angle = 90 * 16
        for i, ((_, _), value) in enumerate(zip(self._data, values)):
            span = int(-360 * 16 * value / total)
            painter.setBrush(QColor(self.COLORS[i % len(self.COLORS)]))
            painter.setPen(QPen(self.palette().color(self.backgroundRole()), 2))
            painter.drawPie(pie_rect, start_angle, span)
            start_angle += span
        legend_x = pie_rect.right() + 34
        legend_y = pie_rect.top() + 8
        painter.setFont(QFont("Segoe UI", 9))
        for i, ((label, raw_value), value) in enumerate(zip(self._data, values)):
            color = QColor(self.COLORS[i % len(self.COLORS)])
            y = legend_y + i * 38
            painter.setBrush(color)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(QRectF(legend_x, y + 2, 12, 12), 3, 3)
            painter.setPen(foreground)
            painter.setFont(QFont("Segoe UI", 9, QFont.Weight.DemiBold))
            painter.drawText(legend_x + 20, y + 12, label)
            painter.setPen(muted)
            painter.setFont(QFont("Segoe UI", 8))
            share = value * 100 / total
            painter.drawText(
                QRectF(legend_x + 20, y + 14, rect.right() - legend_x - 28, 18),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                f"{self._format_value(float(raw_value))} · {share:.1f}%",
            )
        painter.setPen(foreground)
        painter.setFont(QFont("Segoe UI", 10, QFont.Weight.DemiBold))
        painter.drawText(
            QRectF(pie_rect.left(), pie_rect.bottom() + 6, pie_rect.width(), 24),
            Qt.AlignmentFlag.AlignCenter,
            f"{'Total' if self.language == 'en' else 'Tổng'}: {self._format_value(total)}",
        )

    def _draw_scatter(self, painter: QPainter, area: QRectF) -> None:
        if not self._secondary or len(self._secondary) != len(self._data):
            self._draw_empty(painter, self.rect())
            return
        foreground = self.palette().color(self.foregroundRole())
        muted = QColor(foreground)
        muted.setAlpha(145)
        grid_color = QColor(foreground)
        grid_color.setAlpha(38)
        xs = [max(0.0, float(value)) for _, value in self._secondary]
        ys = [max(0.0, float(value)) for _, value in self._data]
        max_x = max(max(xs), 1e-9)
        max_y = max(max(ys), 1e-9)
        painter.setFont(QFont("Segoe UI", 8))
        for i in range(5):
            ratio = i / 4
            x = area.left() + area.width() * ratio
            y = area.bottom() - area.height() * ratio
            painter.setPen(QPen(grid_color, 1))
            painter.drawLine(x, area.top(), x, area.bottom())
            painter.drawLine(area.left(), y, area.right(), y)
            painter.setPen(muted)
            painter.drawText(
                QRectF(x - 30, area.bottom() + 5, 60, 18),
                Qt.AlignmentFlag.AlignHCenter,
                self._format_value(max_x * ratio),
            )
            painter.drawText(
                QRectF(2, y - 9, 50, 18),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                self._format_value(max_y * ratio),
            )
        for i, ((label, y_value), (_, x_value)) in enumerate(zip(self._data, self._secondary)):
            x = area.left() + area.width() * (max(0.0, float(x_value)) / max_x)
            y = area.bottom() - area.height() * (max(0.0, float(y_value)) / max_y)
            color = QColor(self.COLORS[i % len(self.COLORS)])
            painter.setBrush(color)
            painter.setPen(QPen(self.palette().color(self.backgroundRole()), 2))
            painter.drawEllipse(QRectF(x - 7, y - 7, 14, 14))
            painter.setPen(foreground)
            painter.setFont(QFont("Segoe UI", 8, QFont.Weight.DemiBold))
            painter.drawText(
                QRectF(x + 9, y - 19, 100, 18),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                label,
            )
        painter.setPen(muted)
        painter.setFont(QFont("Segoe UI", 8))
        if self._x_label:
            painter.drawText(
                QRectF(area.left(), area.bottom() + 25, area.width(), 18),
                Qt.AlignmentFlag.AlignCenter,
                self._x_label,
            )
        if self._y_label:
            painter.save()
            painter.translate(15, area.center().y())
            painter.rotate(-90)
            painter.drawText(QRectF(-area.height() / 2, -10, area.height(), 20), Qt.AlignmentFlag.AlignCenter, self._y_label)
            painter.restore()

    def paintEvent(self, event):  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect()
        background = self.palette().color(self.backgroundRole())
        painter.fillRect(rect, background)
        header_bottom = self._draw_header(painter, rect)
        if not self._data:
            self._draw_empty(painter, rect)
            return
        if self._chart_type == "pie":
            self._draw_pie(painter, rect, header_bottom)
            return
        area = self._axis_area(rect, header_bottom)
        if self._chart_type == "line":
            self._draw_line(painter, area)
        elif self._chart_type == "scatter":
            self._draw_scatter(painter, area)
        else:
            self._draw_bar(painter, area)


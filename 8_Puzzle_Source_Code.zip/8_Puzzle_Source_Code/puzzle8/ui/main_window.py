from __future__ import annotations

import webbrowser
from pathlib import Path

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, QSettings, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QFont, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGraphicsOpacityEffect,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    QSplitter,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from puzzle8.algorithms import ALGORITHM_INFOS, CATEGORY_ORDER, run_algorithm
from puzzle8.core import (
    ACTION_LABELS,
    DEFAULT_GOAL,
    DEFAULT_START,
    STANDARD_GOAL,
    SearchResult,
    State,
    is_solvable,
    manhattan,
    random_solvable,
    state_text,
)
from puzzle8.reporting import export_result_html, export_results_csv, export_results_json
from .theme import DARK_STYLESHEET, LIGHT_STYLESHEET
from .i18n import LANG_EN, LANG_VI, algorithm_text, apply_language
from .widgets import BoardEditor, MetricCard, PuzzleBoard, SimpleBarChart, StatePreview, StatusPill

GITHUB_URL = "https://github.com/cmphat/AI-Agent-Lab-UTE"

CATEGORY_ACCENTS = {
    "Tìm kiếm mù thông tin": ("#dce9f5", "#285577", "#8db2ce"),
    "Tìm kiếm có thông tin": ("#dcefe9", "#285b4d", "#8cc2ad"),
    "Tìm kiếm cục bộ": ("#f4e8cf", "#71511f", "#d2b36f"),
    "Môi trường phức tạp": ("#e8e0f1", "#5a4171", "#b8a1cf"),
    "Bài toán thỏa mãn ràng buộc": ("#f2dfe3", "#703b47", "#ce9da7"),
    "Tìm kiếm đối kháng": ("#e1e6ee", "#3d4c61", "#9fabbc"),
}


class AlgorithmWorker(QThread):
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, algorithm_id: str, start: State, goal: State, params: dict, parent=None):
        super().__init__(parent)
        self.algorithm_id = algorithm_id
        self.start_state = start
        self.goal_state = goal
        self.params = params

    def run(self) -> None:
        try:
            result = run_algorithm(self.algorithm_id, self.start_state, self.goal_state, self.params)
            self.completed.emit(result)
        except Exception as exc:  # pragma: no cover - UI safety net
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class CompareWorker(QThread):
    completed = Signal(object)
    progress = Signal(int, str)
    failed = Signal(str)

    def __init__(self, algorithm_ids: list[str], start: State, goal: State, params: dict, parent=None):
        super().__init__(parent)
        self.algorithm_ids = algorithm_ids
        self.start_state = start
        self.goal_state = goal
        self.params = params

    def run(self) -> None:
        try:
            results: list[SearchResult] = []
            total = max(1, len(self.algorithm_ids))
            for index, algorithm_id in enumerate(self.algorithm_ids):
                info = ALGORITHM_INFOS[algorithm_id]
                self.progress.emit(int(index * 100 / total), info.short_name)
                results.append(run_algorithm(algorithm_id, self.start_state, self.goal_state, self.params))
            self.progress.emit(100, "Hoàn tất")
            self.completed.emit(results)
        except Exception as exc:  # pragma: no cover - UI safety net
            self.failed.emit(f"{type(exc).__name__}: {exc}")


def page_header(title: str, subtitle: str) -> tuple[QLabel, QLabel]:
    title_label = QLabel(title)
    title_label.setObjectName("PageTitle")
    subtitle_label = QLabel(subtitle)
    subtitle_label.setObjectName("Muted")
    subtitle_label.setWordWrap(True)
    return title_label, subtitle_label


def panel_layout(panel: QFrame, margins: tuple[int, int, int, int] = (16, 14, 16, 16)) -> QVBoxLayout:
    panel.setObjectName("Panel")
    layout = QVBoxLayout(panel)
    layout.setContentsMargins(*margins)
    layout.setSpacing(10)
    return layout


def ui_language(widget: QWidget) -> str:
    window = widget.window()
    return getattr(window, "language", LANG_VI)


def ui_text(widget: QWidget, vi: str, en: str) -> str:
    return en if ui_language(widget) == LANG_EN else vi


def action_label(action: str, language: str) -> str:
    if language == LANG_EN:
        return {"U": "Up", "D": "Down", "L": "Left", "R": "Right"}.get(action, action)
    return ACTION_LABELS.get(action, action)


class HomePage(QWidget):
    open_lab = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 26)
        root.setSpacing(15)

        title, subtitle = page_header(
            "8 Puzzle",
            "Chương trình minh họa 18 thuật toán trí tuệ nhân tạo bằng Python trên cùng một bài toán.",
        )
        root.addWidget(title)
        root.addWidget(subtitle)

        metrics = QHBoxLayout()
        metrics.setSpacing(10)
        metrics.addWidget(MetricCard("Thuật toán", "18", "#4c78d8"))
        metrics.addWidget(MetricCard("Nhóm kiến thức", "6", "#2f8f6b"))
        metrics.addWidget(MetricCard("Cấu hình khả đạt", "181.440", "#c98735"))
        metrics.addWidget(MetricCard("Ngôn ngữ", "Python", "#8a68c7"))
        root.addLayout(metrics)

        content = QSplitter(Qt.Orientation.Horizontal)
        content.setChildrenCollapsible(False)

        intro = QFrame()
        intro_layout = panel_layout(intro)
        intro_title = QLabel("Bài toán đang xét")
        intro_title.setObjectName("SectionTitle")
        intro_layout.addWidget(intro_title)
        intro_text = QLabel(
            "Mỗi trạng thái là một bảng 3×3 gồm tám ô số và một ô trống. "
            "Tác tử chỉ được di chuyển ô trống lên, xuống, trái hoặc phải. "
            "Mục tiêu là tìm chuỗi hành động đưa START về GOAL."
        )
        intro_text.setWordWrap(True)
        intro_text.setObjectName("Muted")
        intro_layout.addWidget(intro_text)

        preview_row = QHBoxLayout()
        preview_row.addWidget(StatePreview("START", DEFAULT_START))
        preview_row.addWidget(StatePreview("GOAL", DEFAULT_GOAL))
        preview_row.addStretch()
        intro_layout.addLayout(preview_row)

        usage_title = QLabel("Cách sử dụng nhanh")
        usage_title.setObjectName("SectionTitle")
        intro_layout.addSpacing(8)
        intro_layout.addWidget(usage_title)
        usage = QLabel(
            "1. Chọn thuật toán và nhập START, GOAL.\n"
            "2. Chạy thuật toán, quan sát hoạt ảnh và nhật ký g(n), h(n), f(n).\n"
            "3. So sánh ba thuật toán hoặc xuất báo cáo HTML làm minh chứng."
        )
        usage.setWordWrap(True)
        usage.setObjectName("Muted")
        intro_layout.addWidget(usage)

        quick = QPushButton("Mở trang chạy thuật toán")
        quick.clicked.connect(self.open_lab.emit)
        intro_layout.addStretch()
        intro_layout.addWidget(quick)

        categories = QFrame()
        category_layout = panel_layout(categories)
        category_title = QLabel("Các nhóm thuật toán")
        category_title.setObjectName("SectionTitle")
        category_layout.addWidget(category_title)
        for index, category in enumerate(CATEGORY_ORDER, 1):
            names = [info.short_name for info in ALGORITHM_INFOS.values() if info.category == category]
            bg, fg, border = CATEGORY_ACCENTS[category]
            line = QLabel(
                f"<span style='color:{fg};font-weight:700'>● &nbsp;{index}. {category}</span>"
                f"<br><span style='color:#8f9dad'>{' · '.join(names)}</span>"
            )
            line.setTextFormat(Qt.TextFormat.RichText)
            line.setWordWrap(True)
            line.setContentsMargins(2, 5, 0, 6)
            category_layout.addWidget(line)
        category_layout.addStretch()

        content.addWidget(intro)
        content.addWidget(categories)
        content.setSizes([610, 560])
        root.addWidget(content, 1)


class LabPage(QWidget):
    result_ready = Signal(object)
    run_started = Signal(str)
    run_failed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_result: SearchResult | None = None
        self.worker: AlgorithmWorker | None = None
        self.animation_index = 0
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.next_frame)

        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 20)
        root.setSpacing(11)

        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title, subtitle = page_header(
            "Chạy thuật toán",
            "Thiết lập START, GOAL và theo dõi lời giải từng bước.",
        )
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header.addLayout(title_box)
        header.addStretch()
        self.status = StatusPill()
        header.addWidget(self.status, alignment=Qt.AlignmentFlag.AlignTop)
        root.addLayout(header)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(5)

        # Configuration column -------------------------------------------------
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.Shape.NoFrame)
        left_scroll.setMinimumWidth(318)
        left_scroll.setMaximumWidth(410)
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 5, 0)
        left_layout.setSpacing(10)

        algo_group = QGroupBox("Thuật toán")
        algo_layout = QVBoxLayout(algo_group)
        algo_layout.setSpacing(7)
        self.algorithm_combo = QComboBox()
        for category in CATEGORY_ORDER:
            for info in ALGORITHM_INFOS.values():
                if info.category == category:
                    self.algorithm_combo.addItem(f"{info.short_name} — {category}", info.id)
        self.algorithm_combo.currentIndexChanged.connect(self._algorithm_changed)
        algo_layout.addWidget(self.algorithm_combo)
        badge_row = QHBoxLayout()
        self.category_badge = QLabel()
        self.category_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge_row.addWidget(self.category_badge)
        badge_row.addStretch()
        algo_layout.addLayout(badge_row)
        self.algo_summary = QLabel()
        self.algo_summary.setProperty("i18n_managed", True)
        self.algo_summary.setWordWrap(True)
        self.algo_summary.setObjectName("Muted")
        algo_layout.addWidget(self.algo_summary)
        left_layout.addWidget(algo_group)

        state_group = QGroupBox("Trạng thái")
        state_layout = QVBoxLayout(state_group)
        editor_row = QHBoxLayout()
        editor_row.setSpacing(7)
        self.start_editor = BoardEditor("START", DEFAULT_START)
        self.goal_editor = BoardEditor("GOAL", DEFAULT_GOAL)
        editor_row.addWidget(self.start_editor)
        editor_row.addWidget(self.goal_editor)
        state_layout.addLayout(editor_row)

        preset_row = QHBoxLayout()
        self.preset_combo = QComboBox()
        self.preset_combo.addItem("Mẫu môn học", "course")
        self.preset_combo.addItem("Dễ · 2 bước", "easy")
        self.preset_combo.addItem("Trung bình · 12 lần xáo", "medium")
        self.preset_combo.addItem("Khó · 24 lần xáo", "hard")
        self.preset_combo.currentIndexChanged.connect(self.apply_preset)
        random_btn = QPushButton("Tạo ngẫu nhiên")
        random_btn.setObjectName("Secondary")
        random_btn.clicked.connect(self.randomize)
        preset_row.addWidget(self.preset_combo, 1)
        preset_row.addWidget(random_btn)
        state_layout.addLayout(preset_row)

        self.solvable_label = QLabel()
        self.solvable_label.setWordWrap(True)
        state_layout.addWidget(self.solvable_label)
        self.start_editor.state_changed.connect(self._validate_states)
        self.goal_editor.state_changed.connect(self._validate_states)
        left_layout.addWidget(state_group)

        param_group = QGroupBox("Giới hạn thực nghiệm")
        param_form = QFormLayout(param_group)
        param_form.setHorizontalSpacing(12)
        param_form.setVerticalSpacing(7)
        self.depth_spin = QSpinBox()
        self.depth_spin.setRange(5, 80)
        self.depth_spin.setValue(40)
        self.node_spin = QSpinBox()
        self.node_spin.setRange(1_000, 500_000)
        self.node_spin.setSingleStep(10_000)
        self.node_spin.setValue(120_000)
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(1, 60)
        self.timeout_spin.setValue(10)
        self.seed_spin = QSpinBox()
        self.seed_spin.setRange(0, 999_999)
        self.seed_spin.setValue(42)
        self.beam_spin = QSpinBox()
        self.beam_spin.setRange(2, 20)
        self.beam_spin.setValue(5)
        self.search_depth_spin = QSpinBox()
        self.search_depth_spin.setRange(1, 8)
        self.search_depth_spin.setValue(4)
        for label, widget in [
            ("Độ sâu tối đa", self.depth_spin),
            ("Node tối đa", self.node_spin),
            ("Timeout (giây)", self.timeout_spin),
            ("Random seed", self.seed_spin),
            ("Beam width", self.beam_spin),
            ("Độ sâu đối kháng", self.search_depth_spin),
        ]:
            param_form.addRow(label, widget)
        left_layout.addWidget(param_group)

        self.run_button = QPushButton("Chạy thuật toán")
        self.run_button.setMinimumHeight(40)
        self.run_button.clicked.connect(self.run_selected)
        left_layout.addWidget(self.run_button)
        hint = QLabel("Phím tắt: Ctrl+Enter để chạy · Space để phát/tạm dừng")
        hint.setObjectName("Caption")
        hint.setWordWrap(True)
        left_layout.addWidget(hint)
        left_layout.addStretch()
        left_scroll.setWidget(left)

        # Visualization column -------------------------------------------------
        center = QFrame()
        center_layout = panel_layout(center, (15, 13, 15, 15))
        center.setMinimumWidth(390)
        center_head = QHBoxLayout()
        viz_title = QLabel("Đường đi của lời giải")
        viz_title.setObjectName("SectionTitle")
        self.step_indicator = QLabel("Bước 0 / 0")
        self.step_indicator.setObjectName("StepBadge")
        center_head.addWidget(viz_title)
        center_head.addStretch()
        center_head.addWidget(self.step_indicator)
        center_layout.addLayout(center_head)

        self.board = PuzzleBoard(DEFAULT_START, "Trạng thái hiện tại")
        center_layout.addWidget(self.board, 1)

        self.move_label = QLabel("Bắt đầu")
        self.move_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.move_label.setObjectName("MoveChip")
        center_layout.addWidget(self.move_label)

        self.animation_progress = QProgressBar()
        self.animation_progress.setRange(0, 100)
        self.animation_progress.setValue(0)
        center_layout.addWidget(self.animation_progress)

        controls = QHBoxLayout()
        controls.setSpacing(6)
        self.prev_btn = QPushButton("←  Lùi")
        self.prev_btn.setObjectName("Secondary")
        self.prev_btn.clicked.connect(self.prev_frame)
        self.play_btn = QPushButton("▶  Phát")
        self.play_btn.setObjectName("Playback")
        self.play_btn.clicked.connect(self.toggle_animation)
        self.next_btn = QPushButton("Tiếp  →")
        self.next_btn.setObjectName("Secondary")
        self.next_btn.clicked.connect(self.next_frame)
        speed_label = QLabel("Tốc độ")
        speed_label.setObjectName("Caption")
        self.speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.speed_slider.setRange(120, 1_200)
        self.speed_slider.setValue(520)
        self.speed_slider.setInvertedAppearance(True)
        self.speed_slider.valueChanged.connect(self._speed_changed)
        self.speed_value = QLabel("1.0×")
        self.speed_value.setObjectName("StepBadge")
        controls.addWidget(self.prev_btn)
        controls.addWidget(self.play_btn)
        controls.addWidget(self.next_btn)
        controls.addSpacing(8)
        controls.addWidget(speed_label)
        controls.addWidget(self.speed_slider, 1)
        controls.addWidget(self.speed_value)
        center_layout.addLayout(controls)

        metrics = QHBoxLayout()
        metrics.setSpacing(7)
        self.metric_steps = MetricCard("Số bước", "—", "#4c78d8")
        self.metric_expanded = MetricCard("Node mở rộng", "—", "#2f8f6b")
        self.metric_time = MetricCard("Thời gian", "—", "#c98735")
        metrics.addWidget(self.metric_steps)
        metrics.addWidget(self.metric_expanded)
        metrics.addWidget(self.metric_time)
        center_layout.addLayout(metrics)

        # Detail column --------------------------------------------------------
        right = QTabWidget()
        right.setMinimumWidth(390)

        analysis_tab = QWidget()
        analysis_layout = QVBoxLayout(analysis_tab)
        analysis_layout.setContentsMargins(14, 13, 14, 14)
        self.result_title = QLabel("Chưa có kết quả")
        self.result_title.setObjectName("SectionTitle")
        self.result_message = QLabel("Chọn thuật toán và nhấn Chạy thuật toán.")
        self.result_message.setWordWrap(True)
        self.result_message.setObjectName("Muted")
        path_label = QLabel("Chuỗi hành động")
        path_label.setStyleSheet("font-weight:600;")
        self.path_text = QPlainTextEdit()
        self.path_text.setReadOnly(True)
        self.path_text.setMaximumHeight(92)
        self.complexity_text = QTextBrowser()
        self.complexity_text.setProperty("i18n_managed", True)
        self.complexity_text.setOpenExternalLinks(True)
        analysis_layout.addWidget(self.result_title)
        analysis_layout.addWidget(self.result_message)
        analysis_layout.addSpacing(4)
        analysis_layout.addWidget(path_label)
        analysis_layout.addWidget(self.path_text)
        analysis_layout.addWidget(self.complexity_text, 1)

        trace_tab = QWidget()
        trace_layout = QVBoxLayout(trace_tab)
        trace_layout.setContentsMargins(8, 8, 8, 8)
        self.trace_table = QTableWidget(0, 9)
        self.trace_table.setHorizontalHeaderLabels(
            ["#", "Pha", "Action", "Depth", "g", "h", "f", "Frontier", "Ghi chú"]
        )
        self.trace_table.setAlternatingRowColors(True)
        self.trace_table.setSortingEnabled(False)
        self.trace_table.horizontalHeader().setSectionResizeMode(8, QHeaderView.ResizeMode.Stretch)
        trace_layout.addWidget(self.trace_table)

        pseudo_tab = QWidget()
        pseudo_layout = QVBoxLayout(pseudo_tab)
        pseudo_layout.setContentsMargins(8, 8, 8, 8)
        self.pseudocode = QPlainTextEdit()
        self.pseudocode.setProperty("i18n_managed", True)
        self.pseudocode.setReadOnly(True)
        self.pseudocode.setFont(QFont("Consolas", 10))
        pseudo_layout.addWidget(self.pseudocode)

        right.addTab(analysis_tab, "Phân tích")
        right.addTab(trace_tab, "Nhật ký")
        right.addTab(pseudo_tab, "Mã giả")

        self.splitter.addWidget(left_scroll)
        self.splitter.addWidget(center)
        self.splitter.addWidget(right)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 1)
        self.splitter.setSizes([340, 480, 480])
        root.addWidget(self.splitter, 1)

        self._algorithm_changed()
        self._speed_changed(self.speed_slider.value())
        self._validate_states()
        self._set_animation_enabled(False)

        QShortcut(QKeySequence("Ctrl+Return"), self, activated=self.run_selected)
        QShortcut(QKeySequence("Space"), self, activated=self.toggle_animation)
        QShortcut(QKeySequence("Left"), self, activated=self.prev_frame)
        QShortcut(QKeySequence("Right"), self, activated=self.next_frame)

    def params(self) -> dict:
        return {
            "max_depth": self.depth_spin.value(),
            "max_nodes": self.node_spin.value(),
            "timeout_s": float(self.timeout_spin.value()),
            "seed": self.seed_spin.value(),
            "beam_width": self.beam_spin.value(),
            "adversarial_depth": self.search_depth_spin.value(),
            "iterations": 8_000,
        }

    def selected_algorithm_id(self) -> str:
        return str(self.algorithm_combo.currentData())

    def _algorithm_changed(self, *_args) -> None:
        info = ALGORITHM_INFOS[self.selected_algorithm_id()]
        bg, fg, border = CATEGORY_ACCENTS[info.category]
        language = ui_language(self)
        self.category_badge.setText(algorithm_text(info, "category", language))
        self.category_badge.setStyleSheet(
            f"background:{bg};color:{fg};border:1px solid {border};"
            "border-radius:7px;padding:4px 9px;font-size:11px;font-weight:700;"
        )
        self.algo_summary.setText(algorithm_text(info, "description", language))
        self.pseudocode.setPlainText(algorithm_text(info, "pseudocode", language))
        if language == LANG_EN:
            note = (
                f"<p><b>Group:</b> {algorithm_text(info, 'category', language)}</p>"
                f"<p><b>Complete:</b> {algorithm_text(info, 'complete', language)}<br>"
                f"<b>Optimal:</b> {algorithm_text(info, 'optimal', language)}<br>"
                f"<b>Time:</b> {info.time_complexity}<br>"
                f"<b>Space:</b> {info.space_complexity}</p>"
                f"<p><b>Strengths:</b> {algorithm_text(info, 'strengths', language)}</p>"
                f"<p><b>Limitations:</b> {algorithm_text(info, 'limitations', language)}</p>"
            )
            if info.adaptation_note:
                note += f"<p><b>8-puzzle adaptation note:</b> {algorithm_text(info, 'adaptation_note', language)}</p>"
        else:
            note = (
                f"<p><b>Nhóm:</b> {info.category}</p>"
                f"<p><b>Đầy đủ:</b> {info.complete}<br>"
                f"<b>Tối ưu:</b> {info.optimal}<br>"
                f"<b>Time:</b> {info.time_complexity}<br>"
                f"<b>Space:</b> {info.space_complexity}</p>"
                f"<p><b>Ưu điểm:</b> {info.strengths}</p>"
                f"<p><b>Hạn chế:</b> {info.limitations}</p>"
            )
            if info.adaptation_note:
                note += f"<p><b>Ghi chú khi áp dụng cho 8-puzzle:</b> {info.adaptation_note}</p>"
        self.complexity_text.setHtml(note)

    def _validate_states(self, *_args) -> None:
        try:
            start = self.start_editor.state()
            goal = self.goal_editor.state()
            if is_solvable(start, goal):
                self.solvable_label.setText(ui_text(self, f"Có lời giải · Manhattan ban đầu: {manhattan(start, goal)}", f"Solvable · Initial Manhattan: {manhattan(start, goal)}"))
                self.solvable_label.setStyleSheet("color:#65c79e;font-weight:600;")
                self.run_button.setEnabled(True)
            else:
                self.solvable_label.setText(ui_text(self, "Không có lời giải: START và GOAL khác parity nghịch thế.", "Unsolvable: START and GOAL have different inversion parity."))
                self.solvable_label.setStyleSheet("color:#e18494;font-weight:600;")
                self.run_button.setEnabled(False)
        except Exception:
            self.solvable_label.setText(ui_text(self, "Nhập đủ 1–8, để trống đúng một ô.", "Enter 1–8 exactly once and leave one cell blank."))
            self.solvable_label.setStyleSheet("color:#d9aa55;")
            self.run_button.setEnabled(False)

    def apply_preset(self, *_args) -> None:
        key = self.preset_combo.currentData()
        if key == "course":
            start, goal = DEFAULT_START, DEFAULT_GOAL
        elif key == "easy":
            goal = STANDARD_GOAL
            start = (1, 2, 3, 4, 5, 6, 0, 7, 8)
        elif key == "medium":
            goal = STANDARD_GOAL
            start = random_solvable(goal, moves=12, seed=17)
        else:
            goal = STANDARD_GOAL
            start = random_solvable(goal, moves=24, seed=29)
        self.start_editor.set_state(start)
        self.goal_editor.set_state(goal)
        self.board.set_state(start)
        self.current_result = None
        self._reset_result_view()

    def randomize(self) -> None:
        try:
            goal = self.goal_editor.state()
        except Exception:
            return
        start = random_solvable(goal, moves=18, seed=self.seed_spin.value())
        self.start_editor.set_state(start)
        self.board.set_state(start)
        self.current_result = None
        self._reset_result_view()

    def run_selected(self) -> None:
        if self.worker is not None and self.worker.isRunning():
            return
        try:
            start = self.start_editor.state()
            goal = self.goal_editor.state()
        except Exception as exc:
            QMessageBox.warning(self, "Trạng thái không hợp lệ", str(exc))
            return
        if not is_solvable(start, goal):
            QMessageBox.warning(self, "Không có lời giải", "START và GOAL không cùng parity.")
            return

        algorithm_id = self.selected_algorithm_id()
        info = ALGORITHM_INFOS[algorithm_id]
        self.run_button.setEnabled(False)
        self.status.set_status("running", ui_text(self, f"Đang chạy {info.short_name}", f"Running {info.short_name}"))
        self.run_started.emit(info.short_name)
        self.animation_timer.stop()
        self.play_btn.setText(ui_text(self, "▶  Phát", "▶  Play"))
        self.result_title.setText(info.name)
        self.result_message.setText(ui_text(self, "Đang tính toán…", "Computing…"))

        self.worker = AlgorithmWorker(algorithm_id, start, goal, self.params(), self)
        self.worker.completed.connect(self._on_result)
        self.worker.failed.connect(self._on_error)
        self.worker.finished.connect(self._worker_finished)
        self.worker.start()

    def _worker_finished(self) -> None:
        self.run_button.setEnabled(True)

    def _on_result(self, result: SearchResult) -> None:
        self.current_result = result
        self.animation_index = 0
        self.status.set_status(
            "success" if result.success else "error",
            ui_text(self, "Đã tìm thấy lời giải", "Solution found") if result.success else ui_text(self, "Chưa đạt đích", "Goal not reached"),
        )
        self.result_title.setText(result.algorithm_name)
        self.result_message.setText(result.message)
        language = ui_language(self)
        readable_actions = [action_label(action, language) for action in result.path]
        self.path_text.setPlainText(" → ".join(readable_actions) if readable_actions else ui_text(self, "Không có chuỗi hành động", "No action sequence"))
        self.metric_steps.set_value(str(result.solution_depth))
        self.metric_expanded.set_value(f"{result.expanded:,}")
        self.metric_time.set_value(f"{result.elapsed_ms:.2f} ms")
        self._populate_trace(result)
        self._set_animation_enabled(bool(result.states))
        self.show_frame(0)
        self.result_ready.emit(result)
        if len(result.states) > 1:
            self.animation_timer.start(self.speed_slider.value())
            self.play_btn.setText(ui_text(self, "Ⅱ  Tạm dừng", "Ⅱ  Pause"))

    def _on_error(self, message: str) -> None:
        self.status.set_status("error", "Có lỗi")
        self.result_message.setText(message)
        self.run_failed.emit(message)
        QMessageBox.critical(self, "Lỗi thuật toán", message)

    def _populate_trace(self, result: SearchResult) -> None:
        rows = result.steps[:5_000]
        self.trace_table.setRowCount(len(rows))
        for row, step in enumerate(rows):
            values = [
                step.index,
                step.phase,
                step.action or "",
                step.depth,
                "" if step.g is None else f"{step.g:.2f}",
                "" if step.h is None else f"{step.h:.2f}",
                "" if step.f is None else f"{step.f:.2f}",
                step.frontier,
                step.note,
            ]
            for column, value in enumerate(values):
                self.trace_table.setItem(row, column, QTableWidgetItem(str(value)))
        self.trace_table.resizeColumnsToContents()
        self.trace_table.horizontalHeader().setSectionResizeMode(8, QHeaderView.ResizeMode.Stretch)

    def _set_animation_enabled(self, enabled: bool) -> None:
        for widget in (self.prev_btn, self.play_btn, self.next_btn, self.speed_slider):
            widget.setEnabled(enabled)

    def _reset_result_view(self) -> None:
        self.animation_timer.stop()
        self.animation_index = 0
        self.step_indicator.setText(ui_text(self, "Bước 0 / 0", "Step 0 / 0"))
        self.move_label.setText(ui_text(self, "Bắt đầu", "Start"))
        self.animation_progress.setValue(0)
        self.metric_steps.set_value("—")
        self.metric_expanded.set_value("—")
        self.metric_time.set_value("—")
        self.result_title.setText(ui_text(self, "Chưa có kết quả", "No result yet"))
        self.result_message.setText(ui_text(self, "Chọn thuật toán và nhấn Chạy thuật toán.", "Choose an algorithm and press Run algorithm."))
        self.path_text.clear()
        self.trace_table.setRowCount(0)
        self._set_animation_enabled(False)

    def show_frame(self, index: int) -> None:
        if not self.current_result or not self.current_result.states:
            return
        index = max(0, min(index, len(self.current_result.states) - 1))
        self.animation_index = index
        state = self.current_result.states[index]
        moved_index = None
        if index > 0:
            moved_index = self.current_result.states[index - 1].index(0)
        self.board.set_state(state, moved_index)

        if index == 0:
            action_text = ui_text(self, "Bắt đầu", "Start")
        else:
            action = self.current_result.path[index - 1]
            language = ui_language(self)
            action_text = ui_text(self, f"Di chuyển ô trống: {ACTION_LABELS.get(action, action)}", f"Move blank: {action_label(action, language)}")
        self.move_label.setText(action_text)
        total = len(self.current_result.states) - 1
        self.step_indicator.setText(ui_text(self, f"Bước {index} / {total}", f"Step {index} / {total}"))
        self.animation_progress.setValue(int(index * 100 / max(1, total)))

    def toggle_animation(self) -> None:
        if not self.current_result or len(self.current_result.states) <= 1:
            return
        if self.animation_timer.isActive():
            self.animation_timer.stop()
            self.play_btn.setText(ui_text(self, "▶  Phát", "▶  Play"))
        else:
            if self.animation_index >= len(self.current_result.states) - 1:
                self.show_frame(0)
            self.animation_timer.start(self.speed_slider.value())
            self.play_btn.setText(ui_text(self, "Ⅱ  Tạm dừng", "Ⅱ  Pause"))

    def _speed_changed(self, value: int) -> None:
        # 520 ms is treated as the normal classroom demonstration speed.
        multiplier = 520 / max(1, value)
        self.speed_value.setText(f"{multiplier:.1f}×")
        if self.animation_timer.isActive():
            self.animation_timer.setInterval(value)

    def next_frame(self) -> None:
        if not self.current_result:
            return
        if self.animation_index >= len(self.current_result.states) - 1:
            self.animation_timer.stop()
            self.play_btn.setText(ui_text(self, "↻  Phát lại", "↻  Replay"))
            return
        self.show_frame(self.animation_index + 1)

    def prev_frame(self) -> None:
        if not self.current_result:
            return
        self.animation_timer.stop()
        self.play_btn.setText("▶  Phát")
        self.show_frame(self.animation_index - 1)


class PseudocodePage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 26)
        root.setSpacing(14)
        title, subtitle = page_header(
            "Thư viện thuật toán",
            "Nguyên lý, độ phức tạp, ưu nhược điểm và mã giả của 18 thuật toán.",
        )
        root.addWidget(title)
        root.addWidget(subtitle)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        self.list = QListWidget()
        self.list.setMinimumWidth(285)
        self.list.setMaximumWidth(390)
        for category in CATEGORY_ORDER:
            header = QListWidgetItem(category)
            header.setFlags(Qt.ItemFlag.NoItemFlags)
            header.setFont(QFont("Segoe UI", 9, QFont.Weight.DemiBold))
            self.list.addItem(header)
            for info in ALGORITHM_INFOS.values():
                if info.category == category:
                    item = QListWidgetItem(f"    {info.short_name} · {info.name}")
                    item.setData(Qt.ItemDataRole.UserRole, info.id)
                    self.list.addItem(item)
        self.list.currentItemChanged.connect(self._changed)

        detail = QFrame()
        detail_layout = panel_layout(detail, (18, 16, 18, 18))
        self.name = QLabel()
        self.name.setObjectName("PageTitle")
        self.summary = QTextBrowser()
        self.summary.setProperty("i18n_managed", True)
        self.code = QPlainTextEdit()
        self.code.setProperty("i18n_managed", True)
        self.code.setReadOnly(True)
        self.code.setFont(QFont("Consolas", 10))
        code_label = QLabel("Mã giả")
        code_label.setObjectName("SectionTitle")
        detail_layout.addWidget(self.name)
        detail_layout.addWidget(self.summary, 1)
        detail_layout.addWidget(code_label)
        detail_layout.addWidget(self.code, 2)

        splitter.addWidget(self.list)
        splitter.addWidget(detail)
        splitter.setSizes([320, 850])
        root.addWidget(splitter, 1)

        for index in range(self.list.count()):
            if self.list.item(index).data(Qt.ItemDataRole.UserRole):
                self.list.setCurrentRow(index)
                break

    def _changed(self, current, previous) -> None:
        if not current:
            return
        algorithm_id = current.data(Qt.ItemDataRole.UserRole)
        if not algorithm_id:
            return
        info = ALGORITHM_INFOS[algorithm_id]
        language = ui_language(self)
        self.name.setText(f"{info.short_name} · {info.name}")
        if language == LANG_EN:
            html = (
                f"<p><b>Group:</b> {algorithm_text(info, 'category', language)}</p>"
                f"<p>{algorithm_text(info, 'description', language)}</p>"
                f"<p><b>Strengths:</b> {algorithm_text(info, 'strengths', language)}</p>"
                f"<p><b>Limitations:</b> {algorithm_text(info, 'limitations', language)}</p>"
                f"<p><b>Complete:</b> {algorithm_text(info, 'complete', language)} &nbsp;&nbsp; <b>Optimal:</b> {algorithm_text(info, 'optimal', language)}</p>"
                f"<p><b>Time:</b> {info.time_complexity} &nbsp;&nbsp; <b>Space:</b> {info.space_complexity}</p>"
            )
            if info.adaptation_note:
                html += f"<p><b>8-puzzle adaptation:</b> {algorithm_text(info, 'adaptation_note', language)}</p>"
        else:
            html = (
                f"<p><b>Nhóm:</b> {info.category}</p>"
                f"<p>{info.description}</p>"
                f"<p><b>Ưu điểm:</b> {info.strengths}</p>"
                f"<p><b>Hạn chế:</b> {info.limitations}</p>"
                f"<p><b>Đầy đủ:</b> {info.complete} &nbsp;&nbsp; <b>Tối ưu:</b> {info.optimal}</p>"
                f"<p><b>Time:</b> {info.time_complexity} &nbsp;&nbsp; <b>Space:</b> {info.space_complexity}</p>"
            )
            if info.adaptation_note:
                html += f"<p><b>Áp dụng cho 8-puzzle:</b> {info.adaptation_note}</p>"
        self.summary.setHtml(html)
        self.code.setPlainText(algorithm_text(info, "pseudocode", language))


class ComparePage(QWidget):
    results_ready = Signal(object)

    METRICS = {
        "expanded": ("Node mở rộng", lambda r: float(r.expanded)),
        "generated": ("Node sinh ra", lambda r: float(r.generated)),
        "max_frontier": ("Frontier lớn nhất", lambda r: float(r.max_frontier)),
        "elapsed_ms": ("Thời gian (ms)", lambda r: float(r.elapsed_ms)),
        "solution_depth": ("Số bước lời giải", lambda r: float(r.solution_depth)),
    }

    def __init__(self, lab: LabPage, parent=None):
        super().__init__(parent)
        self.lab = lab
        self.worker: CompareWorker | None = None
        self.results: list[SearchResult] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 26)
        root.setSpacing(13)
        title, subtitle = page_header(
            "So sánh thực nghiệm",
            "Chạy ba thuật toán trên cùng START, GOAL và trực quan hóa kết quả theo nhiều dạng biểu đồ.",
        )
        root.addWidget(title)
        root.addWidget(subtitle)

        controls = QFrame()
        controls_layout = QHBoxLayout(controls)
        controls.setObjectName("Panel")
        controls_layout.setContentsMargins(14, 12, 14, 12)
        controls_layout.setSpacing(9)
        algorithms_label = QLabel("Thuật toán")
        algorithms_label.setObjectName("Caption")
        algorithms_label.setStyleSheet("font-weight:700;")
        controls_layout.addWidget(algorithms_label)
        self.combos: list[QComboBox] = []
        defaults = ["bfs", "astar", "beam"]
        for default in defaults:
            combo = QComboBox()
            combo.setMinimumWidth(205)
            for info in ALGORITHM_INFOS.values():
                combo.addItem(f"{info.short_name} — {info.category}", info.id)
            combo.setCurrentIndex(combo.findData(default))
            combo.setToolTip("Chọn thuật toán cần đưa vào cùng một phép so sánh")
            self.combos.append(combo)
            controls_layout.addWidget(combo, 1)
        self.run_btn = QPushButton("Chạy so sánh")
        self.run_btn.setObjectName("Success")
        self.run_btn.setMinimumWidth(132)
        self.run_btn.clicked.connect(self.run_compare)
        controls_layout.addWidget(self.run_btn)
        root.addWidget(controls)

        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.progress.setFormat("Sẵn sàng")
        root.addWidget(self.progress)

        summary = QHBoxLayout()
        summary.setSpacing(10)
        self.metric_fastest = MetricCard("Nhanh nhất", "—", "#4c78d8")
        self.metric_nodes = MetricCard("Ít node nhất", "—", "#2f8f6b")
        self.metric_depth = MetricCard("Lời giải ngắn nhất", "—", "#c98735")
        self.metric_success = MetricCard("Tỷ lệ thành công", "0/0", "#8a68c7")
        summary.addWidget(self.metric_fastest)
        summary.addWidget(self.metric_nodes)
        summary.addWidget(self.metric_depth)
        summary.addWidget(self.metric_success)
        root.addLayout(summary)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)

        table_panel = QFrame()
        table_layout = panel_layout(table_panel, (12, 11, 12, 12))
        table_title_row = QHBoxLayout()
        table_title = QLabel("Bảng số liệu")
        table_title.setObjectName("SectionTitle")
        table_title_row.addWidget(table_title)
        table_title_row.addStretch()
        table_hint = QLabel("Có thể bấm tiêu đề cột để sắp xếp")
        table_hint.setObjectName("Caption")
        table_title_row.addWidget(table_hint)
        table_layout.addLayout(table_title_row)

        self.table = QTableWidget(0, 8)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True)
        self.table.setHorizontalHeaderLabels(
            ["Thuật toán", "Kết quả", "Bước", "Expanded", "Generated", "Frontier max", "Thời gian", "Ghi chú"]
        )
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(7, QHeaderView.ResizeMode.Stretch)
        table_layout.addWidget(self.table, 1)

        export_row = QHBoxLayout()
        self.csv_btn = QPushButton("Xuất CSV")
        self.csv_btn.setObjectName("Secondary")
        self.csv_btn.clicked.connect(self.export_csv)
        self.csv_btn.setEnabled(False)
        self.json_btn = QPushButton("Xuất JSON")
        self.json_btn.setObjectName("Secondary")
        self.json_btn.clicked.connect(self.export_json)
        self.json_btn.setEnabled(False)
        export_row.addWidget(self.csv_btn)
        export_row.addWidget(self.json_btn)
        export_row.addStretch()
        table_layout.addLayout(export_row)

        chart_panel = QFrame()
        chart_layout = panel_layout(chart_panel, (12, 11, 12, 12))

        # Giữ tiêu đề và nút lưu cố định ở đầu panel. Phần biểu đồ bên dưới
        # có thanh cuộn dọc riêng để phần nhận xét không che tên thuật toán.
        chart_title_row = QHBoxLayout()
        chart_title_row.setSpacing(8)
        chart_title = QLabel("Trực quan hóa")
        chart_title.setObjectName("SectionTitle")
        chart_title_row.addWidget(chart_title)
        chart_title_row.addStretch()
        self.save_chart_btn = QPushButton("Lưu biểu đồ PNG")
        self.save_chart_btn.setObjectName("Secondary")
        self.save_chart_btn.setEnabled(False)
        self.save_chart_btn.clicked.connect(self.export_chart)
        chart_title_row.addWidget(self.save_chart_btn)
        chart_layout.addLayout(chart_title_row)

        chart_toolbar = QHBoxLayout()
        chart_toolbar.setSpacing(7)
        self.chart_type = QComboBox()
        self.chart_type.addItem("Cột", "bar")
        self.chart_type.addItem("Đường", "line")
        self.chart_type.addItem("Tròn", "pie")
        self.chart_type.addItem("Phân tán", "scatter")
        self.chart_type.setToolTip("Đổi loại biểu đồ mà không cần chạy lại thuật toán")
        self.chart_type.currentIndexChanged.connect(self._chart_options_changed)

        self.chart_metric = QComboBox()
        for key, (label, _) in self.METRICS.items():
            self.chart_metric.addItem(label, key)
        self.chart_metric.setCurrentIndex(self.chart_metric.findData("expanded"))
        self.chart_metric.currentIndexChanged.connect(self.update_chart)

        self.scatter_x_label = QLabel("Trục X")
        self.scatter_x_label.setObjectName("Caption")
        self.scatter_x_metric = QComboBox()
        for key, (label, _) in self.METRICS.items():
            self.scatter_x_metric.addItem(label, key)
        self.scatter_x_metric.setCurrentIndex(self.scatter_x_metric.findData("elapsed_ms"))
        self.scatter_x_metric.currentIndexChanged.connect(self.update_chart)

        self.sort_combo = QComboBox()
        self.sort_combo.addItem("Giữ thứ tự", "none")
        self.sort_combo.addItem("Tăng dần", "asc")
        self.sort_combo.addItem("Giảm dần", "desc")
        self.sort_combo.currentIndexChanged.connect(self.update_chart)

        chart_toolbar.addWidget(QLabel("Loại"))
        chart_toolbar.addWidget(self.chart_type)
        chart_toolbar.addWidget(QLabel("Chỉ số"))
        chart_toolbar.addWidget(self.chart_metric, 1)
        chart_toolbar.addWidget(self.scatter_x_label)
        chart_toolbar.addWidget(self.scatter_x_metric, 1)
        chart_toolbar.addWidget(self.sort_combo)
        chart_layout.addLayout(chart_toolbar)

        # Vùng cuộn dọc chỉ dành cho biểu đồ và phần nhận xét. Trên màn hình
        # thấp, người dùng kéo xuống xem nhận xét thay vì để nó đè lên trục X.
        self.chart_scroll = QScrollArea()
        self.chart_scroll.setObjectName("ChartScrollArea")
        self.chart_scroll.setWidgetResizable(True)
        self.chart_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.chart_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.chart_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        chart_scroll_body = QWidget()
        chart_scroll_body.setObjectName("ChartScrollBody")
        chart_scroll_layout = QVBoxLayout(chart_scroll_body)
        chart_scroll_layout.setContentsMargins(0, 0, 6, 0)
        chart_scroll_layout.setSpacing(10)

        self.chart = SimpleBarChart()
        self.chart.setMinimumHeight(410)
        chart_scroll_layout.addWidget(self.chart)

        insight_frame = QFrame()
        insight_frame.setObjectName("InsightCard")
        insight_layout = QHBoxLayout(insight_frame)
        insight_layout.setContentsMargins(12, 9, 12, 9)
        insight_layout.setSpacing(10)
        self.insight_badge = QLabel("NHẬN XÉT")
        self.insight_badge.setObjectName("InsightBadge")
        self.insight_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        insight_layout.addWidget(self.insight_badge, 0, Qt.AlignmentFlag.AlignTop)

        self.insight = QLabel("Chạy so sánh để hệ thống tổng hợp nhận xét.")
        self.insight.setObjectName("InsightText")
        self.insight.setWordWrap(True)
        self.insight.setMinimumHeight(34)
        insight_layout.addWidget(self.insight, 1)
        chart_scroll_layout.addWidget(insight_frame)
        chart_scroll_layout.addStretch()

        # Chiều cao tối thiểu đủ để hiển thị trọn tên BFS, A*, Local Beam.
        chart_scroll_body.setMinimumHeight(530)
        self.chart_scroll.setWidget(chart_scroll_body)
        chart_layout.addWidget(self.chart_scroll, 1)

        splitter.addWidget(table_panel)
        splitter.addWidget(chart_panel)
        splitter.setSizes([690, 560])
        root.addWidget(splitter, 1)
        self._chart_options_changed()

    def _short_name(self, result: SearchResult) -> str:
        info = ALGORITHM_INFOS.get(result.algorithm_id)
        return info.short_name if info else result.algorithm_name

    def run_compare(self) -> None:
        try:
            start = self.lab.start_editor.state()
            goal = self.lab.goal_editor.state()
        except Exception as exc:
            QMessageBox.warning(self, "Trạng thái không hợp lệ", str(exc))
            return
        ids: list[str] = []
        for combo in self.combos:
            algorithm_id = str(combo.currentData())
            if algorithm_id not in ids:
                ids.append(algorithm_id)
        if len(ids) < 2:
            QMessageBox.information(self, "Chưa đủ thuật toán", "Hãy chọn ít nhất hai thuật toán khác nhau để so sánh.")
            return
        self.run_btn.setEnabled(False)
        self.progress.setValue(0)
        self.progress.setFormat(ui_text(self, "Đang chuẩn bị — %p%", "Preparing — %p%"))
        self.worker = CompareWorker(ids, start, goal, self.lab.params(), self)
        self.worker.progress.connect(self._on_progress)
        self.worker.completed.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.worker.finished.connect(lambda: self.run_btn.setEnabled(True))
        self.worker.start()

    def _on_progress(self, value: int, name: str) -> None:
        self.progress.setValue(value)
        self.progress.setFormat(f"{name} — %p%")

    def _failed(self, message: str) -> None:
        self.progress.setFormat(ui_text(self, "Có lỗi", "Error"))
        QMessageBox.critical(self, "Lỗi", message)

    def _done(self, results: list[SearchResult]) -> None:
        self.results = results
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(results))
        for row, result in enumerate(results):
            values = [
                self._short_name(result),
                "Thành công" if result.success else "Chưa đạt",
                result.solution_depth,
                result.expanded,
                result.generated,
                result.max_frontier,
                f"{result.elapsed_ms:.3f} ms",
                result.message,
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column in (2, 3, 4, 5):
                    item.setData(Qt.ItemDataRole.EditRole, int(value))
                elif column == 6:
                    item.setData(Qt.ItemDataRole.EditRole, float(result.elapsed_ms))
                self.table.setItem(row, column, item)
        self.table.setSortingEnabled(True)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setSectionResizeMode(7, QHeaderView.ResizeMode.Stretch)
        self.csv_btn.setEnabled(True)
        self.json_btn.setEnabled(True)
        self.save_chart_btn.setEnabled(True)
        self.progress.setValue(100)
        self.progress.setFormat(ui_text(self, "Hoàn tất — 100%", "Completed — 100%"))
        self._update_summary()
        self.update_chart()
        self.results_ready.emit(results)

    def _update_summary(self) -> None:
        successful = [result for result in self.results if result.success]
        if not self.results:
            return
        fastest = min(self.results, key=lambda result: result.elapsed_ms)
        fewest_nodes = min(self.results, key=lambda result: result.expanded)
        if successful:
            shortest = min(successful, key=lambda result: result.solution_depth)
            depth_text = ui_text(self, f"{self._short_name(shortest)} · {shortest.solution_depth} bước", f"{self._short_name(shortest)} · {shortest.solution_depth} steps")
        else:
            depth_text = ui_text(self, "Chưa có lời giải", "No solution")
        self.metric_fastest.set_value(f"{self._short_name(fastest)} · {fastest.elapsed_ms:.2f} ms")
        self.metric_nodes.set_value(f"{self._short_name(fewest_nodes)} · {fewest_nodes.expanded:,}")
        self.metric_depth.set_value(depth_text)
        self.metric_success.set_value(f"{len(successful)}/{len(self.results)}")

        if ui_language(self) == LANG_EN:
            parts = [
                f"{self._short_name(fastest)} has the lowest runtime ({fastest.elapsed_ms:.2f} ms)",
                f"{self._short_name(fewest_nodes)} expands the fewest nodes ({fewest_nodes.expanded:,})",
            ]
            if successful:
                shortest = min(successful, key=lambda result: result.solution_depth)
                parts.append(f"{self._short_name(shortest)} produces the shortest solution ({shortest.solution_depth} steps)")
            self.insight.setText("Quick insight: " + "; ".join(parts) + ".")
        else:
            parts = [
                f"{self._short_name(fastest)} có thời gian thấp nhất ({fastest.elapsed_ms:.2f} ms)",
                f"{self._short_name(fewest_nodes)} mở rộng ít node nhất ({fewest_nodes.expanded:,})",
            ]
            if successful:
                shortest = min(successful, key=lambda result: result.solution_depth)
                parts.append(f"{self._short_name(shortest)} cho lời giải ngắn nhất ({shortest.solution_depth} bước)")
            self.insight.setText("Nhận xét nhanh: " + "; ".join(parts) + ".")

    def _chart_options_changed(self) -> None:
        scatter = self.chart_type.currentData() == "scatter"
        self.scatter_x_label.setVisible(scatter)
        self.scatter_x_metric.setVisible(scatter)
        self.sort_combo.setEnabled(not scatter)
        self.update_chart()

    def _metric_values(self, metric_key: str) -> list[tuple[str, float]]:
        _, getter = self.METRICS[metric_key]
        return [(self._short_name(result), getter(result)) for result in self.results]

    def update_chart(self) -> None:
        if not self.results:
            return
        chart_type = str(self.chart_type.currentData())
        metric_key = str(self.chart_metric.currentData())
        metric_title = self.METRICS[metric_key][0]
        data = self._metric_values(metric_key)
        secondary = None
        x_label = ""
        if chart_type == "scatter":
            x_key = str(self.scatter_x_metric.currentData())
            x_label = self.METRICS[x_key][0]
            secondary = self._metric_values(x_key)
            title = ui_text(self, f"Mối quan hệ: {x_label} và {metric_title}", f"Relationship: {x_label} and {metric_title}")
            subtitle = ui_text(self, "Mỗi điểm đại diện cho một thuật toán", "Each point represents one algorithm")
        else:
            order = str(self.sort_combo.currentData())
            if order in ("asc", "desc"):
                reverse = order == "desc"
                data = sorted(data, key=lambda item: item[1], reverse=reverse)
            title = metric_title
            subtitle = ui_text(self, f"{len(data)} thuật toán · cùng một trạng thái đầu và đích", f"{len(data)} algorithms · same start and goal states")
        self.chart.set_data(
            title,
            data,
            chart_type=chart_type,
            secondary=secondary,
            subtitle=subtitle,
            x_label=x_label,
            y_label=metric_title,
        )

    def export_chart(self) -> None:
        if not self.results:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Lưu biểu đồ", "8puzzle_chart.png", "PNG (*.png)")
        if path:
            if not path.lower().endswith(".png"):
                path += ".png"
            if self.chart.grab().save(path, "PNG"):
                QMessageBox.information(self, "Đã lưu biểu đồ", path)
            else:
                QMessageBox.warning(self, "Không thể lưu", "Không thể ghi ảnh biểu đồ vào vị trí đã chọn.")

    def export_csv(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Xuất CSV", "8puzzle_compare.csv", "CSV (*.csv)")
        if path:
            export_results_csv(self.results, path)
            QMessageBox.information(self, "Đã xuất", path)

    def export_json(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Xuất JSON", "8puzzle_compare.json", "JSON (*.json)")
        if path:
            export_results_json(self.results, path)
            QMessageBox.information(self, "Đã xuất", path)


class HistoryPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.results: list[SearchResult] = []
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 26)
        root.setSpacing(14)
        title, subtitle = page_header(
            "Lịch sử thực nghiệm",
            "Các lần chạy trong phiên hiện tại được lưu lại để đối chiếu và xuất dữ liệu.",
        )
        root.addWidget(title)
        root.addWidget(subtitle)
        self.table = QTableWidget(0, 9)
        self.table.setAlternatingRowColors(True)
        self.table.setHorizontalHeaderLabels(
            ["#", "Thuật toán", "Nhóm", "Kết quả", "Bước", "Expanded", "Generated", "Thời gian", "START → GOAL"]
        )
        self.table.horizontalHeader().setSectionResizeMode(8, QHeaderView.ResizeMode.Stretch)
        root.addWidget(self.table, 1)
        row = QHBoxLayout()
        self.export_json_btn = QPushButton("Xuất JSON")
        self.export_json_btn.setObjectName("Secondary")
        self.export_json_btn.clicked.connect(self.export_json)
        self.export_csv_btn = QPushButton("Xuất CSV")
        self.export_csv_btn.setObjectName("Secondary")
        self.export_csv_btn.clicked.connect(self.export_csv)
        self.clear_btn = QPushButton("Xóa lịch sử")
        self.clear_btn.setObjectName("Danger")
        self.clear_btn.clicked.connect(self.clear)
        row.addWidget(self.export_json_btn)
        row.addWidget(self.export_csv_btn)
        row.addStretch()
        row.addWidget(self.clear_btn)
        root.addLayout(row)

    def add_result(self, result: SearchResult) -> None:
        self.results.append(result)
        row = self.table.rowCount()
        self.table.insertRow(row)
        values = [
            row + 1,
            result.algorithm_name,
            result.category,
            "Thành công" if result.success else "Chưa đạt",
            result.solution_depth,
            result.expanded,
            result.generated,
            f"{result.elapsed_ms:.3f} ms",
            f"{state_text(result.start)} → {state_text(result.goal)}",
        ]
        for column, value in enumerate(values):
            self.table.setItem(row, column, QTableWidgetItem(str(value)))
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setSectionResizeMode(8, QHeaderView.ResizeMode.Stretch)

    def add_results(self, results: list[SearchResult]) -> None:
        for result in results:
            self.add_result(result)

    def clear(self) -> None:
        self.results.clear()
        self.table.setRowCount(0)

    def export_json(self) -> None:
        if not self.results:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Xuất lịch sử", "8puzzle_history.json", "JSON (*.json)")
        if path:
            export_results_json(self.results, path)
            QMessageBox.information(self, "Đã xuất", path)

    def export_csv(self) -> None:
        if not self.results:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Xuất lịch sử", "8puzzle_history.csv", "CSV (*.csv)")
        if path:
            export_results_csv(self.results, path)
            QMessageBox.information(self, "Đã xuất", path)


class ReportPage(QWidget):
    def __init__(self, lab: LabPage, parent=None):
        super().__init__(parent)
        self.lab = lab
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 22, 26, 26)
        root.setSpacing(14)
        title, subtitle = page_header(
            "PEAS và báo cáo cá nhân",
            "Tổng hợp mô hình tác tử, yêu cầu bài tập và công cụ xuất minh chứng.",
        )
        root.addWidget(title)
        root.addWidget(subtitle)

        tabs = QTabWidget()
        peas = QTextBrowser()
        peas.setHtml(
            """
            <h2>Mô hình PEAS cho tác tử giải 8-puzzle</h2>
            <table cellspacing='8'>
            <tr><td><b>Performance</b></td><td>Tìm đúng GOAL; ưu tiên ít bước, ít node mở rộng, thời gian thấp và không vượt giới hạn tài nguyên.</td></tr>
            <tr><td><b>Environment</b></td><td>Bảng 3×3 gồm tám ô số và một ô trống; môi trường tuần tự, xác định, rời rạc và quan sát đầy đủ ở bài toán chuẩn.</td></tr>
            <tr><td><b>Actuators</b></td><td>Di chuyển ô trống lên, xuống, trái hoặc phải khi hành động hợp lệ.</td></tr>
            <tr><td><b>Sensors</b></td><td>Quan sát cấu hình 9 ô, vị trí ô trống, START, GOAL và các giá trị g(n), h(n), f(n).</td></tr>
            </table>
            <h3>Biểu diễn trạng thái</h3>
            <p>Mỗi trạng thái là một tuple 9 phần tử. Với một parity, không gian khả đạt có 9!/2 = 181.440 cấu hình.</p>
            <h3>Goal test</h3>
            <p>state == goal. Tính khả giải được kiểm tra bằng parity số nghịch thế.</p>
            """
        )
        requirements = QTextBrowser()
        requirements.setHtml(
            """
            <h2>Đối chiếu yêu cầu bài tập</h2>
            <p>✓ Nêu bài toán, PEAS, START và GOAL.</p>
            <p>✓ Chọn và chạy 18 thuật toán thuộc 6 nhóm.</p>
            <p>✓ Mỗi thuật toán có mô tả, mã giả, độ phức tạp và nhật ký tìm lời giải.</p>
            <p>✓ Hoạt ảnh cho phép phát, tạm dừng, tiến và lùi từng trạng thái.</p>
            <p>✓ So sánh ba thuật toán bằng cùng điều kiện, có bảng và biểu đồ.</p>
            <p>✓ Lưu lịch sử và xuất báo cáo HTML, CSV, JSON.</p>
            <p>✓ Toàn bộ thuật toán được cài đặt bằng Python.</p>
            <p><b>Lưu ý:</b> CSP, AND-OR, Belief-State và nhóm đối kháng là các mô hình thích nghi học thuật vì 8-puzzle chuẩn là bài toán xác định, đơn tác tử.</p>
            """
        )

        export = QWidget()
        export_layout = QVBoxLayout(export)
        export_layout.setContentsMargins(12, 12, 12, 12)
        github_card = QFrame()
        github_layout = panel_layout(github_card)
        github_title = QLabel("Mã nguồn GitHub")
        github_title.setObjectName("SectionTitle")
        self.github = QLineEdit(GITHUB_URL)
        self.github.setReadOnly(True)
        open_btn = QPushButton("Mở repository")
        open_btn.setObjectName("Secondary")
        open_btn.clicked.connect(lambda: webbrowser.open(self.github.text()))
        github_layout.addWidget(github_title)
        github_layout.addWidget(self.github)
        github_layout.addWidget(open_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        report_card = QFrame()
        report_layout = panel_layout(report_card)
        report_title = QLabel("Xuất báo cáo cho lần chạy hiện tại")
        report_title.setObjectName("SectionTitle")
        note = QLabel(
            "Báo cáo HTML gồm START, GOAL, kết quả, mã giả, độ phức tạp, solution path và tối đa 500 bước trace."
        )
        note.setWordWrap(True)
        note.setObjectName("Muted")
        export_btn = QPushButton("Xuất báo cáo HTML")
        export_btn.clicked.connect(self.export_html)
        report_layout.addWidget(report_title)
        report_layout.addWidget(note)
        report_layout.addWidget(export_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        export_layout.addWidget(github_card)
        export_layout.addWidget(report_card)
        export_layout.addStretch()

        tabs.addTab(peas, "PEAS")
        tabs.addTab(requirements, "Yêu cầu bài tập")
        tabs.addTab(export, "GitHub và xuất báo cáo")
        root.addWidget(tabs, 1)

    def export_html(self) -> None:
        result = self.lab.current_result
        if result is None:
            QMessageBox.information(self, "Chưa có kết quả", "Hãy chạy một thuật toán trước.")
            return
        default = f"Bao_cao_{result.algorithm_id}_8puzzle.html"
        path, _ = QFileDialog.getSaveFileName(self, "Xuất báo cáo", default, "HTML (*.html)")
        if path:
            export_result_html(result, path)
            QMessageBox.information(self, "Đã xuất", f"Đã tạo báo cáo:\n{path}")
            webbrowser.open(Path(path).resolve().as_uri())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = QSettings("UTE", "8PuzzleAILab")
        self.setWindowTitle("8 Puzzle — Trực quan hóa thuật toán")
        self.resize(1540, 900)
        self.setMinimumSize(1180, 720)
        self.dark = self.settings.value("dark_theme", True, bool)
        self.language = self.settings.value("language", LANG_VI, str)
        if self.language not in (LANG_VI, LANG_EN):
            self.language = LANG_VI
        self._page_animation: QPropertyAnimation | None = None
        self.setStyleSheet(DARK_STYLESHEET if self.dark else LIGHT_STYLESHEET)

        container = QWidget()
        self.setCentralWidget(container)
        root = QHBoxLayout(container)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(204)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(14, 18, 14, 14)
        sidebar_layout.setSpacing(5)

        app_title = QLabel("8 Puzzle")
        app_title.setObjectName("AppTitle")
        app_subtitle = QLabel("Trực quan hóa thuật toán\nPython · 18 phương pháp")
        app_subtitle.setObjectName("AppSubtitle")
        app_subtitle.setWordWrap(True)
        sidebar_layout.addWidget(app_title)
        sidebar_layout.addWidget(app_subtitle)
        accent_line = QFrame()
        accent_line.setFixedHeight(3)
        accent_line.setStyleSheet("background:#5b8fbe;border:0;border-radius:1px;")
        sidebar_layout.addWidget(accent_line)
        sidebar_layout.addSpacing(15)

        self.nav_buttons: list[QPushButton] = []
        navs = [
            ("Tổng quan", 0),
            ("Chạy thuật toán", 1),
            ("Mã giả", 2),
            ("So sánh", 3),
            ("Lịch sử", 4),
            ("PEAS và báo cáo", 5),
        ]
        for text, index in navs:
            button = QPushButton(text)
            button.setObjectName("NavButton")
            button.setCheckable(True)
            button.clicked.connect(lambda checked=False, i=index: self.show_page(i))
            sidebar_layout.addWidget(button)
            self.nav_buttons.append(button)

        sidebar_layout.addStretch()
        github_btn = QPushButton("GitHub")
        github_btn.setObjectName("Secondary")
        github_btn.clicked.connect(lambda: webbrowser.open(GITHUB_URL))
        sidebar_layout.addWidget(github_btn)
        engine_label = QLabel("Python · sẵn sàng")
        engine_label.setObjectName("Caption")
        engine_label.setStyleSheet("color:#65c79e;")
        sidebar_layout.addWidget(engine_label)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        topbar = QFrame()
        topbar.setObjectName("Topbar")
        topbar.setFixedHeight(54)
        topbar_layout = QHBoxLayout(topbar)
        topbar_layout.setContentsMargins(20, 8, 18, 8)
        self.top_title = QLabel("Tổng quan")
        self.top_title.setStyleSheet("font-size:15px;font-weight:650;")
        topbar_layout.addWidget(self.top_title)
        topbar_layout.addStretch()
        self.global_status = StatusPill("Sẵn sàng")
        topbar_layout.addWidget(self.global_status)
        self.language_btn = QPushButton("English" if self.language == LANG_VI else "Tiếng Việt")
        self.language_btn.setObjectName("Secondary")
        self.language_btn.setMinimumWidth(94)
        self.language_btn.setToolTip("Chuyển đổi ngôn ngữ / Switch language")
        self.language_btn.clicked.connect(self.toggle_language)
        topbar_layout.addWidget(self.language_btn)
        self.theme_btn = QPushButton("Chế độ sáng" if self.dark else "Chế độ tối")
        self.theme_btn.setObjectName("Secondary")
        self.theme_btn.clicked.connect(self.toggle_theme)
        topbar_layout.addWidget(self.theme_btn)
        content_layout.addWidget(topbar)

        self.stack = QStackedWidget()
        content_layout.addWidget(self.stack, 1)
        self.home = HomePage()
        self.lab = LabPage()
        self.pseudo = PseudocodePage()
        self.compare = ComparePage(self.lab)
        self.history = HistoryPage()
        self.report = ReportPage(self.lab)
        for page in (self.home, self.lab, self.pseudo, self.compare, self.history, self.report):
            self.stack.addWidget(page)

        self.home.open_lab.connect(lambda: self.show_page(1))
        self.lab.result_ready.connect(self._new_result)
        self.lab.run_started.connect(self._on_run_started)
        self.lab.run_failed.connect(self._on_run_failed)
        self.compare.results_ready.connect(self._compare_results)

        root.addWidget(sidebar)
        root.addWidget(content, 1)
        self.page_titles = [
            "Tổng quan",
            "Chạy thuật toán",
            "Thư viện mã giả",
            "So sánh thực nghiệm",
            "Lịch sử",
            "PEAS và báo cáo",
        ]

        saved_geometry = self.settings.value("window_geometry")
        if saved_geometry is not None:
            self.restoreGeometry(saved_geometry)
        saved_splitter = self.settings.value("splitter_sizes")
        if isinstance(saved_splitter, list) and len(saved_splitter) == 3:
            try:
                self.lab.splitter.setSizes([int(value) for value in saved_splitter])
            except (TypeError, ValueError):
                pass

        last_page = self.settings.value("last_page", 0, int)
        self.show_page(max(0, min(last_page, len(self.page_titles) - 1)))
        last_algorithm = self.settings.value("last_algorithm", "bfs", str)
        algorithm_index = self.lab.algorithm_combo.findData(last_algorithm)
        if algorithm_index >= 0:
            self.lab.algorithm_combo.setCurrentIndex(algorithm_index)

        # Re-translate dynamic panels after their content changes.
        self.lab.algorithm_combo.currentIndexChanged.connect(
            lambda: QTimer.singleShot(0, self.apply_current_language)
        )
        self.pseudo.list.currentItemChanged.connect(
            lambda *_: QTimer.singleShot(0, self.apply_current_language)
        )
        for combo in (self.compare.chart_type, self.compare.chart_metric, self.compare.scatter_x_metric, self.compare.sort_combo):
            combo.currentIndexChanged.connect(lambda: QTimer.singleShot(0, self.apply_current_language))
        self.apply_current_language()

    def show_page(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        page = self.stack.currentWidget()
        effect = QGraphicsOpacityEffect(page)
        page.setGraphicsEffect(effect)
        animation = QPropertyAnimation(effect, b"opacity", self)
        animation.setDuration(155)
        animation.setStartValue(0.76)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        def clear_effect() -> None:
            page.setGraphicsEffect(None)

        animation.finished.connect(clear_effect)
        self._page_animation = animation
        animation.start()

        self.top_title.setText(self.page_titles[index])
        for button_index, button in enumerate(self.nav_buttons):
            button.setChecked(button_index == index)
        self.settings.setValue("last_page", index)
        QTimer.singleShot(0, self.apply_current_language)

    def _on_run_started(self, name: str) -> None:
        self.global_status.set_status("running", f"Running {name}" if self.language == LANG_EN else f"Đang chạy {name}")

    def _on_run_failed(self, _message: str) -> None:
        self.global_status.set_status("error", "Error" if self.language == LANG_EN else "Có lỗi")

    def _new_result(self, result: SearchResult) -> None:
        self.history.add_result(result)
        self.global_status.set_status("success", ("Completed" if result.success else "Finished") if self.language == LANG_EN else ("Hoàn tất" if result.success else "Đã kết thúc"))
        self.settings.setValue("last_algorithm", result.algorithm_id)
        QTimer.singleShot(0, self.apply_current_language)

    def _compare_results(self, results: list[SearchResult]) -> None:
        self.history.add_results(results)
        self.global_status.set_status("success", "Comparison complete" if self.language == LANG_EN else "So sánh xong")
        QTimer.singleShot(0, self.apply_current_language)

    def apply_current_language(self) -> None:
        # Rebuild metadata-rich panels first, then translate the remaining widget tree.
        self.lab._algorithm_changed()
        current_item = self.pseudo.list.currentItem()
        if current_item is not None:
            self.pseudo._changed(current_item, None)
        apply_language(self, self.language)
        self.compare.chart.set_language(self.language)
        self.language_btn.setText("English" if self.language == LANG_VI else "Tiếng Việt")
        if self.language == LANG_EN:
            self.theme_btn.setText("Light mode" if self.dark else "Dark mode")
        else:
            self.theme_btn.setText("Chế độ sáng" if self.dark else "Chế độ tối")
        current_index = self.stack.currentIndex()
        if 0 <= current_index < len(self.page_titles):
            if self.language == LANG_EN:
                english_titles = [
                    "Overview", "Run algorithm", "Pseudocode library",
                    "Experimental comparison", "History", "PEAS and report",
                ]
                self.top_title.setText(english_titles[current_index])
            else:
                self.top_title.setText(self.page_titles[current_index])

    def toggle_language(self) -> None:
        self.language = LANG_EN if self.language == LANG_VI else LANG_VI
        self.settings.setValue("language", self.language)
        self.apply_current_language()

    def toggle_theme(self) -> None:
        self.dark = not self.dark
        self.setStyleSheet(DARK_STYLESHEET if self.dark else LIGHT_STYLESHEET)
        if self.language == LANG_EN:
            self.theme_btn.setText("Light mode" if self.dark else "Dark mode")
        else:
            self.theme_btn.setText("Chế độ sáng" if self.dark else "Chế độ tối")
        self.settings.setValue("dark_theme", self.dark)

    def closeEvent(self, event):  # noqa: N802
        self.settings.setValue("window_geometry", self.saveGeometry())
        self.settings.setValue("splitter_sizes", self.lab.splitter.sizes())
        super().closeEvent(event)

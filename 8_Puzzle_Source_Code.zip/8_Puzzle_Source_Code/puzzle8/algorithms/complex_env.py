from __future__ import annotations

from collections import deque
from time import perf_counter

from puzzle8.core import ACTIONS, State, apply_action, manhattan, neighbors, reconstruct_path, replay_actions
from .common import SearchLimits, finalize, step, timed_out


def and_or_search(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]; expanded=generated=0; trace=[]
    def or_search(state: State, path_set: set[State], depth: int):
        nonlocal expanded, generated
        if timed_out(t0,limits) or expanded>=limits.max_nodes: return None
        expanded+=1
        step(steps,state,depth=depth,g=depth,h=manhattan(state,goal),f=depth+manhattan(state,goal),explored=expanded,phase="OR",note="OR node: chọn một hành động")
        trace.append(f"OR depth={depth}: {state}")
        if state==goal: return [], [state]
        if depth>=limits.max_depth or state in path_set: return None
        actions=[]
        for nxt,mv in neighbors(state): actions.append((manhattan(nxt,goal),mv,[nxt]))
        actions.sort(key=lambda x:x[0])
        for _,action,results in actions:
            generated+=len(results)
            trace.append(f"AND action={action}, outcomes={len(results)}")
            step(steps,state,action=action,depth=depth,g=depth,h=manhattan(state,goal),f=depth+manhattan(state,goal),explored=expanded,phase="AND",note=f"AND node: phải giải được {len(results)} kết quả")
            combined_actions=[action]; combined_states=[state]; ok=True
            for outcome in results:
                sub=or_search(outcome,path_set|{state},depth+1)
                if sub is None: ok=False; break
                sub_actions,sub_states=sub; combined_actions.extend(sub_actions); combined_states.extend(sub_states)
            if ok: return combined_actions,combined_states
        return None
    result=or_search(start,set(),0)
    if result:
        path,states=result
        return finalize("andor",start,goal,t0,success=True,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=limits.max_depth,message="AND-OR tìm được kế hoạch; trong 8-puzzle xác định mỗi AND node có một outcome.",metadata={"trace":trace[:500]})
    return finalize("andor",start,goal,t0,success=False,path=[],states=[start],steps=steps,expanded=expanded,generated=generated,max_frontier=limits.max_depth,message="AND-OR không tìm thấy kế hoạch trong giới hạn.",metadata={"trace":trace[:500]})


def belief_state_search(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]
    # Tạo belief gồm trạng thái thật và một trạng thái lân cận, mô hình hành động không hợp lệ là no-op.
    first_neighbor=next(iter(neighbors(start)))[0]
    initial=frozenset({start,first_neighbor})
    q=deque([initial]); parent={initial:(None,None)}; expanded=generated=0; max_frontier=1
    found=None
    while q:
        if timed_out(t0,limits) or expanded>=min(limits.max_nodes,100_000): break
        belief=q.popleft(); expanded+=1
        representative=min(belief,key=lambda s:manhattan(s,goal))
        step(steps,representative,depth=0,h=max(manhattan(s,goal) for s in belief),frontier=len(q),explored=expanded,phase="BELIEF",note=f"Belief size={len(belief)}",extra={"belief":[list(s) for s in belief]})
        if all(s==goal for s in belief): found=belief; break
        for action in ACTIONS:
            next_belief=frozenset(apply_action(s,action,illegal_noop=True) for s in belief)
            generated+=1
            if next_belief not in parent:
                parent[next_belief]=(belief,action); q.append(next_belief)
        max_frontier=max(max_frontier,len(q))
    if found is None:
        return finalize("belief",start,goal,t0,success=False,path=[],states=[start],steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message="Không tìm được chuỗi hành động hợp nhất belief trong giới hạn.",metadata={"initial_belief":[list(s) for s in initial]})
    actions=[]; beliefs=[]; cur=found
    while cur is not None:
        beliefs.append(cur); prev,act=parent[cur]
        if act is not None: actions.append(act)
        cur=prev
    actions.reverse(); beliefs.reverse()
    concrete_states = replay_actions(start, actions, illegal_noop=True)
    return finalize("belief",start,goal,t0,success=True,path=actions,states=concrete_states,steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message="Belief-State BFS tìm được chuỗi hành động đưa mọi trạng thái có thể về goal.",metadata={"beliefs":[[list(s) for s in b] for b in beliefs],"initial_belief":[list(s) for s in initial]})


def lrta_star(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]; H: dict[State,float]={}; expanded=generated=0; best_states=[start]; best_path=[]
    for trial in range(1,101):
        current=start; states=[start]; path=[]; visits: dict[State,int]={}
        for local_step in range(max(limits.max_depth*20,200)):
            if timed_out(t0,limits) or expanded>=limits.max_nodes: break
            expanded+=1; visits[current]=visits.get(current,0)+1
            if current==goal:
                return finalize("lrta",start,goal,t0,success=True,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=len(H),message=f"LRTA* đạt đích sau {trial} trial.",metadata={"trials":trial,"learned_states":len(H)})
            options=[]
            for nxt,mv in neighbors(current):
                generated+=1; value=1+H.get(nxt,manhattan(nxt,goal)); options.append((value,visits.get(nxt,0),manhattan(nxt,goal),nxt,mv))
            old=H.get(current,manhattan(current,goal)); new=min(v[0] for v in options); H[current]=max(old,new)
            options.sort(key=lambda x:(x[0],x[1],x[2])); value,_,_,nxt,mv=options[0]
            step(steps,current,action=mv,depth=len(path),g=len(path),h=H[current],f=value,explored=expanded,phase="LEARN",note=f"trial={trial}: H({current}) {old:.1f}→{H[current]:.1f}",extra={"trial":trial,"learned_h":H[current]})
            current=nxt; path.append(mv); states.append(nxt)
            if manhattan(current,goal)<manhattan(best_states[-1],goal): best_states=states.copy(); best_path=path.copy()
        if timed_out(t0,limits) or expanded>=limits.max_nodes: break
    return finalize("lrta",start,goal,t0,success=False,path=best_path,states=best_states,steps=steps,expanded=expanded,generated=generated,max_frontier=len(H),message="LRTA* chưa đạt goal trong giới hạn trial; trả về đường đi tốt nhất.",metadata={"trials":trial,"learned_states":len(H)})

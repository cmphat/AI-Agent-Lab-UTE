from __future__ import annotations

from math import inf
import random
from time import perf_counter

from puzzle8.core import State, manhattan, neighbors
from .common import SearchLimits, finalize, step, timed_out


def _utility(state: State, goal: State, visited: set[State] | None = None) -> float:
    if state == goal:
        return 10_000.0
    value = -100.0 * manhattan(state, goal)
    if visited and state in visited:
        value -= 35.0
    return value


def minimax_solver(start: State, goal: State, limits: SearchLimits):
    return _receding_solver("minimax", start, goal, limits, mode="minimax")


def alphabeta_solver(start: State, goal: State, limits: SearchLimits):
    return _receding_solver("alphabeta", start, goal, limits, mode="alphabeta")


def expectimax_solver(start: State, goal: State, limits: SearchLimits):
    return _receding_solver("expectimax", start, goal, limits, mode="expectimax")


def _receding_solver(algorithm_id: str, start: State, goal: State, limits: SearchLimits, *, mode: str):
    t0=perf_counter(); steps=[]; current=start; states=[start]; path=[]; visited={start}; expanded=generated=pruned=0
    rng=random.Random(limits.seed)

    def search(state: State, depth: int, maximizing: bool, alpha: float=-inf, beta: float=inf) -> float:
        nonlocal expanded,generated,pruned
        expanded+=1
        if state==goal or depth==0 or expanded>=limits.max_nodes or timed_out(t0,limits):
            return _utility(state,goal,visited)
        children=list(neighbors(state)); generated+=len(children)
        if not children:return _utility(state,goal,visited)
        children.sort(key=lambda item:manhattan(item[0],goal))
        if maximizing:
            value=-inf
            for child,_ in children:
                value=max(value,search(child,depth-1,False,alpha,beta))
                if mode=="alphabeta":
                    alpha=max(alpha,value)
                    if alpha>=beta:pruned+=1;break
            return value
        if mode=="expectimax":
            # Chance node: outcome gần action dự kiến có xác suất cao hơn.
            weights=[]
            for child,_ in children:
                weights.append((0.65 if child==children[0][0] else 0.35/max(1,len(children)-1),child))
            return sum(p*search(child,depth-1,True,alpha,beta) for p,child in weights)
        value=inf
        for child,_ in reversed(children):
            value=min(value,search(child,depth-1,True,alpha,beta))
            if mode=="alphabeta":
                beta=min(beta,value)
                if alpha>=beta:pruned+=1;break
        return value

    max_actions=max(30,limits.max_depth*3)
    for turn in range(max_actions):
        if current==goal:
            return finalize(algorithm_id,start,goal,t0,success=True,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=limits.adversarial_depth,message=f"{algorithm_id} đạt đích bằng quyết định receding-horizon.",metadata={"search_depth":limits.adversarial_depth,"pruned":pruned})
        if timed_out(t0,limits) or expanded>=limits.max_nodes:break
        action_values=[]
        options=list(neighbors(current)); options.sort(key=lambda item:manhattan(item[0],goal))
        for child,mv in options:
            value=search(child,max(0,limits.adversarial_depth-1),False,-inf,inf)
            # tie-break ưu tiên giảm Manhattan và tránh quay lại trạng thái cũ
            value += -0.01*manhattan(child,goal) - (10 if child in visited else 0)
            action_values.append((value,-manhattan(child,goal),rng.random(),child,mv))
        action_values.sort(reverse=True,key=lambda x:(x[0],x[1],x[2]))
        value,_,_,nxt,mv=action_values[0]
        step(steps,current,action=mv,depth=turn,g=turn,h=manhattan(current,goal),f=-value,explored=expanded,phase="MAX" if mode!="expectimax" else "MAX/CHANCE",note=f"Chọn {mv}; giá trị {value:.2f}",extra={"action_values":[{"move":a[4],"value":a[0]} for a in action_values],"pruned":pruned})
        current=nxt; path.append(mv); states.append(nxt); visited.add(nxt)
    return finalize(algorithm_id,start,goal,t0,success=current==goal,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=limits.adversarial_depth,message=f"{algorithm_id} dừng trước khi đạt goal; đây là mô hình ra quyết định đối kháng giáo dục.",metadata={"search_depth":limits.adversarial_depth,"pruned":pruned})

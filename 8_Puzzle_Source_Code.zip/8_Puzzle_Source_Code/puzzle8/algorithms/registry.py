from __future__ import annotations

from collections.abc import Callable
from time import perf_counter

from puzzle8.core import SearchResult, State, is_solvable
from .common import SearchLimits, make_limits, finalize
from .classical import bfs, dfs, ids, ucs, greedy, astar
from .local_search import hill_climbing, local_beam, simulated_annealing
from .complex_env import and_or_search, belief_state_search, lrta_star
from .csp import constraint_propagation_ac3, backtracking_csp, min_conflicts_csp
from .adversarial import minimax_solver, alphabeta_solver, expectimax_solver

Solver = Callable[[State, State, SearchLimits], SearchResult]

ALGORITHMS: dict[str, Solver] = {
    "bfs": bfs,
    "dfs": dfs,
    "ids": ids,
    "ucs": ucs,
    "greedy": greedy,
    "astar": astar,
    "hill": hill_climbing,
    "beam": local_beam,
    "sa": simulated_annealing,
    "andor": and_or_search,
    "belief": belief_state_search,
    "lrta": lrta_star,
    "ac3": constraint_propagation_ac3,
    "backtracking": backtracking_csp,
    "minconflicts": min_conflicts_csp,
    "minimax": minimax_solver,
    "alphabeta": alphabeta_solver,
    "expectimax": expectimax_solver,
}


def run_algorithm(
    algorithm_id: str,
    start: State,
    goal: State,
    params: dict | None = None,
) -> SearchResult:
    if algorithm_id not in ALGORITHMS:
        raise KeyError(f"Thuật toán không tồn tại: {algorithm_id}")
    if not is_solvable(start, goal):
        now=perf_counter()
        return finalize(
            algorithm_id,start,goal,now,success=False,path=[],states=[start],steps=[],
            expanded=0,generated=0,max_frontier=0,
            message="Start và goal khác parity nghịch thế nên bài toán không giải được.",
        )
    limits=make_limits(params)
    return ALGORITHMS[algorithm_id](start,goal,limits)

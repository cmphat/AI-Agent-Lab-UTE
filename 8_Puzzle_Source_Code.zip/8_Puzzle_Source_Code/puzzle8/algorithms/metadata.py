from __future__ import annotations

from puzzle8.core import AlgorithmInfo

ALGORITHM_INFOS: dict[str, AlgorithmInfo] = {
    "bfs": AlgorithmInfo(
        id="bfs", name="Breadth-First Search", short_name="BFS", category="Tìm kiếm mù thông tin",
        description="Mở rộng toàn bộ trạng thái theo từng mức độ sâu bằng hàng đợi FIFO.",
        strengths="Đầy đủ; tối ưu khi mọi bước có cùng chi phí; dễ minh họa.",
        limitations="Tốn rất nhiều bộ nhớ khi không gian trạng thái lớn.",
        complete="Có", optimal="Có, khi chi phí bước bằng nhau", time_complexity="O(b^d)", space_complexity="O(b^d)",
        pseudocode="""BFS(start, goal):
    frontier ← Queue([start])
    parent[start] ← null
    while frontier không rỗng:
        state ← frontier.pop_front()
        if state = goal: trả về đường đi
        for mỗi successor của state:
            if successor chưa được khám phá:
                parent[successor] ← state
                frontier.push_back(successor)
    trả về thất bại""",
    ),
    "dfs": AlgorithmInfo(
        id="dfs", name="Depth-First Search", short_name="DFS", category="Tìm kiếm mù thông tin",
        description="Đi sâu vào một nhánh trước khi quay lui sang nhánh khác bằng ngăn xếp LIFO.",
        strengths="Ít bộ nhớ; dễ cài đặt; có thể tìm lời giải sâu nhanh.",
        limitations="Không tối ưu; có thể đi vào nhánh rất sâu hoặc vòng lặp.",
        complete="Có khi giới hạn độ sâu và tránh lặp", optimal="Không", time_complexity="O(b^m)", space_complexity="O(bm)",
        pseudocode="""DFS(start, goal, limit):
    stack ← [(start, 0)]
    while stack không rỗng:
        state, depth ← stack.pop()
        if state = goal: trả về đường đi
        if depth < limit:
            đẩy các successor chưa thăm vào stack
    trả về thất bại""",
    ),
    "ids": AlgorithmInfo(
        id="ids", name="Iterative Deepening Search", short_name="IDS", category="Tìm kiếm mù thông tin",
        description="Lặp tìm kiếm theo chiều sâu với giới hạn tăng dần 0, 1, 2, ...",
        strengths="Đầy đủ như BFS nhưng dùng bộ nhớ gần DFS.", limitations="Lặp lại việc mở rộng các tầng nông.",
        complete="Có", optimal="Có, khi chi phí bước bằng nhau", time_complexity="O(b^d)", space_complexity="O(bd)",
        pseudocode="""IDS(start, goal):
    for limit = 0 đến maxDepth:
        result ← DLS(start, goal, limit)
        if result thành công: trả về result
    trả về thất bại""",
    ),
    "ucs": AlgorithmInfo(
        id="ucs", name="Uniform Cost Search", short_name="UCS", category="Tìm kiếm có thông tin",
        description="Luôn mở rộng trạng thái có tổng chi phí g(n) nhỏ nhất.",
        strengths="Đầy đủ và tối ưu với chi phí dương.", limitations="Không dùng heuristic nên có thể mở rộng nhiều node.",
        complete="Có", optimal="Có", time_complexity="O(b^(1+⌊C*/ε⌋))", space_complexity="Tương đương số node đã sinh",
        pseudocode="""UCS(start, goal):
    frontier ← PriorityQueue theo g(n)
    g(start) ← 0
    while frontier không rỗng:
        state ← pop node có g nhỏ nhất
        if state = goal: trả về đường đi
        relax từng successor với newG = g(state)+cost""",
    ),
    "greedy": AlgorithmInfo(
        id="greedy", name="Greedy Best-First Search", short_name="Greedy", category="Tìm kiếm có thông tin",
        description="Ưu tiên trạng thái có heuristic h(n) nhỏ nhất.",
        strengths="Thường tìm lời giải nhanh khi heuristic tốt.", limitations="Không đảm bảo tối ưu; có thể bị đánh lừa bởi heuristic.",
        complete="Có trong không gian hữu hạn khi tránh lặp", optimal="Không", time_complexity="O(b^m)", space_complexity="O(b^m)",
        pseudocode="""Greedy(start, goal):
    frontier ← PriorityQueue theo h(n)
    while frontier không rỗng:
        state ← pop node có h nhỏ nhất
        if state = goal: trả về đường đi
        thêm successor chưa thăm với priority = h(successor)""",
    ),
    "astar": AlgorithmInfo(
        id="astar", name="A* Search", short_name="A*", category="Tìm kiếm có thông tin",
        description="Kết hợp chi phí đã đi g(n) và ước lượng còn lại h(n): f(n)=g(n)+h(n).",
        strengths="Đầy đủ và tối ưu khi heuristic admissible/consistent.", limitations="Có thể tốn bộ nhớ lớn.",
        complete="Có", optimal="Có với heuristic phù hợp", time_complexity="Phụ thuộc heuristic; xấu nhất O(b^d)", space_complexity="O(b^d)",
        pseudocode="""A*(start, goal):
    frontier ← PriorityQueue theo f(n)=g(n)+h(n)
    g(start) ← 0
    while frontier không rỗng:
        state ← pop node có f nhỏ nhất
        if state = goal: trả về đường đi
        for successor:
            tentativeG ← g(state)+1
            nếu tentativeG tốt hơn:
                cập nhật parent, g, f
                push successor""",
    ),
    "hill": AlgorithmInfo(
        id="hill", name="Steepest-Ascent Hill Climbing", short_name="Hill Climbing", category="Tìm kiếm cục bộ",
        description="Mỗi bước chọn trạng thái lân cận có h(n) tốt nhất và chỉ đi khi cải thiện.",
        strengths="Rất ít bộ nhớ; chạy nhanh.", limitations="Dễ mắc cực trị cục bộ, plateau hoặc ridge.",
        complete="Không", optimal="Không", time_complexity="O(kb)", space_complexity="O(b)",
        pseudocode="""HillClimbing(start):
    current ← start
    loop:
        next ← neighbor có h nhỏ nhất
        if h(next) ≥ h(current): trả về current
        current ← next
        if current = goal: trả về đường đi""",
    ),
    "beam": AlgorithmInfo(
        id="beam", name="Local Beam Search", short_name="Local Beam", category="Tìm kiếm cục bộ",
        description="Duy trì k trạng thái tốt nhất và sinh thế hệ kế tiếp từ toàn bộ k trạng thái.",
        strengths="Khám phá nhiều hướng hơn Hill Climbing.", limitations="Các beam có thể hội tụ vào cùng một vùng; không đảm bảo tối ưu.",
        complete="Không", optimal="Không", time_complexity="O(kbI)", space_complexity="O(kb)",
        pseudocode="""LocalBeam(start, k):
    beam ← k đường đi khởi tạo từ start
    repeat:
        candidates ← toàn bộ successor của beam
        nếu có goal: trả về đường đi
        beam ← k candidate có h nhỏ nhất""",
    ),
    "sa": AlgorithmInfo(
        id="sa", name="Simulated Annealing", short_name="SA", category="Tìm kiếm cục bộ",
        description="Cho phép nhận bước xấu theo xác suất exp(-Δ/T) để thoát cực trị cục bộ.",
        strengths="Có khả năng thoát cực trị cục bộ; bộ nhớ thấp.", limitations="Phụ thuộc lịch giảm nhiệt và yếu tố ngẫu nhiên.",
        complete="Không trong thời gian hữu hạn", optimal="Tiệm cận trong điều kiện lý tưởng", time_complexity="O(I)", space_complexity="O(1)",
        pseudocode="""SimulatedAnnealing(start):
    current ← start; T ← T0
    for i = 1..maxIter:
        next ← neighbor ngẫu nhiên
        Δ ← h(next)-h(current)
        nếu Δ < 0 hoặc random < exp(-Δ/T):
            current ← next
        T ← cooling(T)
        nếu current = goal: trả về đường đi""",
    ),
    "andor": AlgorithmInfo(
        id="andor", name="AND-OR Graph Search", short_name="AND-OR", category="Môi trường phức tạp",
        description="OR node chọn hành động; AND node phải xử lý mọi kết quả có thể của hành động.",
        strengths="Tạo kế hoạch có điều kiện trong môi trường không xác định.", limitations="Cây kế hoạch tăng nhanh; 8-puzzle chuẩn là xác định nên AND node chỉ có một kết quả.",
        complete="Có với không gian hữu hạn và xử lý vòng lặp", optimal="Không mặc định", time_complexity="Theo kích thước cây AND-OR", space_complexity="Theo độ sâu và chính sách",
        pseudocode="""OR-SEARCH(state, path):
    if goal(state): return EMPTY_PLAN
    if state thuộc path: return failure
    for action:
        plan ← AND-SEARCH(results(state, action), path∪{state})
        if plan ≠ failure: return [action, plan]

AND-SEARCH(states, path):
    for mỗi resultState:
        plan[resultState] ← OR-SEARCH(resultState, path)
        nếu failure: return failure
    return plan""",
        adaptation_note="Trong 8-puzzle xác định, mỗi hành động hợp lệ tạo một kết quả; ứng dụng vẫn hiển thị rõ OR/AND trace để minh họa cấu trúc thuật toán.",
    ),
    "belief": AlgorithmInfo(
        id="belief", name="Belief-State Search", short_name="Belief-State", category="Môi trường phức tạp",
        description="Tìm kiếm trên tập các trạng thái có thể khi tác tử không biết chính xác trạng thái thực.",
        strengths="Phù hợp môi trường quan sát không đầy đủ.", limitations="Không gian belief có thể tăng theo lũy thừa.",
        complete="Có trong belief space hữu hạn", optimal="Có khi dùng BFS và chi phí đều", time_complexity="Theo số belief-state", space_complexity="Theo số belief-state",
        pseudocode="""BeliefBFS(initialBelief):
    frontier ← Queue([initialBelief])
    while frontier không rỗng:
        belief ← pop_front()
        if mọi state trong belief đạt goal: return action sequence
        for action:
            nextBelief ← {Result(s, action) | s ∈ belief}
            nếu chưa thăm: enqueue(nextBelief)""",
    ),
    "lrta": AlgorithmInfo(
        id="lrta", name="Learning Real-Time A*", short_name="LRTA*", category="Môi trường phức tạp",
        description="Vừa hành động vừa cập nhật heuristic H(s) từ kinh nghiệm thực tế.",
        strengths="Ra quyết định trực tuyến; học dần từ các lần thử.", limitations="Đường đi ban đầu có thể dài và lặp; cần nhiều trial.",
        complete="Có trong điều kiện chuẩn với không gian hữu hạn", optimal="Không cho trial đầu", time_complexity="Theo số bước trực tuyến", space_complexity="O(|S|) cho bảng H",
        pseudocode="""LRTA*(start):
    H(s) ← h(s)
    lặp qua nhiều trial:
        current ← start
        while current ≠ goal:
            H(current) ← min_a [cost + H(Result(current,a))]
            action ← argmin_a [cost + H(Result(current,a))]
            current ← Result(current, action)
        nếu đạt goal: trả về đường đi trial hiện tại""",
    ),
    "ac3": AlgorithmInfo(
        id="ac3", name="Constraint Propagation (AC-3)", short_name="AC-3", category="Bài toán thỏa mãn ràng buộc",
        description="Mô hình X0..Xd là trạng thái theo thời gian; AC-3 loại trạng thái không có hỗ trợ ở miền kế cận.",
        strengths="Cắt giảm miền trước khi backtracking; giải thích rõ quá trình lan truyền ràng buộc.", limitations="Phải chọn horizon; miền trạng thái có thể lớn.",
        complete="Có khi kết hợp backtracking trên miền hữu hạn", optimal="Có nếu thử horizon tăng dần", time_complexity="O(ed^3) theo CSP tổng quát", space_complexity="Theo tổng kích thước miền",
        pseudocode="""AC3(domains, arcs):
    queue ← tất cả cung (Xi, Xj)
    while queue không rỗng:
        (Xi, Xj) ← pop(queue)
        if REVISE(Xi, Xj):
            if domain[Xi] rỗng: return failure
            thêm (Xk, Xi) với Xk là hàng xóm của Xi
    backtrack để chọn một chuỗi state tương thích""",
        adaptation_note="Mỗi biến Xi đại diện trạng thái 8-puzzle tại bước i; ràng buộc nhị phân yêu cầu Xi và Xi+1 khác nhau đúng một nước đi hợp lệ.",
    ),
    "backtracking": AlgorithmInfo(
        id="backtracking", name="Backtracking CSP", short_name="Backtracking", category="Bài toán thỏa mãn ràng buộc",
        description="Gán lần lượt X1, X2, ...; nếu nhánh không thể tới goal trong số bước còn lại thì quay lui.",
        strengths="Rõ ràng, dễ chạy tay; kết hợp forward checking để cắt nhánh.", limitations="Có thể bùng nổ tổ hợp nếu ràng buộc yếu.",
        complete="Có với giới hạn đủ lớn", optimal="Có nếu tăng horizon từ cận dưới", time_complexity="O(b^d)", space_complexity="O(d)",
        pseudocode="""Backtrack(step, state):
    if step = horizon: return state = goal
    if Manhattan(state, goal) > remaining: return failure
    for successor hợp lệ, chưa lặp:
        gán X(step+1) ← successor
        if Backtrack(step+1, successor): return success
        hủy gán
    return failure""",
    ),
    "minconflicts": AlgorithmInfo(
        id="minconflicts", name="Min-Conflicts CSP", short_name="Min-Conflicts", category="Bài toán thỏa mãn ràng buộc",
        description="Biểu diễn lời giải bằng chuỗi hành động đầy đủ rồi sửa biến gây xung đột để giảm vi phạm.",
        strengths="Hiệu quả với nhiều CSP lớn; thể hiện rõ local repair.", limitations="Không đảm bảo tìm lời giải; cần restart và horizon phù hợp.",
        complete="Không", optimal="Không", time_complexity="O(R·I·d·|A|)", space_complexity="O(d)",
        pseudocode="""MinConflicts(horizon):
    actions ← gán ngẫu nhiên U/D/L/R
    repeat maxSteps:
        replay(actions)
        if hợp lệ và trạng thái cuối = goal: return actions
        chọn một biến hành động gây xung đột
        gán giá trị làm tổng conflict nhỏ nhất
    restart nếu chưa thành công""",
    ),
    "minimax": AlgorithmInfo(
        id="minimax", name="Minimax", short_name="Minimax", category="Tìm kiếm đối kháng",
        description="MAX chọn nước đi tốt; MIN mô phỏng nhiễu/môi trường chọn phản ứng bất lợi nhất.",
        strengths="Đưa ra quyết định thận trọng trong trường hợp xấu nhất.", limitations="8-puzzle không phải trò chơi hai người; đây là mô hình hóa môi trường đối kháng để học thuật toán.",
        complete="Có ở độ sâu hữu hạn", optimal="Tối ưu theo mô hình đối kháng đã định nghĩa", time_complexity="O(b^d)", space_complexity="O(bd) với DFS",
        pseudocode="""MINIMAX(state, depth, maximizing):
    if terminal hoặc depth=0: return utility(state)
    if maximizing:
        return max MINIMAX(successor, depth-1, False)
    else:
        return min MINIMAX(adverseOutcome, depth-1, True)""",
        adaptation_note="Ứng dụng dùng tìm kiếm receding-horizon: MAX chọn nước đi, MIN đại diện tác động bất lợi lên lựa chọn tiếp theo; utility ưu tiên giảm Manhattan và tránh lặp.",
    ),
    "alphabeta": AlgorithmInfo(
        id="alphabeta", name="Alpha-Beta Pruning", short_name="Alpha-Beta", category="Tìm kiếm đối kháng",
        description="Cho kết quả như Minimax nhưng cắt các nhánh không thể ảnh hưởng quyết định cuối.",
        strengths="Giảm số node rõ rệt khi thứ tự nước đi tốt.", limitations="Không thay đổi bản chất mô hình đối kháng; hiệu quả phụ thuộc thứ tự duyệt.",
        complete="Có ở độ sâu hữu hạn", optimal="Như Minimax", time_complexity="Tốt nhất O(b^(d/2)); xấu nhất O(b^d)", space_complexity="O(bd)",
        pseudocode="""ALPHABETA(state, depth, α, β, maximizing):
    if terminal: return utility
    if maximizing:
        value ← -∞
        for child:
            value ← max(value, AB(child, ..., False))
            α ← max(α, value)
            if α ≥ β: break
    else:
        tương tự với min và β
    return value""",
        adaptation_note="Cùng mô hình đối kháng giáo dục với Minimax; thống kê riêng số nhánh bị cắt.",
    ),
    "expectimax": AlgorithmInfo(
        id="expectimax", name="Expectimax", short_name="Expectimax", category="Tìm kiếm đối kháng",
        description="Thay MIN node bằng CHANCE node và tính giá trị kỳ vọng theo xác suất kết quả.",
        strengths="Phù hợp nhiễu ngẫu nhiên thay vì đối thủ luôn gây hại nhất.", limitations="Cần giả định phân phối xác suất; vẫn là thích nghi giáo dục cho 8-puzzle.",
        complete="Có ở độ sâu hữu hạn", optimal="Tối ưu theo mô hình xác suất", time_complexity="O(b^d)", space_complexity="O(bd)",
        pseudocode="""EXPECTIMAX(state, depth, nodeType):
    if terminal: return utility
    if MAX:
        return max EXPECTIMAX(successor, depth-1, CHANCE)
    if CHANCE:
        return Σ P(outcome) · EXPECTIMAX(outcome, depth-1, MAX)""",
        adaptation_note="Ứng dụng mô hình môi trường có xác suất giữ nguyên/đi lệch; thuật toán chọn hành động có utility kỳ vọng tốt nhất.",
    ),
}

CATEGORY_ORDER = [
    "Tìm kiếm mù thông tin",
    "Tìm kiếm có thông tin",
    "Tìm kiếm cục bộ",
    "Môi trường phức tạp",
    "Bài toán thỏa mãn ràng buộc",
    "Tìm kiếm đối kháng",
]

from __future__ import annotations

from collections import deque
from heapq import heappop, heappush
from itertools import count
from time import perf_counter

from puzzle8.core import State, manhattan, neighbors, reconstruct_path
from .common import SearchLimits, finalize, step, timed_out


def bfs(start: State, goal: State, limits: SearchLimits):
    t0 = perf_counter(); steps=[]; q=deque([start]); parent={start:(None,None)}; depth={start:0}
    expanded=generated=0; max_frontier=1
    while q:
        if expanded >= limits.max_nodes or timed_out(t0, limits): break
        cur=q.popleft(); expanded+=1
        step(steps, cur, depth=depth[cur], g=depth[cur], h=manhattan(cur, goal), f=depth[cur], frontier=len(q), explored=expanded, note="Lấy node đầu hàng đợi FIFO")
        if cur==goal:
            path, states=reconstruct_path(parent, goal)
            return finalize("bfs", start, goal, t0, success=True, path=path, states=states, steps=steps, expanded=expanded, generated=generated, max_frontier=max_frontier, message="BFS tìm thấy lời giải tối ưu theo số bước.")
        for nxt, mv in neighbors(cur):
            generated+=1
            if nxt not in parent:
                parent[nxt]=(cur,mv); depth[nxt]=depth[cur]+1; q.append(nxt)
        max_frontier=max(max_frontier,len(q))
    return finalize("bfs", start, goal, t0, success=False, path=[], states=[start], steps=steps, expanded=expanded, generated=generated, max_frontier=max_frontier, message="BFS dừng do giới hạn tài nguyên.")


def dfs(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]; stack=[(start,0)]; parent={start:(None,None)}; best_depth={start:0}
    expanded=generated=0; max_frontier=1
    while stack:
        if expanded >= limits.max_nodes or timed_out(t0, limits): break
        cur,d=stack.pop(); expanded+=1
        step(steps, cur, depth=d, g=d, h=manhattan(cur, goal), f=d, frontier=len(stack), explored=expanded, note="Lấy node trên đỉnh stack LIFO")
        if cur==goal:
            path, states=reconstruct_path(parent, goal)
            return finalize("dfs", start, goal, t0, success=True, path=path, states=states, steps=steps, expanded=expanded, generated=generated, max_frontier=max_frontier, message=f"DFS tìm thấy lời giải với giới hạn sâu {limits.max_depth}.")
        if d>=limits.max_depth: continue
        children=list(neighbors(cur))
        for nxt,mv in reversed(children):
            generated+=1; nd=d+1
            if nd < best_depth.get(nxt, 10**9):
                best_depth[nxt]=nd; parent[nxt]=(cur,mv); stack.append((nxt,nd))
        max_frontier=max(max_frontier,len(stack))
    return finalize("dfs", start, goal, t0, success=False, path=[], states=[start], steps=steps, expanded=expanded, generated=generated, max_frontier=max_frontier, message="DFS không tìm thấy lời giải trong giới hạn đã chọn.")


def ids(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]; expanded=generated=0; max_frontier=0
    for limit in range(limits.max_depth+1):
        if expanded >= limits.max_nodes or timed_out(t0, limits): break
        step(steps, start, phase="ITERATION", depth=0, g=0, h=manhattan(start,goal), note=f"Bắt đầu Depth-Limited Search với limit={limit}", explored=expanded)
        path_states=[start]; path_actions=[]; on_path={start}
        found=False
        def dls(cur: State, depth: int) -> bool:
            nonlocal expanded, generated, max_frontier, found
            if expanded >= limits.max_nodes or timed_out(t0, limits): return False
            expanded+=1; max_frontier=max(max_frontier,len(path_states))
            step(steps, cur, depth=depth, g=depth, h=manhattan(cur,goal), f=depth, frontier=len(path_states), explored=expanded, phase="DLS", note=f"Giới hạn hiện tại: {limit}")
            if cur==goal: found=True; return True
            if depth==limit: return False
            for nxt,mv in neighbors(cur):
                generated+=1
                if nxt in on_path: continue
                on_path.add(nxt); path_states.append(nxt); path_actions.append(mv)
                if dls(nxt, depth+1): return True
                on_path.remove(nxt); path_states.pop(); path_actions.pop()
            return False
        if dls(start,0):
            return finalize("ids", start, goal, t0, success=True, path=path_actions, states=path_states, steps=steps, expanded=expanded, generated=generated, max_frontier=max_frontier, message=f"IDS tìm thấy lời giải ở giới hạn sâu {limit}.", metadata={"found_limit":limit})
    return finalize("ids", start, goal, t0, success=False, path=[], states=[start], steps=steps, expanded=expanded, generated=generated, max_frontier=max_frontier, message="IDS không tìm thấy lời giải trong giới hạn.")


def ucs(start: State, goal: State, limits: SearchLimits):
    return _best_first("ucs", start, goal, limits, lambda g,h:g)

def greedy(start: State, goal: State, limits: SearchLimits):
    return _best_first("greedy", start, goal, limits, lambda g,h:h)

def astar(start: State, goal: State, limits: SearchLimits):
    return _best_first("astar", start, goal, limits, lambda g,h:g+h)


def _best_first(algorithm_id: str, start: State, goal: State, limits: SearchLimits, priority_fn):
    t0=perf_counter(); steps=[]; serial=count(); h0=manhattan(start,goal)
    pq=[(priority_fn(0,h0), next(serial), 0, start)]; best_g={start:0}; parent={start:(None,None)}; closed=set()
    expanded=generated=0; max_frontier=1
    while pq:
        if expanded >= limits.max_nodes or timed_out(t0, limits): break
        priority,_,g,cur=heappop(pq)
        if cur in closed or g!=best_g.get(cur): continue
        closed.add(cur); expanded+=1; h=manhattan(cur,goal)
        labels={"ucs":"g(n)","greedy":"h(n)","astar":"f(n)=g(n)+h(n)"}
        step(steps, cur, depth=g, g=g, h=h, f=g+h, frontier=len(pq), explored=expanded, note=f"Ưu tiên theo {labels[algorithm_id]} = {priority:.0f}")
        if cur==goal:
            path,states=reconstruct_path(parent,goal)
            return finalize(algorithm_id,start,goal,t0,success=True,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message=f"{algorithm_id.upper()} tìm thấy lời giải.")
        for nxt,mv in neighbors(cur):
            generated+=1; ng=g+1
            if ng < best_g.get(nxt,10**9):
                best_g[nxt]=ng; parent[nxt]=(cur,mv); hn=manhattan(nxt,goal)
                heappush(pq,(priority_fn(ng,hn),next(serial),ng,nxt))
        max_frontier=max(max_frontier,len(pq))
    return finalize(algorithm_id,start,goal,t0,success=False,path=[],states=[start],steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message="Không tìm thấy lời giải trong giới hạn.")

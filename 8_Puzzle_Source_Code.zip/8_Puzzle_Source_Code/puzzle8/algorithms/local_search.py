from __future__ import annotations

import math
import random
from time import perf_counter

from puzzle8.core import State, manhattan, neighbors
from .common import SearchLimits, finalize, step, timed_out


def _erase_cycles(states, actions):
    """Loại các chu trình khỏi đường đi nhưng giữ nguyên tính hợp lệ của từng bước."""
    out_states=[]
    out_actions=[]
    position={}
    for index,state in enumerate(states):
        if state in position:
            keep=position[state]
            out_states=out_states[:keep+1]
            out_actions=out_actions[:keep]
            position={s:i for i,s in enumerate(out_states)}
        else:
            if out_states:
                out_actions.append(actions[index-1])
            position[state]=len(out_states)
            out_states.append(state)
    return out_states,out_actions


def hill_climbing(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]; current=start; states=[start]; path=[]; visited={start}; expanded=generated=0
    while expanded < limits.max_nodes and len(path) < limits.max_depth and not timed_out(t0,limits):
        hcur=manhattan(current,goal); expanded+=1
        step(steps,current,depth=len(path),g=len(path),h=hcur,f=hcur,explored=expanded,phase="SELECT",note="Chọn lân cận có h nhỏ nhất")
        if current==goal:
            return finalize("hill",start,goal,t0,success=True,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=4,message="Hill Climbing đạt trạng thái đích.")
        candidates=[]
        for nxt,mv in neighbors(current):
            generated+=1
            if nxt not in visited:
                candidates.append((manhattan(nxt,goal),nxt,mv))
        if not candidates: break
        candidates.sort(key=lambda x:x[0]); best_h,best,mv=candidates[0]
        if best_h >= hcur:
            step(steps,current,depth=len(path),g=len(path),h=hcur,f=hcur,explored=expanded,phase="STOP",note="Không còn lân cận cải thiện: cực trị cục bộ/plateau")
            break
        current=best; visited.add(best); path.append(mv); states.append(best)
    return finalize("hill",start,goal,t0,success=current==goal,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=4,message="Hill Climbing dừng tại cực trị cục bộ." if current!=goal else "Thành công")


def local_beam(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]; k=max(2,limits.beam_width); beam=[(start,[start],[])]; expanded=generated=0; max_frontier=k
    # tạo các hướng ban đầu từ start để vẫn giữ đúng bài toán cùng trạng thái khởi đầu
    for nxt,mv in list(neighbors(start))[:k-1]: beam.append((nxt,[start,nxt],[mv]))
    for iteration in range(limits.iterations):
        if timed_out(t0,limits) or expanded>=limits.max_nodes: break
        candidates=[]; seen=set()
        for state,states,moves in beam:
            expanded+=1
            h=manhattan(state,goal)
            step(steps,state,depth=len(moves),g=len(moves),h=h,f=h,frontier=len(beam),explored=expanded,phase="BEAM",note=f"Thế hệ {iteration}, beam width={k}")
            if state==goal:
                return finalize("beam",start,goal,t0,success=True,path=moves,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message=f"Local Beam tìm thấy lời giải với k={k}.")
            for nxt,mv in neighbors(state):
                generated+=1
                if nxt in states or nxt in seen: continue
                seen.add(nxt); candidates.append((manhattan(nxt,goal),nxt,states+[nxt],moves+[mv]))
        if not candidates: break
        candidates.sort(key=lambda x:(x[0],len(x[3])))
        beam=[(x[1],x[2],x[3]) for x in candidates[:k]]; max_frontier=max(max_frontier,len(candidates))
    best=min(beam,key=lambda x:manhattan(x[0],goal)) if beam else (start,[start],[])
    return finalize("beam",start,goal,t0,success=best[0]==goal,path=best[2],states=best[1],steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message="Local Beam hết giới hạn trước khi đạt đích.")


def simulated_annealing(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); rng=random.Random(limits.seed); steps=[]; best_global=(manhattan(start,goal),[start],[]); expanded=generated=0
    for restart in range(6):
        current=start; states=[start]; path=[]; temp=limits.temperature
        for iteration in range(limits.iterations):
            if timed_out(t0,limits) or expanded>=limits.max_nodes: break
            hcur=manhattan(current,goal); expanded+=1
            if hcur < best_global[0]: best_global=(hcur,states.copy(),path.copy())
            step(steps,current,depth=len(path),g=len(path),h=hcur,f=hcur,explored=expanded,phase="ANNEAL",note=f"restart={restart}, T={temp:.3f}",extra={"temperature":temp})
            if current==goal:
                clean_states, clean_path = _erase_cycles(states, path)
                return finalize("sa",start,goal,t0,success=True,path=clean_path,states=clean_states,steps=steps,expanded=expanded,generated=generated,max_frontier=4,message="Simulated Annealing đạt đích; chu trình trong quỹ đạo đã được rút gọn cho hoạt ảnh.",metadata={"restarts":restart,"raw_accepted_steps":len(path)})
            options=list(neighbors(current)); generated+=len(options); nxt,mv=rng.choice(options); hn=manhattan(nxt,goal); delta=hn-hcur
            probability=1.0 if delta<=0 else math.exp(-delta/max(temp,1e-9))
            accepted=delta<=0 or rng.random()<probability
            step(steps,nxt,action=mv,depth=len(path)+1,g=len(path)+1,h=hn,f=hn,explored=expanded,phase="DECISION",note=f"Δ={delta}, P={probability:.4f}, {'chấp nhận' if accepted else 'từ chối'}",extra={"delta":delta,"probability":probability,"accepted":accepted})
            if accepted:
                current=nxt; path.append(mv); states.append(nxt)
            temp*=limits.cooling
            if temp<0.001: break
        rng.seed(limits.seed+restart+1)
    return finalize("sa",start,goal,t0,success=False,path=best_global[2],states=best_global[1],steps=steps,expanded=expanded,generated=generated,max_frontier=4,message=f"Không đạt đích; trả về trạng thái tốt nhất h={best_global[0]}.",metadata={"best_h":best_global[0]})

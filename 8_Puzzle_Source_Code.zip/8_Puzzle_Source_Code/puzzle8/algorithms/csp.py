from __future__ import annotations

from collections import deque
import random
from time import perf_counter

from puzzle8.core import ACTIONS, State, apply_action, manhattan, neighbors
from .common import SearchLimits, finalize, step, timed_out


def _reachable_levels(origin: State, depth: int, cap: int = 80_000) -> list[set[State]]:
    levels=[{origin}]
    for _ in range(depth):
        nxt=set()
        for state in levels[-1]:
            for child,_ in neighbors(state): nxt.add(child)
            if len(nxt)>cap: break
        levels.append(nxt)
        if len(nxt)>cap: break
    return levels


def constraint_propagation_ac3(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]; expanded=generated=0; max_frontier=0
    lower=manhattan(start,goal)
    for horizon in range(lower, min(limits.max_depth, lower+12)+1):
        if timed_out(t0,limits): break
        from_start=_reachable_levels(start,horizon)
        from_goal=_reachable_levels(goal,horizon)
        if len(from_start)<=horizon or len(from_goal)<=horizon: break
        domains=[]
        for i in range(horizon+1):
            domain=from_start[i].intersection(from_goal[horizon-i])
            domains.append(domain)
        domains[0]={start}; domains[-1]={goal}
        before=[len(d) for d in domains]
        if any(not d for d in domains):
            continue
        queue=deque()
        for i in range(horizon):
            queue.append((i,i+1)); queue.append((i+1,i))
        revised_count=0
        while queue:
            xi,xj=queue.popleft(); expanded+=1
            old=domains[xi]
            if xi<xj:
                keep={s for s in old if any(child in domains[xj] for child,_ in neighbors(s))}
            else:
                keep={s for s in old if any(parent in domains[xj] for parent,_ in neighbors(s))}
            if keep != old:
                revised_count += len(old)-len(keep); domains[xi]=keep
                representative=next(iter(keep), start)
                step(steps,representative,depth=xi,g=xi,h=manhattan(representative,goal),f=xi+manhattan(representative,goal),frontier=len(queue),explored=expanded,phase="REVISE",note=f"REVISE(X{xi}, X{xj}): {len(old)}→{len(keep)}",extra={"variable":xi,"support_variable":xj,"domain_before":len(old),"domain_after":len(keep),"horizon":horizon})
                if not keep: break
                for xk in (xi-1,xi+1):
                    if 0<=xk<=horizon and xk!=xj: queue.append((xk,xi))
            max_frontier=max(max_frontier,len(queue))
        if any(not d for d in domains): continue
        # trích xuất đường đi tương thích từ các miền đã arc-consistent
        path=[]; states=[start]; visited={start}
        def assign(i:int,current:State)->bool:
            nonlocal generated
            if i==horizon: return current==goal
            candidates=[]
            for nxt,mv in neighbors(current):
                generated+=1
                if nxt in domains[i+1] and (nxt not in visited or nxt==goal):
                    candidates.append((manhattan(nxt,goal),nxt,mv))
            for _,nxt,mv in sorted(candidates):
                path.append(mv); states.append(nxt); visited.add(nxt)
                if assign(i+1,nxt): return True
                if nxt!=goal: visited.discard(nxt)
                path.pop(); states.pop()
            return False
        if assign(0,start):
            return finalize("ac3",start,goal,t0,success=True,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message=f"AC-3 làm nhất quán miền và tìm được lời giải ở horizon={horizon}.",metadata={"horizon":horizon,"domain_sizes_before":before,"domain_sizes_after":[len(d) for d in domains],"values_pruned":revised_count})
    return finalize("ac3",start,goal,t0,success=False,path=[],states=[start],steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message="AC-3 không tìm được horizon khả thi trong giới hạn.")


def backtracking_csp(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); steps=[]; expanded=generated=0; max_frontier=0; lower=manhattan(start,goal)
    for horizon in range(lower,limits.max_depth+1):
        path=[]; states=[start]; on_path={start}
        step(steps,start,phase="HORIZON",depth=0,g=0,h=lower,f=lower,note=f"Thử CSP horizon={horizon}",explored=expanded)
        def bt(current:State,depth:int)->bool:
            nonlocal expanded,generated,max_frontier
            if timed_out(t0,limits) or expanded>=limits.max_nodes:return False
            expanded+=1; remaining=horizon-depth; max_frontier=max(max_frontier,len(states))
            h=manhattan(current,goal)
            step(steps,current,depth=depth,g=depth,h=h,f=depth+h,frontier=len(states),explored=expanded,phase="ASSIGN",note=f"Gán X{depth}; còn {remaining} bước")
            if depth==horizon:return current==goal
            if h>remaining or (remaining-h)%2!=0:
                step(steps,current,depth=depth,g=depth,h=h,f=depth+h,explored=expanded,phase="PRUNE",note="Forward checking: không đủ bước/parity không phù hợp")
                return False
            candidates=sorted(neighbors(current),key=lambda item:manhattan(item[0],goal))
            for nxt,mv in candidates:
                generated+=1
                if nxt in on_path:continue
                on_path.add(nxt); path.append(mv); states.append(nxt)
                if bt(nxt,depth+1):return True
                on_path.remove(nxt); path.pop(); states.pop()
                step(steps,current,depth=depth,g=depth,h=h,f=depth+h,explored=expanded,phase="BACKTRACK",note=f"Quay lui khỏi hành động {mv}")
            return False
        if bt(start,0):
            return finalize("backtracking",start,goal,t0,success=True,path=path,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message=f"Backtracking CSP tìm được lời giải ở horizon={horizon}.",metadata={"horizon":horizon})
        if timed_out(t0,limits) or expanded>=limits.max_nodes:break
    return finalize("backtracking",start,goal,t0,success=False,path=[],states=[start],steps=steps,expanded=expanded,generated=generated,max_frontier=max_frontier,message="Backtracking CSP hết giới hạn.")


def min_conflicts_csp(start: State, goal: State, limits: SearchLimits):
    t0=perf_counter(); rng=random.Random(limits.seed); steps=[]; expanded=generated=0; lower=manhattan(start,goal)
    horizon=min(limits.max_depth,max(lower,lower+4))
    best=(10**9,[],[start])
    def replay(actions):
        current=start; states=[start]; invalid=[]; repeats=0; seen={start}
        for i,action in enumerate(actions):
            nxt=apply_action(current,action)
            if nxt is None:
                invalid.append(i); nxt=current
            current=nxt; repeats+=int(current in seen); seen.add(current); states.append(current)
        score=20*len(invalid)+10*manhattan(current,goal)+repeats
        return score,current,states,invalid,repeats
    for restart in range(60):
        actions=[rng.choice(ACTIONS) for _ in range(horizon)]
        for iteration in range(min(limits.iterations,2000)):
            if timed_out(t0,limits) or expanded>=limits.max_nodes:break
            score,current,states,invalid,repeats=replay(actions); expanded+=1
            if score<best[0]:best=(score,actions.copy(),states.copy())
            step(steps,current,depth=horizon,g=horizon,h=manhattan(current,goal),f=score,explored=expanded,phase="REPAIR",note=f"restart={restart}, iter={iteration}, conflicts={score}",extra={"sequence":"".join(actions),"invalid_positions":invalid,"repeats":repeats})
            if current==goal and not invalid:
                return finalize("minconflicts",start,goal,t0,success=True,path=actions,states=states,steps=steps,expanded=expanded,generated=generated,max_frontier=horizon,message=f"Min-Conflicts giải được CSP sau {restart+1} restart.",metadata={"horizon":horizon,"restarts":restart})
            index=rng.choice(invalid) if invalid and rng.random()<0.8 else rng.randrange(horizon)
            candidates=[]
            for action in ACTIONS:
                generated+=1; candidate=actions.copy(); candidate[index]=action
                candidate_score,*_=replay(candidate); candidates.append((candidate_score,action))
            min_score=min(x[0] for x in candidates); best_actions=[a for s,a in candidates if s==min_score]
            actions[index]=rng.choice(best_actions)
        if timed_out(t0,limits) or expanded>=limits.max_nodes:break
        rng.seed(limits.seed+restart+1)
    return finalize("minconflicts",start,goal,t0,success=False,path=best[1],states=best[2],steps=steps,expanded=expanded,generated=generated,max_frontier=horizon,message=f"Min-Conflicts chưa đạt goal; trả về gán tốt nhất với conflict={best[0]}.",metadata={"horizon":horizon,"best_conflict":best[0]})

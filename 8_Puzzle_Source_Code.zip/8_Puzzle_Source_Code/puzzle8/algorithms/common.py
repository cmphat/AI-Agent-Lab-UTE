from __future__ import annotations

from dataclasses import dataclass, fields
from time import perf_counter
from typing import Callable, Iterable, Sequence

from puzzle8.core import SearchResult, SearchStep, State, Action, manhattan
from .metadata import ALGORITHM_INFOS


@dataclass(slots=True)
class SearchLimits:
    max_nodes: int = 200_000
    max_depth: int = 40
    timeout_s: float = 15.0
    seed: int = 42
    beam_width: int = 5
    temperature: float = 80.0
    cooling: float = 0.992
    iterations: int = 10_000
    adversarial_depth: int = 4


def make_limits(params: dict | None = None) -> SearchLimits:
    default = SearchLimits()
    values = {item.name: getattr(default, item.name) for item in fields(SearchLimits)}
    if params:
        for key, value in params.items():
            if key in values:
                values[key] = value
    return SearchLimits(**values)


def step(
    steps: list[SearchStep],
    state: State,
    *,
    action: Action | None = None,
    depth: int = 0,
    g: float | None = None,
    h: float | None = None,
    f: float | None = None,
    frontier: int = 0,
    explored: int = 0,
    phase: str = "EXPAND",
    note: str = "",
    extra: dict | None = None,
) -> None:
    steps.append(
        SearchStep(
            index=len(steps), state=state, action=action, depth=depth, g=g, h=h, f=f,
            frontier=frontier, explored=explored, phase=phase, note=note, extra=extra or {},
        )
    )


def finalize(
    algorithm_id: str,
    start: State,
    goal: State,
    started_at: float,
    *,
    success: bool,
    path: Sequence[Action] | None,
    states: Sequence[State] | None,
    steps: list[SearchStep],
    expanded: int,
    generated: int,
    max_frontier: int,
    message: str = "",
    metadata: dict | None = None,
    score: float | None = None,
) -> SearchResult:
    info = ALGORITHM_INFOS[algorithm_id]
    final_states = list(states or [start])
    final_path = list(path or [])
    if score is None and final_states:
        score = float(-manhattan(final_states[-1], goal))
    return SearchResult(
        algorithm_id=algorithm_id,
        algorithm_name=info.name,
        category=info.category,
        success=success,
        start=start,
        goal=goal,
        path=final_path,
        states=final_states,
        steps=steps,
        expanded=expanded,
        generated=generated,
        max_frontier=max_frontier,
        elapsed_ms=(perf_counter() - started_at) * 1000,
        message=message,
        score=score,
        metadata=metadata or {},
    )


def timed_out(started_at: float, limits: SearchLimits) -> bool:
    return perf_counter() - started_at > limits.timeout_s

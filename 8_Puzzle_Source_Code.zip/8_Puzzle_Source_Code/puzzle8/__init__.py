"""8 Puzzle algorithm visualizer."""

__version__ = "2.1.0"

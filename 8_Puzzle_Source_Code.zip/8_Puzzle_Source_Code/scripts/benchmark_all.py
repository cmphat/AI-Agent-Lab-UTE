from __future__ import annotations

import csv
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from puzzle8.algorithms import ALGORITHM_INFOS, run_algorithm
from puzzle8.core import DEFAULT_GOAL, DEFAULT_START

PARAMS = {
    "max_depth": 20,
    "max_nodes": 100_000,
    "timeout_s": 5,
    "seed": 42,
    "beam_width": 5,
    "adversarial_depth": 4,
    "iterations": 3000,
}


def main() -> None:
    output = Path("benchmark_18_algorithms.csv")
    rows = []
    print("8 Puzzle AI Lab — benchmark 18 thuật toán")
    print("=" * 86)
    for algorithm_id in ALGORITHM_INFOS:
        result = run_algorithm(algorithm_id, DEFAULT_START, DEFAULT_GOAL, PARAMS)
        rows.append([
            result.algorithm_name,
            result.category,
            result.success,
            result.solution_depth,
            result.expanded,
            result.generated,
            result.max_frontier,
            f"{result.elapsed_ms:.3f}",
            " ".join(result.path),
        ])
        print(
            f"{result.algorithm_name:32} | success={str(result.success):5} | "
            f"steps={result.solution_depth:4} | expanded={result.expanded:7} | "
            f"time={result.elapsed_ms:9.3f} ms"
        )
    with output.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        writer.writerow([
            "algorithm", "category", "success", "steps", "expanded", "generated",
            "max_frontier", "elapsed_ms", "path",
        ])
        writer.writerows(rows)
    print("=" * 86)
    print(f"Đã xuất: {output.resolve()}")


if __name__ == "__main__":
    main()

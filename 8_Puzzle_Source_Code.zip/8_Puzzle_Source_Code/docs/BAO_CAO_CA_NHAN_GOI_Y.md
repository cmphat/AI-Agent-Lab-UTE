# Gợi ý bố cục báo cáo cá nhân

## I. Bài toán đặt ra

1. Phát biểu bài toán 8-puzzle.
2. Mô hình PEAS.
3. Biểu diễn trạng thái.
4. Trạng thái bắt đầu và trạng thái mục tiêu.
5. Tập hành động và hàm chuyển trạng thái.
6. Kiểm tra tính khả giải bằng parity số nghịch thế.

## II. Thuật toán áp dụng

Chọn một thuật toán đại diện cho mỗi nhóm và trình bày:

- Nguyên lý.
- Cấu trúc dữ liệu.
- Mã giả.
- Độ phức tạp.
- START, GOAL.
- Bảng chạy từng bước từ trace do ứng dụng xuất.

Gợi ý sáu đại diện: IDS, A*, Simulated Annealing, AND-OR, Backtracking CSP và Alpha-Beta.

## III. Thực nghiệm và kết quả

- Chạy ba thuật toán trong từng nhóm.
- Dùng cùng START, GOAL, giới hạn node, timeout và random seed.
- Thu thập: success, số bước, expanded, generated, max frontier và elapsed time.
- Dùng trang **So sánh** trong ứng dụng để tạo bảng và biểu đồ.

## IV. Đánh giá và thảo luận

- So sánh trong từng nhóm.
- So sánh giữa sáu nhóm.
- Giải thích vì sao không phải mọi thuật toán đều tự nhiên đối với 8-puzzle.
- Nhận xét vai trò của heuristic và giới hạn tài nguyên.

## V. Kết luận

- Kết quả đạt được.
- Hạn chế.
- Hướng phát triển.
- Link GitHub: https://github.com/cmphat/AI-Agent-Lab-UTE

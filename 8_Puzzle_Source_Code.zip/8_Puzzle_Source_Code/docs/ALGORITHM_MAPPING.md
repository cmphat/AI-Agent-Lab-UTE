# Ánh xạ 18 thuật toán vào bài toán 8-puzzle

## 1. Tìm kiếm mù thông tin

- **BFS:** duyệt theo tầng, tối ưu số bước khi mọi hành động có chi phí 1.
- **DFS:** đi sâu trước, có giới hạn độ sâu và tránh lặp.
- **IDS:** lặp DFS với giới hạn 0, 1, 2, ... cho đến khi tìm thấy goal.

## 2. Tìm kiếm có thông tin

- **UCS:** ưu tiên tổng chi phí đường đi `g(n)`.
- **Greedy Best-First:** ưu tiên khoảng cách Manhattan `h(n)`.
- **A\*:** ưu tiên `f(n) = g(n) + h(n)`.

## 3. Tìm kiếm cục bộ

- **Hill Climbing:** chọn lân cận có Manhattan nhỏ nhất nếu có cải thiện.
- **Local Beam:** duy trì `k` đường đi ứng viên tốt nhất.
- **Simulated Annealing:** có thể chấp nhận bước xấu theo xác suất phụ thuộc nhiệt độ.

## 4. Môi trường phức tạp

- **AND-OR Graph Search:** OR node chọn action; AND node kiểm tra mọi outcome. Với 8-puzzle chuẩn, một action hợp lệ có đúng một outcome, nên ứng dụng ghi rõ đây là trường hợp xác định của mô hình tổng quát.
- **Belief-State Search:** tìm kiếm trên tập trạng thái khả dĩ khi agent không biết chính xác start thực tế.
- **LRTA\*:** vừa di chuyển vừa cập nhật bảng heuristic đã học.

## 5. Bài toán thỏa mãn ràng buộc

- **Constraint Propagation / AC-3:** biến `X_i` là state ở bước `i`, miền chứa các state có thể; ràng buộc yêu cầu hai state liên tiếp là hàng xóm hợp lệ.
- **Backtracking CSP:** gán lần lượt `X_1, X_2, ...`, dùng forward checking và quay lui.
- **Min-Conflicts:** biến là action ở từng bước; sửa action gây xung đột để giảm số hành động không hợp lệ và khoảng cách tới goal.

## 6. Tìm kiếm đối kháng

8-puzzle chuẩn là bài toán đơn tác tử. Để minh họa đúng cấu trúc thuật toán, ứng dụng dùng mô hình giáo dục:

- **MAX:** agent chọn nước đi.
- **MIN:** môi trường đánh giá phản ứng bất lợi.
- **CHANCE:** môi trường gây nhiễu với xác suất.

Các thuật toán Minimax, Alpha-Beta và Expectimax được chạy theo kiểu receding-horizon: mỗi lượt xây cây ở độ sâu giới hạn, chọn hành động tốt nhất rồi lặp lại cho đến goal. Giao diện và báo cáo luôn hiển thị ghi chú thích nghi này để tránh trình bày sai bản chất học thuật.

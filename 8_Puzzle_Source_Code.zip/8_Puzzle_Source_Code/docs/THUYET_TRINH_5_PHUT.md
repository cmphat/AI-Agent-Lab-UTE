# Kịch bản demo 5 phút

## Phút 0–1: Giới thiệu bài toán

- 8-puzzle gồm 8 ô số và 1 ô trống.
- State là tuple 9 phần tử; action là U, D, L, R.
- Goal test là so sánh state hiện tại với GOAL.
- Tính khả giải được kiểm tra bằng parity số nghịch thế.

## Phút 1–2: Chạy A*

- Chọn A* ở sidebar Phòng thí nghiệm.
- Giữ preset môn học.
- Bấm chạy và mở tab Nhật ký.
- Giải thích `g(n)` là số bước đã đi, `h(n)` là Manhattan, `f(n)=g(n)+h(n)`.
- Cho hoạt ảnh chạy từng state.

## Phút 2–3: Mã giả và trace

- Mở trang Mã giả.
- Chỉ ra Priority Queue và điều kiện cập nhật đường đi tốt hơn.
- Quay lại trace để minh chứng code chạy đúng nguyên lý.

## Phút 3–4: So sánh

- Chọn BFS, A* và Local Beam.
- Chạy cùng START/GOAL.
- So sánh node mở rộng, thời gian và độ dài lời giải.
- Nhận xét A* dùng heuristic nên mở ít node hơn BFS trên preset này.

## Phút 4–5: PEAS và minh chứng nộp bài

- Mở trang PEAS & Báo cáo.
- Trình bày PEAS.
- Xuất báo cáo HTML.
- Mở link GitHub source code.
- Nêu rõ toàn bộ 18 thuật toán nằm trong `puzzle8/algorithms/` và đều viết bằng Python.

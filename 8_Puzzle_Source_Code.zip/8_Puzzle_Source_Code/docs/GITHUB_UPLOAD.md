# Cách đưa project lên GitHub chuyên nghiệp

1. Xóa `.venv` nếu đã được tạo trong thư mục project.
2. Không nén toàn bộ source thành một file duy nhất trong repository.
3. Upload trực tiếp các thư mục và file:

```text
puzzle8/
scripts/
tests/
docs/
main.py
README.md
requirements.txt
pyproject.toml
CHAY_8_PUZZLE.bat
.gitignore
```

4. Commit message gợi ý:

```text
Release 8 Puzzle AI Lab — Python 18 Algorithms
```

5. Commit description gợi ý:

```text
Final individual AI assignment featuring a professional PySide6 interface,
18 Python AI algorithms, step-by-step animation, pseudocode, search traces,
comparison charts, PEAS documentation, run history and HTML/CSV/JSON export.
```

6. Link dùng trong báo cáo:

```text
https://github.com/cmphat/AI-Agent-Lab-UTE
```

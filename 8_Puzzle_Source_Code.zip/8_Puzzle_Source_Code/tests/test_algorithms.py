from puzzle8.algorithms import ALGORITHMS, run_algorithm
from puzzle8.core import DEFAULT_GOAL, DEFAULT_START, apply_action, is_solvable

PARAMS = {
    "max_depth": 20,
    "max_nodes": 100_000,
    "timeout_s": 5,
    "seed": 42,
    "beam_width": 5,
    "adversarial_depth": 4,
    "iterations": 3000,
}


def test_registry_contains_18_algorithms():
    assert len(ALGORITHMS) == 18


def test_default_problem_is_solvable():
    assert is_solvable(DEFAULT_START, DEFAULT_GOAL)


def test_all_algorithms_run_on_course_preset():
    for algorithm_id in ALGORITHMS:
        result = run_algorithm(algorithm_id, DEFAULT_START, DEFAULT_GOAL, PARAMS)
        assert result.success, f"{algorithm_id}: {result.message}"
        assert result.states[0] == DEFAULT_START
        assert result.states[-1] == DEFAULT_GOAL
        assert len(result.states) == len(result.path) + 1


def test_classical_optimal_depth_is_five():
    for algorithm_id in ("bfs", "ucs", "astar", "ids"):
        result = run_algorithm(algorithm_id, DEFAULT_START, DEFAULT_GOAL, PARAMS)
        assert result.solution_depth == 5


def test_solution_paths_are_legal():
    for algorithm_id in ALGORITHMS:
        result = run_algorithm(algorithm_id, DEFAULT_START, DEFAULT_GOAL, PARAMS)
        state = DEFAULT_START
        for action, expected in zip(result.path, result.states[1:]):
            state = apply_action(state, action)
            assert state == expected
        assert state == DEFAULT_GOAL
